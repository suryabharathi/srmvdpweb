<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"> 
<link rel="stylesheet" href="//www.lpu.in/css/sweetalert2.min.css" type="text/css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/eonasdan-bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<script type="text/javascript" src="//www.lpu.in/js/jquery.js"></script>
	<script type="text/javascript" src="//www.lpu.in/js/sweetalert2.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.19.1/moment.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/eonasdan-bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
    <style type="text/css">
        body
        {
			font-family: 'Montserrat', sans-serif;
            background-color: #f5f5f6;
            font: normal 12px/1.5 "Tahoma";
            -webkit-font-smoothing: antialiased;
            margin: 0;
            padding: 0;
        }
		p{margin:0 !important;
		padding:5px 0}
        .about_heading2
        {
            color: #444444;
           
            font-size: 12px;
            font-style: normal;
            font-weight: bold;
            padding-top: 20px;
        }
        input.myButton, button.myButton
        {
            
            
            background-color: #f58221;
            display: inline-block;
            cursor: pointer;
            color: #ffffff;
          
			width: 100%;
            font-size: 14px;
            padding: 5px 5px;
            text-decoration: none;
			height: 35px;
			border: 0;
		}
		
		button.myButtonback
        {
            
            
            background-color: #ccc;
            display: inline-block;
            cursor: pointer;
            color: #000;
          
			width: 100%;
            font-size: 14px;
            padding: 5px 5px;
            text-decoration: none;
			height: 35px;
			border: 0;
		}
			
           
        }
		
		
		
    
        input.myButton:active
        {
            position: relative;
            top: 1px;
        }
        .Level_no
        {
           
            font-size: 12px;
            color: #f58221;
            font-weight: bold;
			padding:3px;
			display:inline;
			background-color:#2985c5;
			color:#FFF;
			
        }
        
		.offline p
		{padding:10px;}
		
		.offline strong{
			font-weight:bold;
			display:block;
			margin-bottom:5px;
		}
		
        .offline li
        {
            list-style-image: url(imgs/program_searc_list_style_red.png) !important;margin-bottom:15px;
        }
		.text-f{width: 100%; height: 38px; border: 1px #9d9d9d solid; padding-left: 5px;  box-sizing: border-box;  font-size: 18px; color: #8B8B8B;text-align: left;}
		
		.text-f-center{width: 100%; height: 38px; border: 1px #9d9d9d solid; padding-left: 5px;  box-sizing: border-box;  font-size: 18px; color: #8B8B8B;text-align: center;}
		.clickhere
        {
            background-color: #b00324;
            display: inline-block;
            cursor: pointer;
            color: #ffffff;
            font-size: 14px;
            padding: 3px 5px;
            text-decoration: none;
			margin-top: 10px;}
			.invalid{
				border-color:#cc0000;
			}
			
			
			
			.card {
			width: 300px;
			margin: 0 auto;
			-webkit-transition: -webkit-transform 1s;
			-moz-transition: -moz-transform 1s;
			-o-transition: -o-transform 1s;
			transition: transform 1s;
			-webkit-transform-style: preserve-3d;
			-moz-transform-style: preserve-3d;
			-o-transform-style: preserve-3d;
			transform-style: preserve-3d;
			-webkit-transform-origin: 50% 50%;
		}
		.card .card1 {
			display: block;
			width: 100%;			
			position: absolute;
			 background: #ffffff; -webkit-border-radius: 5px;
			-moz-border-radius: 5px;
			border-radius: 5px;
			-webkit-box-shadow: 0px 0px 10px 0px rgba(179,179,179,0.61);
			-moz-box-shadow: 0px 0px 10px 0px rgba(179,179,179,0.61);
			box-shadow: 0px 0px 10px 0px rgba(179,179,179,0.61);
			-webkit-backface-visibility: hidden;
			-moz-backface-visibility: hidden;
			-o-backface-visibility: hidden;
			backface-visibility: hidden;
		}
		.card .back {
			-webkit-transform: rotateY( 180deg );
			-moz-transform: rotateY( 180deg );
			-o-transform: rotateY( 180deg );
			transform: rotateY( 180deg );
		}
		.card.flipped {
			-webkit-transform: rotateY( 180deg );
			-moz-transform: rotateY( 180deg );
			-o-transform: rotateY( 180deg );
			transform: rotateY( 180deg );
		}
		.swal2-icon.swal2-success .line.tip{
			top:46px !important;
		}
    </style>
	
	
	
</head>
<body>

	
   
<div style="padding: 15px 0;"><center>
    <img src="//www.lpu.in/mailer/2017/logo-lpu.png">
        </center>    </div>
		
		
		
		
		
		
		
		
		

 			<div class="card">
<div class="card1" style="">
<div style="background: #f58221; color: #ffffff; padding: 10px; text-align: center; font-size: 18px; font-family: 'Montserrat', sans-serif;">GET CALL BACK</div>
			<div class="online" id="online">
			<div style="padding: 10px;">
			<p style="text-align: center; color: #727272; font-family: 'Montserrat', sans-serif; margin-bottom:10px;">
			<span>Please enter your mobile number</span> </p>
			<div style="text-align: center;">
					<form id="callform">
					<input type="text" required name="phone" class="text-f-center copyMe phoneonly" id="phone" style="margin-bottom:10px;" />
					
					<input type="button" id="btnSub" class="myButton" value="Get Call">
				</form>
			</div>
			<p style="text-align:center">
			OR
			</p>
			<p>
				<button onclick="flip()"  class="myButton">Schedule a Call</button>
			</p>
			<p>
			<small id="textline" style="display:none;text-align:center;width:100%">(This window will close automatically after the call is over)<br></small>
				<p runat="server" id="callcounseller" style="text-align: center; color: #727272; font-family: 'Montserrat', sans-serif; line-height: 22px">You would get call from number starting with +911824 shortly, kindly wait for few seconds after accepting the call to talk to our counsellor.</p>
			</div>
			<div style="background: #f2f2f2; padding: 10px; color: #b00324; font-size: 11px; text-align: center; font-weight: bold;">Counsellors available from 9.00 A.M to 5.00 P.M</div>
			</div>
			  </div>
			  <div class="back card1">
		<div style="background: #f58221; color: #ffffff; padding: 10px; text-align: center; font-size: 18px; font-family: 'Montserrat', sans-serif;">SCHEDULE A CALL</div>
		
		<div style="text-align: center;padding:10px">
		<form id="scheduleform">
		<p style="text-align: left; color: #727272; font-family: 'Montserrat', sans-serif; margin-bottom:10px;">
			<span>Please enter your name</span> </p>
				<input type="text" id="name" name="name" required class="text-f" style="margin-bottom:10px;" />	
					<p style="text-align: left; color: #727272; font-family: 'Montserrat', sans-serif; margin-bottom:10px;">
			<span>Please enter your mobile number</span> </p>
				<input type='text' id='phonenumber' required name='phonenumber' class="text-f copyMe phoneonly" style="margin-bottom:10px;" />	
					<p style="text-align: left; color: #727272; font-family: 'Montserrat', sans-serif; margin-bottom:10px;">
			<span>Programme Interested</span> </p>
				<input type='text' id='programme' required name='programme' class="text-f" style="margin-bottom:10px;" />	
				<p style="text-align: left; color: #727272; font-family: 'Montserrat', sans-serif; margin-bottom:10px;">
			<span>Please Select Date</span> </p>
				<select id="scheduledate" required name="scheduledate" onchange="bindtime(this)" class="text-f" style="margin-bottom:10px;">
			<option value="">Select Date</option>
			</select>
			<p style="text-align: left; color: #727272; font-family: 'Montserrat', sans-serif; margin-bottom:10px;">
			<span>Please Select Time</span> </p>
				<input type='text' readonly="readonly" required id='datetimepicker1' name="datetimepicker1" class="text-f" style="margin-bottom:10px;" />	
				
				<input type='button' id='scall' class="myButton" value="Schedule call" style="margin-bottom:10px;" />
				
			
		</form>
		
		
		
		<p>
				<button onclick="flip()"  class="myButtonback">BACK</button>
			</p>
			</div>
	</div>
	
	
	
	
	
		  </div>
		  	 <script type="text/javascript">
				   function flip() {
				$('.card').toggleClass('flipped');
			}
	</script>
		 

    
	
		
  
	

	 <script type="text/javascript">
	
	$(function()
	{
		
		$(".phoneonly").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
	
		$.validator.addMethod('phone', function (value) { 
			return /^(?:\s+|)((0|(?:(\+|)91))(?:\s|-)*(?:(?:\d(?:\s|-)*\d{9})|(?:\d{2}(?:\s|-)*\d{8})|(?:\d{3}(?:\s|-)*\d{7}))|\d{10})(?:\s+|)$/.test(value); 
		}, 'Please enter a valid indian number.');
		
		$('#callform').validate({
						rules: {
							    phonenumber: {
								  required: true,
								  number: true,
								  minlength: 10
								}
						},
                errorElement: 'div',
                errorClass: 'invalid',
                errorPlacement: function (error, element) {
					
                    
                },
				highlight: function (element, errorClass, validClass) {
					$(element).addClass(errorClass).removeClass(validClass);

				},
				unhighlight: function (element, errorClass, validClass) {
					$(element).removeClass(errorClass).addClass(validClass);
					
				} 
		});
		$('#scheduleform').validate({
						rules: {
							    phone: {
								  required: true,
								  number: true,
								  minlength: 10
								}
						},
                errorElement: 'div',
                errorClass: 'invalid',
                errorPlacement: function (error, element) {
					
                    
                },
				highlight: function (element, errorClass, validClass) {
					$(element).addClass(errorClass).removeClass(validClass);

				},
				unhighlight: function (element, errorClass, validClass) {
					$(element).removeClass(errorClass).addClass(validClass);
					
				} 
		});
		
	});
	 
	 $('#btnSub').click(function(event) { 
	 
			if($("#callform").valid()){
				$('#btnSub').attr('disabled','disabled');
				$('#btnSub').val('Calling in Process..');
				$('#textline').css('display','inline-block');
				
				$.get("http://220.227.154.176:8888/ameyowebaccess/command/?command=clickToCall&data={%22userId%22:%22API%22,%22password%22:%22API%22,%22terminal%22:%22172.19.2.91%22,%22campaignId%22:%2281%22,%22phone%22:%22" + $('#phone').val() + "%22,%22requestId%22:%22asda1234%22,%22shouldAddCustomer%22:%22true%22,%22additionalParams%22:{%22akey%22:%22aval%22,%22bkey%22%20:%22bval%22}}", function( data ) {
					window.close()
				});	
		}
		else
		{
		}
				event.preventDefault();
				return false;
			   
		});
      $(function () {
			$(".copyMe").keyup(function(){
				$(".copyMe").val($(this).val());
			});
			//alert();
			$( "#scall" ).click(function() {
				if($("#scheduleform").valid()){
					$('#scall').attr('disabled','disabled');
				$('#scall').val('Please wait..');
			  var datetimeStart=new Date();
			  var sdate=$("#scheduledate option:selected").text()+" "+$("#datetimepicker1").val()+":00";
			  var datetimeEnd=new Date(sdate);
			 
			  if(Date.parse(datetimeStart) > Date.parse(datetimeEnd)){
				   swal("Time invalid!", "Call cannot be scheduled for the time already elapsed. Please select future time/date for scheduling a callback.", "warning");
				   $('#scall').attr('disabled','');
						$('#scall').val('Schedule Call');
				}else{
				   $.post( "https://services.lpu.in/api/programsearch/ScheduleCall", { Phone: $("#phonenumber").val(), ScheduleDateTime: sdate, Name: $("#name").val(), Programme: $("#programme").val() })
					  .done(function( data ) {
						  $('#scall').attr('disabled','');
						$('#scall').val('Schedule Call');
						swal("Call scheduled successfully!", "Thank you! We have saved your request for call back on "+data+". You will receive a call at the scheduled time.", "success").then((value) => {
						  window.close();
						});
						$('#scheduleform')[0].reset();
						$('#scall').attr('disabled','');
						$('#scall').val('Schedule Call');
						
					  });
				}
				}
			});
			//$('#datetimepicker1').datetimepicker();
			$.get( "https://services.lpu.in/api/programsearch/Clicktocallschedule", function( data ) {
			$.each(data, function (index, element) {
							$('#scheduledate').append('<option value="' + element.EnableTime + '">' + element.sDate + '</option>');
						});
			});
		
            });
			function bindtime(x){
			  //$('#datetimepicker1').val('');
			 // $('#datetimepicker1').datetimepicker();
			 var dt= $('#datetimepicker1').data("DateTimePicker");
			 //console.log(dt);
			 //var dt="";
				if(typeof dt !== "undefined" && dt !== null ){
				
				  dt.destroy();
				
				}
			 
			  var hours = $(x).val().split(',');
			  //alert(hours);
			  $('#datetimepicker1').datetimepicker({
					enabledHours: hours,
					format: 'HH:mm',
					ignoreReadonly: true,
					icons: 
					{
						up: 'fa fa-angle-up',
						down: 'fa fa-angle-down'
					}
				}); 
			
			}
    </script>
</body>
</html>
