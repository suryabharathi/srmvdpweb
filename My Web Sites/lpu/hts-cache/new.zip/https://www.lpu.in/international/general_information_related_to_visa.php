<!doctype html>
<html>
<head> <meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>LPU International | Lovely Professional University</title>
<meta name="description" content="LPU International" />
<meta name="keywords" content="LPU International" />

    <!-- Stylesheets
	============================================= -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700" rel="stylesheet">
	<link rel="stylesheet" href="../css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/style.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/dark.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/animate.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/magnific-popup.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/vmap.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/responsive.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/home-custom.css" type="text/css" />
	
	<link rel="stylesheet" href="css/international-custom.css" type="text/css" />
	
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="author" content="LOVELY PROFESSIONAL UNIVERSITY" />

    <!-- One Page Module Specific Stylesheet -->
    <!--<link rel="stylesheet" href="../one-page/onepage.css" type="text/css" />-->
    <!-- / -->

    <!-- External JavaScripts
	============================================= -->
    <script type="text/javascript" src="//www.lpu.in/js/jquery.js"></script>
    <script type="text/javascript" src="//www.lpu.in/js/plugins.js"></script>
	<script type="text/javascript" src="//www.lpu.in/js/sweetalert2.min.js"></script>

    <title>LPU- India's Largest Best Private University (Jalandhar, Punjab)</title>
	
	<style type="text/css">
		#page-menu nav li a {font-size:13px!important;}		
		
	
	</style>
	
	<!-- Start of LiveChat (www.livechatinc.com) code -->
<script type="text/javascript">
window.__lc = window.__lc || {};
window.__lc.license = 9045305;
(function() {
  var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
  lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
})();
</script>
<!-- End of LiveChat code -->
	
</head>

<body class="stretched">

<!-- Document Wrapper
    ============================================= -->
<div id="wrapper" class="clearfix"> 

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P8ZP9K2"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- Hello Bar Start -->
<style>
.lpu-hello-bar{background-color:#fccb92 ; color:#000000; padding:9px 10px; text-align:center; }
.font18{font-size:18px;}
.section-mt40{margin-top:40px !important;} <!--for landing page -->
.font15b{font-size:16px;font-weight:bold !important;}
@media(max-width:430px){.font18{font-size:16px;}
.font15b{font-size:14px;font-weight:bold !important;}}
@media(max-width:800px)
{.lpu-hello-bar{position:static !important;}#top-bar{margin-top:0;}
.section-mt40{margin-top:0 !important;} <!--for landing page -->
}
#top-bar {
    margin-top: 0 !important;
}
#header.sticky-header #header-wrap{
	top:0 !important;
}
#page-menu.sticky-page-menu #page-menu-wrap, .main-nav-scrolled{
	top:60px !important;
}
</style>

  
<!--<div class="lpu-hello-bar" id="lpu-bar">

 	
	 <div class="oc-item">
	<div class="font-f" id="topbartext">
		<i class="icon icon-bullhorn" aria-hidden="true"></i>
		<span>Last date to apply with scholarship up to 50%* (31st August 2018)</span>  <b class="font15b">
			<a class="hide-on-lp" href="//admission.lpu.in/"  style="color:#000000 !important;" target="_blank"> Apply Now.</a> </b>
		<br>
		
	</div>
	</div>
	
	
	
</div>-->
<!-- Hello Bar End-->

<div id="top-bar" class="ps-top-bar slider-top-link">
			<div class="container-fluid clearfix">
				<div class="col_half nobottommargin mr0">
					<div class="top-links dark">
						<ul>
							<li class="hidden-xs hidden-xxs hidden-sm hidden-md"><a href="https://ums.lpu.in/lpuums" target="_blank">Parent's Login</a></li>
							<li class="hidden-xs hidden-xxs hidden-sm hidden-md"><a href="https://ums.lpu.in/lpuums" target="_blank">UMS Login</a></li>
							<li class="hidden-xs hidden-xxs hidden-sm"><a href="//www.lpu.in/about_lpu/tour_lpu.php">Campus Visit</a></li> 
							<li class="hidden-xs hidden-xxs hidden-sm"><a href="//happenings.lpu.in/" target="_blank">Happenings</a></li>
							<li class="hidden-xs hidden-xxs hidden-sm"><a href="//conferences.lpu.in/" target="_blank"> Conferences </a> </li>
							<li class="hidden-xs hidden-xxs hidden-sm"><a href="//www.lpu.in/international/pick-up-services.php" class="nest-result" target="_blank"> Reporting Schedule</a> </li>
							<li class="hidden-xs hidden-xxs hidden-sm"><a href="//www.lpu.in/international/contact-us.php">Contact Us</a></li>     
			<!--<li><a id="educationawards" href="#" data-toggle="modal" data-target="#myLargeModal">Education Awards</a></li>			 -->
          </ul>
					</div>
				</div>
				<div class="col_half fright nobottommargin mr0">
					<div id="top-social">
						<ul>
							<li><a href="https://www.facebook.com/LPUUniversity" target="_blank" class="si-facebook"><span class="ts-icon"><i class="icon-facebook"></i></span></a></li>
							<li><a href="https://twitter.com/lpuuniversity" target="_blank" class="si-twitter"><span class="ts-icon"><i class="icon-twitter"></i></span></a></li>
							<li><a href="https://plus.google.com/u/0/102445329734305802454/posts" target="_blank" class="si-gplus"><span class="ts-icon"><i class="icon-gplus"></i></span></a></li>
							<li><a href="https://www.linkedin.com/company/lovely-professional-university" target="_blank" class="si-linkedin"><span class="ts-icon"><i class="icon-linkedin"></i></span></a></li>
							<li><a href="https://www.youtube.com/user/LPUuniversity" target="_blank" class="si-youtube"><span class="ts-icon"><i class="icon-youtube"></i></span></a></li>
							<li><a href="tel:+91.1824.404404" class="si-call"><span class="ts-icon"><i class="icon-call"></i></span></a></li>
							<li><a href="mailto:admissions@lpu.co.in" class="si-email3"><span class="ts-icon"><i class="icon-email3"></i></span></a></li>
							 <li><a href="//www.lpu.in/about_lpu/tour_lpu.php" target="_blank" class="si-call"><span class="ts-icon"><i class="icon-globe"></i></span><span class="ts-text">360<sup>0</sup> View</span></a>
							</li>
						  </ul>
					</div>
				</div>
			</div>
		</div>
		
		<script type="text/javascript">

						$(document).ready(function() {
							 $("#oc-posts-top-bar").owlCarousel({
								margin: 20,
								autoplayTimeout:5000,								
								loop:true,
								nav: false,
								navText: ['<i class="icon-angle-left"></i>','<i class="icon-angle-right"></i>'],
								autoplay: true,
								autoplayHoverPause: true,
								dots: false,
								responsive:{
									0:{ items:1 },
									600:{ items:1 },
									1000:{ items:1 },
									1200:{ items:1 }
								}
							});

						});

					</script>
		<header id="header" class="full-header ps-header" data-responsive-class="not-dark">
	<div id="header-wrap">
		<div class="container clearfix">
			<div id="primary-menu-trigger"><i class="icon-reorder"></i>
			</div>
			<div id="logo">
				<a href="//www.lpu.in/" class="standard-logo" data-sticky-logo="//www.lpu.in/images/logo/logo-media.png" data-dark-logo="//www.lpu.in/images/logo/logo-dark.png" data-mobile-logo="//www.lpu.in/images/logo/logo-media.png"><img src="//www.lpu.in/images/logo/logo.png"  alt="LPU Logo" width="auto" height="auto" /></a>
				<a href="//www.lpu.in/" class="retina-logo" data-sticky-logo="//www.lpu.in/images/logo/logo-media@2x.png" data-dark-logo="//www.lpu.in/images/logo/logo-dark.png" data-mobile-logo="//www.lpu.in/images/logo/logo-media@2x.png"><img width="auto" height="auto" src="//www.lpu.in/images/logo/logo-media@2x.png"  alt="LPU Logo"></a>
			</div>
			<nav id="primary-menu">
				<ul>
									
					<li class="mega-menu sub-menu">
						<a href="#">
							<div style="border-bottom:2px solid #F68121;">Admissions</div>
						</a>
						
						
						<div class="mega-menu-content style-2 clearfix col-3" style="padding:0 !important">
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Get Started</div>
									</a>
									<ul>

										<li>
											<a href="//www.lpu.in/international/how_to_apply.php">
												<div>How to Apply</div>
											</a>
										</li>
										<li>
											<a href="//admission.lpu.in">
												<div>Apply Online</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/scholarship.php">
												<div>Scholarship</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/english-language-requirement.php">
												<div>English Language Requirement</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/how_to_pay.php">
												<div>How to Pay</div>
											</a>
										</li>
										
									
										<li>
											<a href="//www.lpu.in/international/booklet_and_forms.php">
												<div>Admission Guidelines</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/across_globe.php">
												<div>Our Global Representatives</div>
											</a>
										</li>
																				
											<li>
											<a href="//www.lpu.in/OnlineAdmission/LetterAuthentication.aspx">
												<div>Admission Letter Authentication</div>
											</a>
										</li>
										<li><a  target="_blank" href="//www.lpu.in/international/admission_related_faqs.php"><div>Admission Related FAQs</div></a> </li>
											
										
										
										
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Programme We Offer</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/international/programmes/all/Grade 10th (O Level)">
												<div>Diploma (after O level)</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/programmes/all/Grade 12th (A Level)">
												<div>Bachelor Degree (after A level)</div>
											</a>
										</li>
										
										<li>
											<a href="//www.lpu.in/international/programmes/all/Graduation">
												<div>Master Degree (after Graduation)</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/programmes/all/Graduation">
												<div>Ph.D. (after Post Graduation)</div>
											</a>
										</li>
										<li><a href="//www.lpu.in/international/english-language-programme.php">
										  <div>English Language Programmes</div>
										  </a></li>
										  <li>
											<a href="//www.lpu.in/international/study_india_programme.php">
												<div>Study India Programmes</div>
												
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/study_abroad_programme.php">
												<div>Term Exchange Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/index.php">
												<div>International Summer School Programmes</div>
											</a>
										</li>
										<!--<li>
											<a href="//www.lpu.in/programmes/ProgramSearch.php">
												<div>Programme Search</div>
											</a>
										</li>-->
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Other Links</div>
									</a>
									<ul>
									<li><a  target="_blank"  href="//www.lpu.in/international/accommodation.php"><div>Residential Facilities</div></a></li>
									  <li><a  target="_blank" href="//www.lpu.in/international/general-faq.php"><div>Joining Related FAQs</div></a> </li>
									   <li><a  target="_blank" href="//www.lpu.in/international/visa-frro-faq.php"><div>VISA/FRRO Related FAQs</div></a> </li>
									   <li><a  target="_blank" href="//www.lpu.in/international/downloads/international-booklet.pdf"><div>Download International Booklet</div></a> </li>
									   <li><a  target="_blank" href="//www.lpu.in/international/downloads/refund_policy.pdf"><div>Refund Policy </div></a> </li>
																									
									</ul>
							
						
								</li>
							</ul>
						</div>
						
						
						
				
					
					
					</li>
					
					
					<li>
						<a href="#">
							<div>Student Services</div>
						</a>
						<div class="mega-menu-content style-2 clearfix" style="padding:0 !important">
							<ul>

								<li class="mega-menu-title">
										<a>
										<div>Get Started</div>
									</a>
									<div class="col-xs-12 mb0 pl0 pr0">
										<ul>
										<li><a  target="_blank"  href="//www.lpu.in/international/reporting-schedule-pickup-services.php"><div>Pick-up Facility</div></a></li>
											<li><a  target="_blank"  href="//www.lpu.in/international/pre_arrival.php"><div>Pre Arrival Information</div></a></li>
									 <li><a target="_blank" href="//www.lpu.in/international/post_arrival.php"><div>Post Arrival Information</div></a> </li>
									 <li><a target="_blank"  href="//www.lpu.in/international/after_you_graduate.php"><div>After You Graduate</div></a> </li>
								  <li><a target="_blank"  href="//www.lpu.in/international/returning_back.php"><div>Returning Back Home</div></a> </li>
								  <li><a  target="_blank" href="//www.lpu.in/international/international_student_experience.php"><div>Students Testimonials</div></a> </li>
										</ul>
									</div>
								</li>
							</ul>
						</div>
					</li>
					
					
					<li>
						<a href="#">
							<div>Summer School</div>
						</a>
						<div class="mega-menu-content style-2 clearfix" style="padding:0 !important">
							<ul>

								<li class="mega-menu-title">
									<a>
										<div>Get Started</div>
									</a>
									<div class="col-xs-12 mb0 pl0 pr0">
										<ul>
											 <li>
											<a href="//www.lpu.in/international/summer_school/index.php">
												<div>Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/SummerSchoolApplicationForm.aspx">
												<div>Apply Now</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_eligibility.php">
												<div>Eligibility</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_registeration_and_fee_structure.php">
												<div>Registration & Fee</div>
											</a>
										</li>
											<a href="//www.lpu.in/international/summer_school/int_proposed_schedule.php">
												<div>Schedule and Details</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_accommodation_and_facilities.php">
												<div>Accomodation and Other Facilities</div>
											</a>
										</li>
										
										<li>
										
										<li>
											<a href="//www.lpu.in/international/summer_school/int_visa_requirement_and_guidelines.php">
												<div>Visa Requirement and Guidelines</div>
											</a>
										</li>
										
										 <li><a href="//www.lpu.in/international/summer_school/int_gallery.php">
										  <div>Gallary</div>
										  </a></li>	
										  
										   <li><a href="//www.lpu.in/international/summer_school/int_faq.php">
										  <div>FAQ's</div>
										  </a></li>	
										  
										     <li><a href="//www.lpu.in/international/summer_school/int_contact.php">
										  <div>Contact Us</div>
										  </a></li>	
										</ul>
									</div>
								</li>
							</ul>
						</div>
					</li>
					
					
					<li>
						<a href="#">
							<div>Visa Assistance</div>
						</a>
						<div class="mega-menu-content style-2 clearfix" style="padding:0 !important">
							<ul>

								<li class="mega-menu-title">
									<a>
										<div>Get Started</div>
									</a>
									<div class="col-xs-12 mb0 pl0 pr0">
										<ul>
											 <li><a  target="_blank" href="//www.lpu.in/international/general_information_related_to_visa.php"><div>Visa Requirement and Guidelines</div></a> </li>
											  <li><a  target="_blank" href="//www.lpu.in/international/general-faq.php"><div>Joining Related FAQs</div></a> </li>
									
								  <li><a  target="_blank" href="//www.lpu.in/international/visa-frro-faq.php"><div>VISA/FRRO Related FAQs</div></a> </li>
								  
								   <li><a  target="_blank" href="//www.lpu.in/international/visa_extensions.php"><div>Visa Extensions</div></a> </li>
										</ul>
									</div>
								</li>
							</ul>
						</div>
					</li>
					
			
					<li class="mega-menu">
						<a href="#">
							<div>Academics</div>
						</a>
						<div class="mega-menu-content col-2 style-2 clearfix">
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>How We Teach</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/academics/live-projects.php" target="_blank">
												<div>Live projects</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/industry-immersion.php" target="_blank">
												<div>Industry Immersion</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/Interdisciplinary-minors.php" target="_blank">
												<div>Interdisciplinary Minors</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/curriculum-innovations.php" target="_blank">
												<div>Curriculum innovations</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/guest-lectures.php" target="_blank">
												<div>Guest lectures / Workshops</div>
											</a>
										</li>

										<li>
											<a href="//www.lpu.in/academics/assessment-and-evaluation.php" target="_blank">
												<div>Assessment & Evaluation</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/mentoring-advising.php" target="_blank">
												<div>Mentoring and advising</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Highlights</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/academics/research.php" target="_blank">
												<div>Research @ LPU</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/faculty-development.php" target="_blank">
												<div>Human Resource Development Center</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/placements.php" target="_blank">
												<div>Placements</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/libraries-laboratories.php" target="_blank">
												<div>Libraries & Laboratories</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/calendar_regular_programmes.php" target="_blank">
												<div>Academic Calendar</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/holiday-list.php" target="_blank">
												<div>Holiday List</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
						
						</div>
					</li>
				
					

			<li class="mega-menu">
						<a href="#">
							<div>Campus Life</div>
						</a>
						
						<div class="mega-menu-content col-2 style-2 clearfix">
						
							
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Campus Life</div>
									</a>
									
									<div class="col-md-12 mb0 pl0 pr0">
									<div class="col-md-6 ma0 pa0"><ul>
											<li>
												<a href="//www.lpu.in/campus_life/entrepreneurship.php" target="_blank">
													<div>Entrepreneurship</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/sports.php" target="_blank">
													<div>Sports</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/art-and-culture.php" target="_blank">
													<div>Art & Culture</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/campus-events.php" target="_blank">
													<div>Campus Events</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/student-organisations.php" target="_blank">
													<div>Student Organizations</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/community-services.php" target="_blank">
													<div>Community Service</div>
												</a>
											</li>
										</ul>
									</div>
									<div class="col-md-6 ma0 pa0"><ul>
											
											<li>
												<a href="//www.lpu.in/campus_life/visitors.php" target="_blank">
													<div>Visitors</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/diversity.php" target="_blank">
													<div>Diversity</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/on-campus-jobs.php" target="_blank">
													<div>On Campus Jobs</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/fun-zone.php" target="_blank">
													<div>Fun Zone</div>
												</a>
											</li>
											<!--<li>
												<a href="//www.lpu.in/startupschool" target="_blank">
													<div>Startup School</div>
												</a>
											</li>-->
										</ul>
									</div>
										
									</div>
								
								
								</li>
							</ul>
						

							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Student Services</div>
									</a>
									
									<div class="col-md-12 mb0 pl0 pr0">
									<div class="col-md-6 ma0 pa0"><ul>
											<li>
												<a href="//www.lpu.in/student_services/security.php" target="_blank">
													<div>Campus Security</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/healthcare.php" target="_blank">
													<div>Uni Hospital</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/ums.php" target="_blank">
													<div>University Management System</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/residence.php" target="_blank">
													<div>Residential Facilities</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/transport.php" target="_blank">
													<div>Transportation Facilities</div>
												</a>
											</li>
										</ul>
									</div>
									<div class="col-md-6 ma0 pa0"><ul>
											
											<li>
												<a href="//www.lpu.in/student_services/shopping-dining.php" target="_blank">
													<div>Shopping & Dining</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/banking-postal-services.php" target="_blank">
													<div>Banking and Postal Services</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/education-loan-assistance.php" target="_blank">
													<div>Education Loan Assistance</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/placements.php" target="_blank">
													<div>Placements</div>
												</a>
											</li>
										</ul>
									</div>
										
									</div>
								
								
								</li>
							</ul>
						
						</div>
					
						
						
				</li>

		
				
				
				<li class="scroll-menu">
						<a href="//admission.lpu.in/" target="_blank">
							<div>Apply Now</div>
						</a>
					</li>
				</ul>
				<div id="top-search">
					<a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
					<form action="//www.lpu.in/result.php" name="form2" id="form2">
						<input type="hidden" name="cx" value="partner-pub-016589675364233558975:gl7zrlhae3u"/>
						<input type="hidden" name="cof" value="FORID:11"/>
						<input type="hidden" name="ie" value="ISO-8859-1"/>
						<input type="text" name="q" onclick="make_blank();" class="form-control" placeholder="Type &amp; Hit Enter.."/>
					</form>
				</div>
			</nav>
		</div>
	</div>
</header>


				
		
<section id="page-title" class="page-title-mini">
<div class="container clearfix text-center">
<h1>Visa Requirement and Guidelines</h1>

</div>
</section>
<section id="content" class="mt0 pt40">

	
	
	<div class="container clearfix">
		<div class="col-md-12 grid-outer mb15 pa15">
		

      <ul class="list-img pl15 mb10">
	  
<li> Foreign Nationals desirous of coming into  India are required to possess a valid passport of their country and a valid  Indian Visa. The only exceptions are nationals of Nepal and Bhutan who can  enter India without a visa.<br />
  (Note: Nepalese nationals need a visa if  entering India from China).</li>
 
<li> To study in India it is mandatory for an  international student to procure an Indian Student Visa.</li>
<li> Visas can be applied for in person or by post  (in certain High Commissions/Embassies, it is responsibility of the student to  check with particular embassy on postal visa application) to the High  Commission of India based in the country from where the candidate intends to  depart for India.</li>
<li> Applicant need to mention the name of the  Institute while applying for the visa, which is then mentioned on the visa.</li>
<li> International students taking admission at  Lovely Professional University should make sure that the Student<br />
  Visa is endorsed to Lovely Professional  University by the visa issuing authority.</li>
<li> A request for change of university or  institution subsequently made cannot be considered. In this case you would be  required to go back to your home country and apply for a new visa.</li>
<li> Also, if you have entered India on basis of  documents provided by the University then it is your responsibility to ensure  that you directly join and report to the University. The Visa endorsed on the  name of the University or obtained on the basis of University documents cannot  be used for any other purpose like employment , admission to any other  university/college/institute/academy etc or for non-regular (distance/online)  mode of education.</li>
<li> After reaching the university students have to  get the visa verified by the University and have to deposit a copy of the valid  visa.</li>
<li> It is the responsibility of the student to  ensure that throughout his/her study period student is on valid visa.</li>
<li> In case the initial visa is not endorsed for  the complete duration of the programme or student has to extend the stay  because he/she is not able to complete the programme in the stipulated time  then the student should apply for the extension of the visa before visa  expires.</li>
<li> It is the responsibility of the student to  ensure that visa should be applied well in advance and time. It generally takes  3-8 weeks to get the Indian Visa thus it is advisable to apply for the visa  accordingly and consult the Indian High Commission/Embassy if required.</li>
<li> In case a student reports to the university  late because of the Visa/Tickets Availability or any other personal issue, no  relaxation related to attendance or any favour for completing the assignment,  submitting the missed assignments, sitting for the missed examination(s), relaxation  in the marks etc. will be given.</li>
<li> Students joining the university after the  prescribed time period may be denied admission. In such cases the fees etc.  deposited by the applicant would be forfeited and further no claim for the  expense made for the travelling, visa or any other expense made or hardship  suffered by the student will be entertained.</li>
<li> Even, after joining the university if the  student leaves the country then it is the responsibility of the student to  report back at the university on time. It some cases where visa extension is  required it is the responsibility of the student to ensure to get the valid  visa extension on time. In case student reports to the university late because  of the<br />
  Visa/Tickets Availability or any other personal  issue then student will not be provided any relaxation related to attendance,  extra time to complete the assignments, opportunity to submit the missed  assignments, opportunity to sit for the missed examination(s), relaxation in  the marks etc.</li>
<li> In case student is expelled from the  university or the student decides to leave the programme then an affidavit has  to be submitted to the university that he/she will leave India immediately and  will not use visa issued on the basis of LPU documents to stay in India.</li>
<li> University may debar the student to continue  attending classes or staying in the university residential facility if student does not  maintain a valid visa/ FRRO or does not follow any guidelines issued by the  Govt. of India/ Govt. of Punjab/University/ any other authority from time to  time.</li>
<li> For loss of attendance/ academics or any  expenditure so occurred because of such action by the university, the student  himself will be responsible and no relaxation or benefit may be provided in  such cases and all expenditure has to be born by the student.</li>
</ul>
<p class="mb5"><strong>

“The following questions will be helpful for getting exact answers for the pre-determined queries in your mind related to Indian Student Visa.”
 
</strong></p>
<strong>Disclaimer:</strong> Information provided here is based on data/information available on various public domains. It is the student’s responsibility to comply with all Visa or all other formalaties as defined by government from time to time. Thus it is advised to visit Ministry of External Affairs website for the most updated information and towards (Instead of towards it should be to avoid) any complications and hassles.



</div>
</div>
</section>	     
	 
		   

﻿
<!-- Footer============================================= -->
<style>
	.iccash li{margin-bottom:15px;}
	#myLargeModal .mod-btn-6.active {background: #f68220 none repeat scroll 0 0;border-color: #f68220;color: #fff;}	
	#myLargeModal .mod-btn-6:hover {background: #f68220 none repeat scroll 0 0;border-color: #f68220;color: #fff;}	
	.nirf-hd {color: #333333;text-transform: uppercase;font-size: 14px;font-weight: 500;text-decoration: none;line-height: 25px;}	
	.nirf-hd span {text-transform: none;color: #f68220;	text-decoration: underline;	}	
	.nirf li i {color: #f68220;	font-size: 11px;padding-right: 10px;}	
	.vertical-alignment-helper {display: table;height: 100%;width: 100%;}
	.vertical-align-center {display: table-cell;vertical-align: middle;}
	.modal-content {width: inherit;height: inherit;margin: 0 auto;}	
	.disciplines-popup {-webkit-border-radius: 10px !important;-moz-border-radius: 10px !important;border-radius: 10px !important;}	
	.disciplines-popup li {background: rgba(0, 0, 0, 0) url("//www.lpu.in/images/icons/widget-link.png") no-repeat scroll left 5px;line-height: 25px;border: medium none !important;color: #444;font-size: 14px;list-style: outside none none;padding-left: 15px;}	
	#dexample td {border: none !important;background: url(//www.lpu.in/images/icons/widget-link.png) no-repeat;padding: 0 0 0 15px;display: inline-block}	
	#dexample tr {background: none !important;border: medium none;display: inline-block;float: left;padding: 0 0 0 15px;width: 33%;}	
	.no-footer,	.dataTables_wrapper.no-footer .dataTables_scrollBody {border: none !important;}	
	#disciplines-popup table.dataTable thead th,#disciplines-popup table.dataTable thead td {border: none !important;}	
	@media screen and (min-width: 320px) and (max-width: 1023px) {#dexample tr {float: none;width: 100%;}}	
		
	.intercom .feature-box .fbox-icon {	width: 55px;height: 55px;}
	.intercom .feature-box .fbox-icon i {line-height: 58px;background-color: #ff4358;}	
	.intercom .fbox-effect .fbox-icon i:hover,.intercom .fbox-effect:hover .fbox-icon i {background-color: #ff4358;}	
	.intercom .fbox-effect .fbox-icon i:after {box-shadow: none;left: 0;}
	.intercom .badge {position: absolute;z-index: 999;right: 0;cursor: pointer;}	
	.toast-top-left {bottom: 80px;top: auto !important;}	
	.badge-color {background: #ff4358;color: #fff;box-shadow: 0 !important;}	
	.mt75 {	margin-top: 75px}	
	/*body.modal-open {overflow-y: scroll;}*/	
	.intercom .icon-comment:before {content: "\e65f";left: 14px;position: absolute;}	
	.m10 {margin-top: 9%;}
	.m3 {margin-top: 3%;}	
	.modal-dialog {	margin: 0 auto;}	
	.modal-body {padding: 0 15px !important;}	
	#noti .entry-content {background: #fff;}
	.single-modal {width: 300px !important;}
	.double-modal {	width: 600px !important;}
	.col-61 {width: 50% !important;}	
	.col-12 {width: 100% !important;}	
	#myLargeModal .modal-content {background: #EBEBEB;}	
	#myLargeModal .mod-btn {border-color: #2985C6;color: #2985C6;width: 96%;text-align: center;}	
	#myLargeModal .mod-btn:hover {border-color: #2985C6;color: #fff;background: #2985C6;}	
	#myLargeModal .mod-btn-6 {border-color: #2985C6;color: #2985C6;width: 45%;text-align: center;padding: 0 3px!important;font-size: 9px;}	
	#myLargeModal .mod-btn-6:hover {border-color: #2985C6;color: #fff;background: #2985C6;}	
	#myLargeModal .modal-header {padding: 7px;border-color: #d6d6d6;}
	.pr7 {padding-right: 7px;}
	.pl7 {padding-left: 7px;}	
	@media(max-width:770px) {#noti .entry-content p {min-height: auto !important;}#myLargeModal.modal{overflow-y:scroll !important;}}	
	.popupwindow {cursor: pointer;}
</style>

<!--Start of Zendesk Chat Script-->
<script type="text/javascript">
window.$zopim || (function(d, s) {
    var z = $zopim = function(c) {
            z._.push(c)
        },
        ps = z.s =
        d.createElement(s),
        e = d.getElementsByTagName(s)[0];
    z.set = function(o) {
        z.set.
        _.push(o)
    };
    z._ = [];
    z.set._ = [];
    ps.async = !0;
    ps.setAttribute("charset", "utf-8");
    ps.src = "https://v2.zopim.com/?5zU5ycyGChvBrSvnk5mgdxLN5fzikAC3";
    z.t = +new Date;
    ps.
    type = "text/javascript";
    e.parentNode.insertBefore(ps, e);
	
})(document, "script");
</script>
<!--End of Zendesk Chat Script-->


<div class="right-new-bar  hidden-sm hidden-xs hidden-xxs">


<div class="mb5 text-right"><a target="_blank"  href="//iviewd.com/lpu/"><img width="" height="auto" src="//www.lpu.in/images/virtual-tour.png" alt=""></a></div>




	<div class="right-icons apply-now" style="display:none !important">
		<div class="rotate" href="#LoginModal1" data-lightbox="inline" style="cursor:pointer">Apply Now</div>
	</div>
	<div class="right-icons call">
		<a href="" class="ppwnd white-tooltip" data-toggle="tooltip" data-placement="left" title="Schedule a Call">
		<i class="icon-call ml5"></i></a>
	</div>
	<div class="right-icons d-one">
		<a href="" target="_blank" class="white-tooltip si-whatsapp hidden-sm hidden-xs hidden-xxs" data-toggle="tooltip" data-placement="left" title="">
			<img width="auto" height="auto" src="//www.lpu.in/images/whatsapp-icon.png" alt="">
		</a>		
	</div>

	<div class="right-icons international">
		<a href="" target="_blank" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="For SAARC Nations::+91-9780005961 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;For Other Nations::+91-9855322332">
			<img width="auto" height="auto" src="//www.lpu.in/images/whatsapp-icon.png" alt="">
		</a>
	</div>
	<div class="right-icons international">
		<a href="//www.lpu.in/international/contact-us.php" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="Enquire Now ">
			<img width="auto" height="auto" src="//www.lpu.in/images/enquire-icon.png" alt="">
		</a>
	</div>
	<div class="right-icons international">
		<a href="//admission.lpu.in" target="_blank" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="Apply Now">
			<img width="auto" height="auto" src="//www.lpu.in/images/apply-now-icon.png" alt="">
		</a>
	</div>
	<div class="right-icons ltown"><a href="//www.lpu.in/admission/lpu-in-your-town.php#lpu-town" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="LPU in Your Town"><i class="icon-location ml3"></i></a>
	</div>
	<div class="right-icons chatimg hide" style="height:43px;">
	</div>
</div>
<footer id="footer" class="dark remove-div" style="background-color: #222;">
	<div class="container mt15 clearfix" style="font-size:8px">E&OE </div>
	<div class="container">
		<!-- Footer Widgets
				============================================= -->
		<div class="footer-widgets-wrap clearfix" style="padding:20px 0 10px 0">
			<div class="col_two_third">
				<div class="widget clearfix">
					<!-- -->
					<div class="row">
						<div class="col-md-5 col-sm-12 col-xs-12 bottommargin-sm widget_links">
							<h4 class="mb10">Admissions</h4>
							<ul>
								<li><a href="//www.lpu.in/admission/admissions.php"> Admissions 2019 - 20 </a>
								</li>
								<li><a href="//www.lpu.in/international/international_students.php"> International Admissions 2019 - 2020 </a>
								</li>
								<li><a target="_blank" href="//www.lpude.in/admissions/overview.php">Distance Education Admissions</a>
								</li>
								<li><a href="//www.lpu.in/scholarship/scholarship.php">Scholarship</a>
								</li>
								<li><a title="Fee Deposit" href="//www.lpu.in/frmloginaccounts.aspx">Fee Deposit</a>
								</li>
								<li><a title="Top Engineering Courses (B.Tech - M.Tech)" href="//www.lpu.in/engineering/" target="_blank">
								Top Engineering Courses</a>
								</li>
							</ul>
							<h4 class="mb10 mt20">Media</h4>
							<ul>
								<li><a href="//www.lpu.in/tv-ads.php">TV Ads</a>
								</li>
								<li class="hide"><a href="//www.lpu.in/print-ads.php">Print Ads</a>
								</li>
								<li><a href="//www.lpu.in/newshome.aspx">Media Coverage</a>
								</li>
							</ul>
						</div>
						<div class="col-md-4 col-sm-12 col-xs-12 bottommargin-sm widget_links">
							<h4 class="mb10">Other Links:</h4>
							<ul>
								<li><a href="//alumni.lpu.in" target="_blank"> Alumni </a>
								</li>
								<li><a href="//www.lpu.in/campus_life/entrepreneurship.php"> Entrepreneurship </a>
								</li>
								<li class="hide"><a href="//www.lpu.in/campus_life/campus-events.php"> Events </a>
								</li>
								
								
								<li><a href="//www.lpu.in/EventCertificate/index.aspx"> Download Event Certificate </a>
								<li><a href="//www.lpu.in/authenticate" target="_blank" title="Certificate Authentication">Certificate Authentication</a>
								</li>
								<li><a target="_blank" title="Fee Deposit" href="//nad.gov.in/">National Academic Depository</a>
								</li>
								<li><a href="//www.lpu.in/jpd" target="_blank" title="Joint Placement Drive">Joint Placement Drive</a>
								</li>
								<li> <a data-toggle="modal" data-target="#convocation" href="#">9th Convocation Gallery</a> </li>
								<li> <a href="//www.lpu.in/knowledge-brain-storm/index.php">Knowledge Brainstorm</a> </li>
								<li> <a href="" class="" data-toggle="modal" data-target="#nirf">NIRF</a>
								</li>
								<li> <a href="//www.lpu.in/lpusummerschool/index.php">LPU Summer School 2018</a> </li>
							</ul>
						</div>


						<div class="col-md-3 col-sm-12 col-xs-12  widget_links">

							<h4 class="mb10">&nbsp;</h4>
							<ul>
							<li> <a href="//schools.lpu.in" target="_blank">Schools.lpu.in</a> </li>
								<li><a id="bt-notification" href="#" data-toggle="modal" data-target="#myLargeModal">Education Awards</a>
								</li>
								<li> <a href="//www.lpu.in/explorica/index.php" target="_blank">Explorica</a> </li>
								<li> <a href="//www.lpu.in/downloads/ssr.pdf" target="_blank">LPU SSR</a> </li>
								<li> <a href="https://ums.lpu.in/lpuums/" target="_blank">Parent's Login</a> </li>
								<li> <a href="https://ums.lpu.in/lpuums/" target="_blank">UMS Login</a>
								</li>
								<li><a href="//www.lpu.in/about_lpu/tour_lpu.php" target="_blank">Campus Visit</a>
								</li>
								<li><a href="//www.lpu.in/jobs/jobs_at_lpu.php" target="_blank">Jobs At LPU</a>
								</li>
								<li><a href="//www.lpu.in/contact_us/contact-us.php" target="_blank">Contact</a> </li>
								<li><a href="https://docs.google.com/forms/d/e/1FAIpQLScHTG-vQoSOKIRPGnuNZ2bc66M6BOpJXOxBUxOFAUdfz35UkA/viewform" target="_blank">Supplier Registration</a>
								</li>
								<!--<li><a href="//www.lpu.in/downloads/Corigendum-Indian-Express-29-8-18.html" target="_blank">Corrigendum</a></li>-->
						</div>
					</div>
					
				</div>
			</div>
			<div class="col-md-3 col-sm-12 col-xs-12">				
				<div class="widget clearfix" style="margin-bottom: -20px;">
					<div class="row">
						<div class="col-md-12 clearfix bottommargin-sm">
							<a href="//www.lpu.in/about_lpu/tour_lpu.php" style="margin-right: 10px;">
                				<img width="auto" height="auto" src="//www.lpu.in/images/360.gif"> 
              				</a>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 clearfix">
							<h4 class="mt0 pr10" style="display:inline;float:left">Download App</h4>
							<div style="display:inline;float:left">
								<a title="Appstore" class="social-icon si-rounded si-appstore" href="https://itunes.apple.com/in/app/lputouch/id509819753?mt=8" target="_blank">
							<i class="icon-appstore"></i>
							<i class="icon-appstore"></i>
						</a>
						<a title="Android" class="social-icon si-rounded si-android" href="https://play.google.com/store/apps/details?id=ums.lovely.university&hl=en" target="_blank">
							<i class="icon-android"></i>
							<i class="icon-android"></i>
						</a>							
							</div>
							<div class="clearfix"></div>
								<div class="col-md-12 col-sm-12 col-xs-12 pl0 widget_links">
              <div class="mb10">Subscribe Newsletter</div>
            <!-- <p class="mb0">Stay updated about latest happenings, events and campus news</p>-->
          <div id="widget-subscribe-form-result" data-notify-type="success" data-notify-msg=""></div>
          <div id="widget-subscribe-form-result2" data-notify-type="error" data-notify-msg=""></div>
			
			<div class="widget subscribe-widget clearfix mt15 mb15">
				<form id="widget-subscribe-form" action="#" role="form" method="post" class="nobottommargin">
					<div class="input-group divcenter">
						<span class="input-group-addon"><i id="spinner" class="icon-email2"></i></span>
							<input style="height:32px;" type="email" id="widget-subscribe-form-email" name="email" class="form-control required email plr6" placeholder="Enter your Email">
							<span class="input-group-btn">
								<button class="btn btn-success plr6" id="subs-btn" type="submit">Go</button>
							</span>
								</div>
							</form>
						</div>
		
            </div>
							
							
							<div>
								<span title="Tel"><strong>Tel:</strong></span> +91-1824-404404 <br>
								<span title="Toll Free"><strong>Toll Free:</strong></span> 1800 102 4431<br>
								<!--<span title="Helpline"><strong>Helpline:</strong></span> 01824 444545<br>-->
							</div>
							<div class="col_last tleft mt20">
								<div class="fleft clearfix">
									<div class="fleft">
										<a href="https://www.facebook.com/LPUUniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-facebook">
										<i class="icon-facebook"></i>
										<i class="icon-facebook"></i>
									  </a>
										<a href="https://twitter.com/lpuuniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										  </a>
										<a href="https://plus.google.com/+LpuIn-lovely-professional-university/posts" target="_blank" class="social-icon si-small si-borderless nobottommargin si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										  </a>
										<a href="https://www.linkedin.com/company/lovely-professional-university" target="_blank" class="social-icon si-small si-borderless nobottommargin si-linkedin">
											<i class="icon-linkedin"></i>
											<i class="icon-linkedin"></i>
										  </a>	
										<a href="https://www.youtube.com/user/LPUuniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-gplus">
											<i class="icon-youtube"></i>
											<i class="icon-youtube"></i>
										  </a>
									</div>
									<div class="clear"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- .footer-widgets-wrap end -->

	</div>
	
			<!-- Copyrights
			============================================= -->
	<div id="copyrights" style="padding:10px 0">
		<div class="container clearfix">
			<div class="row clearfix">
				<div class="col-md-6 col-sm-12">
					<div class="copyrights-menu copyright-links clearfix">
						<!--Copyrights &copy; 2014 All Rights Reserved by Canvas Inc.<br>-->
						<img width="auto" height="auto" src="//www.lpu.in/images/footer-widget-logo.png" alt="" class="alignleft" style="margin-top: 20px; padding-right: 18px; border-right: 1px solid #4A4A4A;"/>
						<p class="pt15 mb0">
							India's Largest University* <strong>Lovely Professional University</strong>, Jalandhar-Delhi, G.T. Road, Phagwara, Punjab (INDIA) -144411.<br/>Website: //www.lpu.in
						</p>
					</div>
				</div>
				<div class="col-md-6 col-sm-12 tright hidden-xs mt15">
					<div class="fright clearfix">
						<div class="copyrights-menu copyright-links nobottommargin">
							<a href="//www.lpu.in/downloads/Ragging.pdf" target="_blank">Anti-Ragging</a>/ <a style="cursor:pointer" target="_blank" data-toggle="modal" data-target="#sexual-harrassment-footer">ICCASH</a>/ <a href="//www.lpu.in/privacy.php">Privacy Policy</a>/ <a href="//www.lpu.in/disclaimer.php">Disclaimer</a> / <a href="//www.lpu.in/downloads/student-grievance-redressal-policy.pdf">Student Grievance Redressal</a> / <a href="#">RTI</a> / Problem with this page ? <a href="mailto:webmaster@lpu.co.in?subject=Mail from lpu.in Website">Contact Webmaster</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- #copyrights end -->
</footer>

	<!-- sexual-harrassment-footer modal start -->
	<div id="sexual-harrassment-footer" class="modal fade" role="dialog">
  <div class="modal-dialog modal-dialog-centered">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ICCASH</h4>
      </div>
      <div class="modal-body">
        <ol class="mt20 ml20 iccash"><li> <a href="https://www.lpu.in/downloads/sexual-harrassment-of-women-act-and-rules-2013.pdf" target="_blank"> The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013</a></li>
<li> <a href="https://www.lpu.in/downloads/UGC_regulations-harassment.pdf"  target="_blank">UGC ( Prevention, Prohibition and Redressal of sexual harassment of Women employees and students in Higher Educational Institutions ) Regulations, 2015</a></li>

<li> <a href="https://www.lpu.in/downloads/handbook-for-prevention-of-sexual-harassment%20at-workplace.pdf"  target="_blank">Handbook on Sexual Harassment of Women at Workplace issued by the Ministry of Women and Child Development, Government of India</a></li>
<li><a href="https://www.lpu.in/downloads/composition-of-ICCASH.pdf"  target="_blank"> Composition of Internal Complaints Committee against Sexual harassment</a></li>
<li> "Sexual Harassment Complaint Registration: - <a href="mailto:iccash@lpu.co.in" target="_top">iccash@lpu.co.in</a> </li>
<li><a href="//www.lpu.in/downloads/Anti-Sexual-Harrasment-policy.pdf" target="_blank">Anti Sexual Harrasment Policy</a> </li>

</ol>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
		<!-- sexual-harrassment-footer modal end -->




<!-- Go To Top -->
<div id="gotoTop" class="icon-angle-up"></div>
<!-- start intake top bar -->
<div id="intake" class="modal fade mt50" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-body mt30">
				<h4 class="text-center mb0"><strong>Admissions for 2017-2018 are closed, except for the following programmes.</strong><br></h4>
				<div class="col-md-12 pa0 mt20">
					<div class="col-md-12">
						<div class="title-block">
							<h4>B.Ed.</h4>
							<span>
								<a href="//admission.lpu.in/" target="_blank" class="more-link">Click Here</a>
							</span>
							<br> The last date to apply for admission is 31st August 2017.
						</div>
					</div>
					<div class="col-md-12">
						<div class="title-block">
							<h4> Integrated B.Ed. - M.Ed.</h4>
							<span>
								<a href="//admission.lpu.in/" target="_blank" class="more-link">Click Here</a>
							</span>
							<br> The last date to apply for admission is 31st August 2017.
						</div>
					</div>
					To enquire for admission in programmes other than mentioned above, <a href="//www.lpu.in/contact_us/contact-us.php" class="btn btn-default btn-xs">Click Here</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<div class="modal1 mfp-hide" id="disciplines-popup">
	<div class="block divcenter disciplines-popup" style="background-color: #FFF; width: 80%;">
		<div class="row nomargin clearfix">
			<div class="col-sm-12 col-padding pa30">
				<div class="heading-block center mb30">
					<h2>Disciplines / Departments</h2> </div>
				<table id="dexample" class="display" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electronics &amp; Communication Engg. (ECE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/business/" target="_blank">Management</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/pharmaceutical-sciences/" target="_blank">Pharmaceutical Sciences</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/computer-science-engineering/" target="_blank">Computer Science &amp; Engineering (CSE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/business/" target="_blank">Commerce</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/computer-science-engineering/" target="_blank">Information Technology (IT)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/business/" target="_blank">Economics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physiotherapy-and-paramedical-sciences/" target="_blank">Physiotherapy</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electronics &amp; Computer Engineering</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/law/" target="_blank">Law</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physiotherapy-and-paramedical-sciences/" target="_blank">Medical Laboratory Sciences</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">Mechanical Engineering (ME)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/hotel-management-and-tourism/" target="_blank">Hotel Management and Tourism</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biotechnology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">ME - Mechatronics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Architecture</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Microbiology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">Aerospace Engineering</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Planning</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Forensic Sciences</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Interior &amp; Furniture Design</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biochemistry</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Product &amp; Industrial Design</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Botany</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">Automobile Engineering (AE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/fashion-design/" target="_blank">Fashion Design</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Zoology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electrical Engineering (EE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Multimedia &amp; Animation</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Chemistry</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electrical and Electronics Engineering (EEE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Journalism &amp; Film Production</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Physics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/civil-engineering/" target="_blank">Civil Engineering (CE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Fine Arts</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Mathematics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biotechnology (BT)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Performing Arts</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Arts (Humanities)</a>
							</td>
						</tr>
						
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Psychology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">English and Foreign Languages</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biomedical Engineering</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Sociology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Indian Languages</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Chemical Engineering (CHE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">History</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Public Administration</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">CHE - Petroleum</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Political Science</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/polytechnic/" target="_blank">Polytechnic</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Geography</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Library Science</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/computer-applications/" target="_blank">Computer Applications</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/agriculture/" target="_blank">Food Technology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/education/" target="_blank">Education</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/agriculture/" target="_blank">Agriculture</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/agriculture/" target="_blank">Nutrition and Dietetics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-education/" target="_blank">Physical Education</a>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!-- Modal noti start -->
<div class="modal fade" id="myLargeModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" id="modal-width">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title upcom text-center" id="myLargeModalLabel">Events</h4>
				<!--<h4 class="modal-title upcom1 text-center">Knowledge BrainStorm</h4>-->
			</div>
			<div class="modal-body" id="single-modal">
				<div id="noti" class="row clearfix">
				
				
				
				
				
				<!--start3rd-->
					<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/studygrant.jpg" alt="studygrant">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
							<strong>Benefits of Taking LPUNEST</strong><br>
								Now qualifying LPUNEST can also get you an assured study grant of upto Rs. 3 Lac per student to study at IITs/ NITs/ IIMs/ NLUs / IHMs/ NIDs/ IIT( DoD/ IDC)/ IIITDM/ NIFTs. <strong>OR</strong> Get admission into LPU programmes and avail scholarship of upto Rs. 5 Lac per student.
							</p>
							<div class="text-center">								
							
								
								<a class="button button-small active button-border button-rounded" href="//www.lpu.in/studygrant/index.php" target="_blank">Read More</a>

							</div>
						</div>
					</div>
					<!--end3rd-->
				
				
					<!--start3rd-->
					<!--<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/knowledge.jpg" alt="knowledge-brain-storm">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
								<strong>“Knowledge Brainstorm” (KBS),</strong> conducted under Transforming Education Awards for school students of North Eastern states, has proved to be the most preferred aptitude test for the young minds. KBS has been designed to examine the general skills, critical thinking, analytical skills, and intellectual promise of school students.
							</p>
							<div class="text-center">								
							
								
								<a class="button button-small active button-border button-rounded" href="//www.lpu.in/knowledge-brain-storm/index.php" target="_blank">Read More</a>

							</div>
						</div>
					</div>-->
					<!--end3rd-->
					
					<!--start3rd-->
					<!--<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5 col-md-6">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/convocation.jpg" alt="FRESHMEN INDUCTION 2018" style="opacity: 1;">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
								<strong>9th Convocation on 22nd October 2018</strong><br> Lovely Professional University solicit your presence on the occasion of the “9th Annual Convocation Ceremony” for the class of 2017 and 2018 scheduled for Monday 22nd of October 2018 at 1000 hrs. Shri M. Venkaiah Naidu, Hon’ble Vice-President of India, has very kindly consented to be the Chief Guest and deliver the Convocation Address. 
							</p>
							<div class="text-center">	
								<a class="button button-small active button-border button-rounded" href="convocation/index.aspx" target="_blank">Read More </a>
							</div>
						</div>
					</div>-->
					<!--end3rd-->
					
					
					<!--start3rd-->
					<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5 col-md-6">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/educationawards.jpg" alt="AIU 2018" style="opacity: 1;">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
								<strong>Transforming Education Awards</strong><br>After the grand success of its first edition, the 2nd Edition of Transforming Education Awards is slated to be a much better affair as compared to last year. Upload a video of your inspiring teacher and win a grant of Rs. 50000 for your school, award of Rs. 25000 for your Teacher, and Rs. 10000 for yourself.   
							</p>
								<div class="text-center">	
								<a class="button button-small active button-border button-rounded" href="https://www.lpu.in/educationawards" target="_blank">Read More </a>
							</div>
						
						</div>
					</div>
					<!--end3rd-->
					
					
				</div>
			</div>
		</div>
	</div>
</div>

<!--<div class="modal fade" id="nirf" role="dialog">
	<div class="vertical-alignment-helper">
		<div class="modal-dialog vertical-align-center">
			<div class="modal-content cent">
				<div style="background-color:#2985c6;" class="modal-header">
					<button type="button" style="color:#fff; opacity:1;" class="close" data-dismiss="modal">&times;</button>
					<h4 style="background:#2985c5; color:#fff;" class="modal-title">NIRF</h4>
				</div>
				<div class="modal-body">
				<h4 class="text-center mt15 border-bottom">2018</h4>
					<ul class="iconlist nirf" style="margin-top:20px;">
						<li><a href="https://www.lpu.in/downloads/nirf/Architecture.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture<br></a>
						</li>
						<li><a href="https://www.lpu.in/downloads/nirf/Management.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a>
						</li>
						<li><a href="https://www.lpu.in/downloads/nirf/Pharmacy.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a>
						</li>
						
					</ul>
					<h4 class="text-center mt15 border-bottom">2019</h4>
					
					<ul class="iconlist nirf" style="margin-top:20px;">
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Engineering</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Overall</a></li>
						
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>-->

<div class="modal fade" id="nirf" role="dialog">
	<div class="vertical-alignment-helper">
		<div class="modal-dialog vertical-align-center">
			<!-- Modal content-->
			<div class="modal-content cent">
				<div style="background-color:#2985c6;" class="modal-header">
					<button type="button" style="color:#fff; opacity:1;" class="close" data-dismiss="modal">&times;</button>
					<h4 style="background:#2985c5; color:#fff;" class="modal-title">NIRF</h4>
				</div>
				<div class="modal-body">
				
						<div class="tabs tabs-bb clearfix" id="tab-9">

							<ul class="tab-nav clearfix">
								<li><a href="#tabs-33">2018</a></li>
								<li><a href="#tabs-34">2019</a></li>
							</ul>

							<div class="tab-container">

								<div class="tab-content clearfix" id="tabs-33">
									<ul class="iconlist nirf" style="margin:0 0 0 30px;">
										<li><a href="https://www.lpu.in/downloads/nirf/Architecture.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture<br></a>
										</li>
										<li><a href="https://www.lpu.in/downloads/nirf/Management.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a>
										</li>
										<li><a href="https://www.lpu.in/downloads/nirf/Pharmacy.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a>
										</li>
										
									</ul>
								</div>
								<div class="tab-content clearfix" id="tabs-34">
									<ul class="iconlist nirf" style="margin:0 0 0 30px">
										<li><a href="https://www.lpu.in/downloads/nirf/Architecture-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Management-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Pharmacy-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Engineering-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Engineering</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Overall-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Overall</a></li>										
									</ul>
								</div>
								

							</div>

						</div>

				</div>
				<div class="modal-footer">
					<ul class="iconlist text-center nirf" style="margin:0 !important;">
					<li class="nirf-hd">Email ID for Comments & Feedback : <span>registrar@lpu.co.in</span>
						</li>
					</ul>
				  </div>
			</div>
		</div>
	</div>
</div>






<div class="modal fade" id="convocation" role="dialog">
	<div class="modal-dialog modal-lg modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<div class="modal-title" style="font-size:18px; font-weight:400; color:#232020;"><b>9th Convocation</b></div>
			</div>
			<div class="modal-body">
				The photographs of the students, who attended the 9th Convocation are attached under the following links. Students can download the photographs based on the line number allocated to them, for the ceremony.
				<div class="col-md-12 pa0 mt20">
					<div class="col-md-12">
						<div class="title-block">
							<h4>Convocation (Gold Medalist and Ph.D)</h4>
							<span>
								<a href="https://photos.app.goo.gl/rc8kQAN5wERJhrLA7" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="divider mt10 mb10"><em class="icon-circle"></em>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 1)</h4>
							<span>
								<a href="https://photos.app.goo.gl/TUxf8rNFqDHMhphw5" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 2)</h4>
							<span>
								<a href="https://photos.app.goo.gl/hiHDZi2p45nvB4az6" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
				</div>
				<div class="divider mt10 mb10"><em class="icon-circle"></em>
				</div>
				<div class="col-md-12 pa0">
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 3)</h4>
							<span>
								<a href="https://photos.app.goo.gl/8efLx5unJD5AML3C9" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 4)</h4>
							<span>
								<a href="https://photos.app.goo.gl/AhpHq8WZhNU6pTEt7" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
				</div>
				<div class="divider mt10 mb10"><em class="icon-circle"></em>
				</div>
				<div class="col-md-12 pa0">
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 5)</h4>
							<span>
								<a href="https://photos.app.goo.gl/sHJLeF4z61nAsvUh7" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 6)</h4>
							<span>
								<a href="https://photos.app.goo.gl/nFQJppXSfGpYe4XBA" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<input type='hidden' id='getday' value="Wednesday" />


<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" defer></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" type="text/css"/>
<script src="//www.lpu.in/js/jquery.popupwindow.js" defer></script>

<script type="text/javascript">

            function isValidEmailAddress(emailAddress) {
            var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
            return pattern.test(emailAddress);
            }
         

          

	$(document).ready(function() {
		
	 $("#subs-btn").click(function () {
            if (!isValidEmailAddress($("#widget-subscribe-form-email").val())) {
            $('#widget-subscribe-form-result2').attr('data-notify-msg', 'Please enter a valid email address');
            SEMICOLON.widget.notifications($('#widget-subscribe-form-result2'));
            }
            else {
            $("#spinner").removeClass('icon-email2').addClass('icon-line-loader icon-spin');
            var id = $("#widget-subscribe-form-email").val();
            $.ajax({
            url: "../SubscribeNewsletter.asmx/Subscribe",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: "{email:'" + id + "'}",
            success: function (msg) {
            $("#spinner").removeClass('icon-line-loader icon-spin').addClass('icon-email2');
            $("#widget-subscribe-form-email").val('');
            if(msg.d=="success")
            {

            $('#widget-subscribe-form-result').attr('data-notify-msg', 'You have successfully subscribed');
            SEMICOLON.widget.notifications($('#widget-subscribe-form-result'));

            }
            else if(msg.d=="error")
            {
            $('#widget-subscribe-form-result2').attr('data-notify-msg', 'You have already subscribed');
            SEMICOLON.widget.notifications($('#widget-subscribe-form-result2'));

            }
            },
            error: function () {
            $("#widget-subscribe-form-email").val('');
            $("#spinner").removeClass('icon-line-loader icon-spin').addClass('icon-email2');
            }
            });
            return false;

            }
            });
			
		// $( "#educationawards" ).click( function () {
			// $( ".upcom" ).addClass( "hide" );
			// $( ".upcom1" ).removeClass( "hide" );
			// $( ".brainstorm" ).css( "display", "none" );
			// $( "#modal-width" ).removeClass( "double-modal" );
			// $( "#modal-width" ).addClass( "single-modal" );
			// $( ".diff-popup" ).removeClass( "col-md-4" );
			// $( ".diff-popup" ).removeClass( "col-61" );
			// $( ".diff-popup" ).removeClass( "col-md-6" );
		// } );


		$( "#bt-notification" ).click( function () {
			$( ".brainstorm" ).css( "display", "" );

			$( ".upcom" ).removeClass( "hide" );
			$( ".upcom1" ).addClass( "hide" );
			//$(".diff-popup").addClass("col-md-4");
			//$( "#modal-width" ).addClass( "double-modal" );
			//$("#modal-width").addClass("double-modal");
			//$( "#modal-width" ).removeClass( "single-modal" );
			$( ".diff-popup " ).addClass( "col-md-6" );

		} );
		$( "#footer" ).removeAttr( "style" );
		var pathname = window.location.pathname;
		var str_array = pathname.split( '/' );
		if ( str_array[ 1 ].replace( /^\s*/, "" ).replace( /\s*$/, "" ) == "international" ) {
			//alert('Number1');
			$( ".international" ).show();
			$( ".si-whatsapp" ).attr("href","https://api.whatsapp.com/send?phone=+919876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202019.");
			$( ".call" ).hide();
			$( ".ltown" ).hide();
		} else {
			$( ".international" ).hide();

			//Whatsapp Number change
			if ( $('#getday').val() == "Monday" || $('#getday').val() == "Wednesday" || $('#getday').val() == "Friday" ) {
				//alert('Number1');
				$( ".si-whatsapp" ).attr("href","https://api.whatsapp.com/send?phone=+919876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202019.");
				$( ".si-whatsapp" ).attr("title","Whatsapp only +919876022222");
			} else {
				//alert('Number2');
				$( ".si-whatsapp" ).attr("href","https://api.whatsapp.com/send?phone=+919876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202019.");
				$( ".si-whatsapp" ).attr("title","Whatsapp only +919876022222");
			}
		}

		$( '#dexample' ).DataTable( {
			scrollY: 500,
			"paging": false,
			"ordering": false,
			"info": false
		} );

		var numItems = $( '#single-modal .col-md-4' ).length;
		//alert(numItems);
		if ( numItems <= 3 ) {
			$( '#myLargeModal' ).addClass( 'm10' );

		}
		if ( numItems > 3 ) {
			$( '#myLargeModal' ).addClass( 'm3' );
		}
		if ( numItems == 1 ) {
			$( '#modal-width' ).addClass( 'single-modal' );
			$( '#noti .col-md-4' ).addClass( 'col-12' );
		}
		if ( numItems == 2 ) {
			$( '#modal-width' ).addClass( 'double-modal' );
			$( '#noti .col-md-4' ).addClass( 'col-61' );
		}
		var sWidth = $( window ).width();
		if ( sWidth < 770 ) {
			$( '#noti .col-md-4' ).removeClass( 'pl7' );
			$( '#noti .col-md-4' ).removeClass( 'pr7' );
			if ( numItems == 1 ) {
				$( '#modal-width' ).removeClass( 'single-modal' );
				$( '#noti .col-md-4' ).removeClass( 'col-12' );
			}
			if ( numItems == 2 ) {
				$( '#modal-width' ).removeClass( 'double-modal' );
				$( '#noti .col-md-4' ).removeClass( 'col-61' );
			}
		}
	} );

	function homeToast( vtype, vtitle, vmsgtext, vNavigationUrl, type ) {
		if ( type == "link" ) {
			toastr.options = {
				"closeButton": true,
				"debug": false,
				"newestOnTop": true,
				"progressBar": true,
				"positionClass": "toast-top-left",
				"preventDuplicates": true,
				//"onclick": daljit(),
				onclick: function () {
					window.open( vNavigationUrl, '_blank' );
				},
				"showDuration": "12000",
				"hideDuration": "1000",
				"timeOut": "10000",
				"extendedTimeOut": "1000",
				"showEasing": "swing",
				"hideEasing": "linear",
				"showMethod": "fadeIn",
				"hideMethod": "fadeOut"
			}
			toastr[ vtype ]( vmsgtext, vtitle )
		} else if ( type == "popup" ) {
			toastr.options = {
				"closeButton": true,
				"debug": false,
				"newestOnTop": true,
				"progressBar": true,
				"positionClass": "toast-top-left",
				"preventDuplicates": true,
				onclick: function () {
					$( "#" + vNavigationUrl ).trigger( "click" );
				},
				"showDuration": "12000",
				"hideDuration": "1000",
				"timeOut": "10000",
				"extendedTimeOut": "1000",
				"showEasing": "swing",
				"hideEasing": "linear",
				"showMethod": "fadeIn",
				"hideMethod": "fadeOut"
			}
			toastr[ vtype ]( vmsgtext, vtitle )
		}
	}

	function setModalMaxHeight( element ) {
		this.$element = $( element );
		this.$content = this.$element.find( '.modal-content' );
		var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
		var dialogMargin = $( window ).width() < 768 ? 20 : 60;
		var contentHeight = $( window ).height() - ( dialogMargin + borderWidth );
		var headerHeight = this.$element.find( '.modal-header' ).outerHeight() || 0;
		var footerHeight = this.$element.find( '.modal-footer' ).outerHeight() || 0;
		var maxHeight = contentHeight - ( headerHeight + footerHeight );

		this.$content.css( {
			'overflow': 'hidden'
		} );

		this.$element
			.find( '#myLargeModal .modal-body' ).css( {
				'max-height': maxHeight,
				'overflow-y': 'auto'
			} );
	}

	$( '.modal' ).on( 'show.bs.modal', function () {
		$( this ).show();
		setModalMaxHeight( this );
	} );

	$( window ).resize( function () {
		if ( $( '.modal.in' ).length != 0 ) {
			setModalMaxHeight( $( '.modal.in' ) );
		}
	} );
	$( '.ppwnd' ).on( 'click', function ( event ) {
		event.preventDefault();
		$.popupWindow( '//www.lpu.in/ClickToCall.php', {
		//$.popupWindow( '//172.17.60.228/ClickToCall.php', {
			width: 420,
			height: 630
		} );
	} );
</script>
<div style="display:none !important">

<!-- ===================================================== -->
<!-- Description of the code :Google Analytics -->
<!-- Applied Date: 06-Mar-2018 format  ( 05-Mar-2018 )  -->
<!-- Applicable for  Year: 2018 -->
<!-- Required Till: Permanent or Possible Month-Year till code is required -->
<!-- Source Agency : AdGlobal Etc -->
<!-- Contact Person : Abha  -->
<!-- ===================================================== -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-8319620-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-8319620-1');
</script>
<!-- ============ End Of Code  ============================== -->

<!-- ===================================================== -->
<!-- Description of the code :AMO Code -->
<!-- Applied Date: 06-Mar-2018 format  ( 05-Mar-2018 )  -->
<!-- Applicable for  Year: 2018 -->
<!-- Required Till: Permanent or Possible Month-Year till code is required -->
<!-- Source Agency : AdGlobal Etc -->
<!-- Contact Person : Abha  -->
<!-- ===================================================== -->
<img src="//pixel.everesttech.net/px2/5453?px_evt=t&ev_Landing_Page=1" width="1" height="1"/>
<!-- ============ End Of Code  ============================== -->
</div>
 </div> 
<script src="//www.lpu.in/js/functions.js"></script>   

</body>
</html>


  
