<!doctype html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title>
		LPUNEST Study Scholarship and Grants for Students - Apply Now
	</title>
	<meta name="description" content="Apply now for LPUNEST and take the benefits of LPUNEST. Get study grant of upto Rs. 3 Lac per student to study at IITs/ NITs/ IIMs/ NLUs/ IHMs/ NIDs/ IITs (IDC/DoD)/ IIITDM/ NIFTs . Get admission into LPU  Programmes and avail Scholarship up to Rs. 5 Lac per student."/>	
	<!-- Stylesheets============================================= -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700" rel="stylesheet">
	<link rel="stylesheet" href="../css/font-icons.css" type="text/css"/>
	<link rel="stylesheet" href="../css/nest-custom-new.css" type="text/css"/>
	<link rel="stylesheet" href="//www.lpu.in/css/bootstrap.css" type="text/css"/>
	<link rel="stylesheet" href="//www.lpu.in/style.css" type="text/css"/>
	<link rel="stylesheet" href="//www.lpu.in/css/dark.css" type="text/css"/>
	<link rel="stylesheet" href="//www.lpu.in/css/animate.css" type="text/css"/>
	<link rel="stylesheet" href="//www.lpu.in/css/magnific-popup.css" type="text/css"/>
	<link rel="stylesheet" href="//www.lpu.in/css/vmap.css" type="text/css"/>
	<link rel="stylesheet" href="//www.lpu.in/css/responsive.css" type="text/css"/>
	<link rel="stylesheet" href="//www.lpu.in/css/home-custom.css" type="text/css"/>
	<link rel="stylesheet" href="//www.lpu.in/css/radio-checkbox.css" type="text/css"/>
	<link rel="stylesheet" href="//www.lpu.in/css/sweetalert2.min.css" type="text/css"/>
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta name="author" content="LOVELY PROFESSIONAL UNIVERSITY"/>
	<!-- One Page Module Specific Stylesheet -->
	<!--<link rel="stylesheet" href="../one-page/onepage.css" type="text/css" />-->
	<!-- / -->
	<!-- External JavaScripts
	============================================= -->
<style type="text/css">
.modal {
  text-align: center;
  padding: 0!important;
}
.modal:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle;
  margin-right: -4px;
}
.modal-dialog {
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}
@media (max-width: 768px){
.modal:before {
  content: '';
  display: inline-block;
  height: auto !important;
  vertical-align: top !important;
  margin-right: -4px;
}
.modal-dialog {
  display: block !important;
  vertical-align: top !important;
} 
.table-responsive > .table > thead > tr > th, .table-responsive > .table > tbody > tr > th, .table-responsive > .table > tfoot > tr > th, .table-responsive > .table > thead > tr > td, .table-responsive > .table > tbody > tr > td, .table-responsive > .table > tfoot > tr > td{ white-space: normal;}

}
</style>
	<style type="text/css">
	a{cursor: pointer;}
		body {
			background-color: #f6f6f6;
			color: #666666;
		}
		
		.think-big {
			float: right;
		}
		
		.mt50 {
			margin-top: 50px !important;
		}
		
		.mt40 {
			margin-top: 40px !important;
		}
		
		.select-programme {
			top: -110px;
			position: relative;
		}
		
		.box {
			-webkit-border-radius: 20px;
			-moz-border-radius: 20px;
			border-radius: 20px;
			background: #ffffff;
			text-align: center;
			cursor:pointer;
		}
		
		.radio-outer {
			position: relative;
			top: -22px;
			background: #fff;
			display: inline-block;
			border-radius: 50%;
			width: 45px;
			height: 45px;
			padding: 2px;
			-webkit-box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
			box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
		}
		
		.radio-style-3-label::before {
			border: 0 !important;
			color: #f58634 ! important;
			font-size: 24px;
			font-weight: normal;
		}
		
		.box-head {
			color: #303135;
			font-size: 16px;
			font-weight: bold;
			display: block;
		}
		
		.schedule-head {
			color: #303135;
			font-size: 24px;
			font-weight: bold;
		}
		
		.benefits-blue-text {
			color: #4592c5;
			font-size: 18px;
			line-height: 30px;
			padding: 130px 50px;
			background-color: #f6f6f6;
			text-align: center;
			-webkit-border-radius: 50%;
			-moz-border-radius: 50%;
			border-radius: 50%;
		}
		
		.circle .content {
			color: #4592c5;
			font-size: 18px;
			line-height: 30px;
			margin-top: -18%;
			display: block;
		}
		
		.box-head-img {
			display: block;
		}
		
		.box-sub-head {
			color: #666666;
			font-size: 14px;
			font-weight: normal;
			display: block;
		}
		
		.box-selectefd {
			-webkit-box-shadow: 0 5px 15px 1px #cccccc;
			box-shadow: 0 5px 15px 1px #cccccc;
		}
		
		.head-content h1 {
			font-size: 60px;
			font-weight: bold;
			color: #ffffff;
			line-height: 70px !important;
			margin-top: 20px;
		}
		
		.sub-head-content {
			font-size: 36px;
			font-weight: normal;
			color: #ffffff;
		}
		
		.select-programme-heading {
			font-size: 30px;
			font-weight: normal;
			color: #ffffff;
		}
		
		.montserrat-light {
			font-family: Montserrat Light;
		}
		
		.get-scholarship-now {
			font-size: 36px;
			font-weight: normal;
			color: #303135;
			text-align: center;
		}
		
		.sub-get-scholarship-now {
			font-size: 18px;
			font-weight: normal;
			color: #666666;
			text-align: center;
		}
		
		.form-text {
			font-size: 11px;
			font-weight: normal;
			color: #666666;
			text-transform: uppercase;
			letter-spacing: 0 !important;
			margin-bottom: 0px !important;
		}
		
		.text-box {
			background-color: #fafafa;
			height: 38px;
			-webkit-border-radius: 2px;
			-moz-border-radius: 2px;
			border-radius: 2px;
		}
		
		.bg-white {
			background-color: #ffffff;
		}
		
		.avail-benefits {
			font-size: 24px;
			font-weight: 500;
			color: #3589c0;
			text-align: center;
		}
		
		.form-padding {
			padding: 40px 70px;
		}
		
		.button-circle {
			border-radius: 26px;
		}
		
		.button-orange {
			background-color: #f58634;
			font-size: 16px;
			font-weight: bold;
			padding: 3px 35px 3px 35px;
			height: 45px;
		}
		
		.ok {
			background-color: #f58634;
			font-size: 16px;
			font-weight: bold;
			padding: 2px 25px 2 px 25px;
		}
		
		.button-orange-apply-now {
			background-color: #f58634;
			font-size: 16px;
			font-weight: bold;
			padding: 8px 35px 3px 35px;
			height: 55px;
		}
		
		.footer-content {
			color: #1085c5;
			font-size: 14px;
		}
		
		.text-coloe-blue {
			color: #3589c0;
			font-size: 14px;
		}
		
		.or {
			background-color: #3589c0;
			font-size: 12px;
			font-weight: bold;
			text-align: center;
			color: #ffffff;
			padding: 8px;
			width: 35px;
			height: 35px;
			-webkit-border-radius: 50%;
			-moz-border-radius: 50%;
			border-radius: 50%;
			margin: 0 auto;
		}
		
		.or-bg {
			padding-top: 17.75%;
		}
		
		.border-zero {
			border: 0px !important
		}
		
		.modal-heading {
			font-size: 24px;
			color: #333333;
		}
		
		.close {
			color: #666666;
			font-size: 35px;
			font-weight: normal;
			opacity: 1;
		}
		
		.close1 {
			color: #666666;
			font-size: 20px;
			font-weight: normal;
			opacity: 1;
			margin-top: -4px;
			position: absolute;
			right: 0;
			cursor: pointer;
		}
		
		.modal-footer {
			text-align: center !important;
		}
		
		.benefits-table {
			background: #FFF;
			padding: 0
		}
		
		.col-xs-15,
		.col-sm-15,
		.col-md-15,
		.col-lg-15 {
			position: relative;
			min-height: 1px;
			padding-right: 10px;
			padding-left: 10px;
		}
		
		.col-xs-15 {
			width: 20%;
			float: left;
		}
		
		.invalid {
			border: 1px solid #F44336;
		}
		
		.form-error {
			color: #F44336;
		}
		
		.circle {
			-webkit-border-radius: 100%;
			-webkit-background-clip: padding-box;
			-moz-border-radius: 100%;
			-moz-background-clip: padding;
			border-radius: 100%;
			background-clip: padding-box;
			text-align: center;
			display: block;
			height: 0;
			width: 100%;
			padding: 50% 10%;
			background: #f6f6f6;
		}
		
		.font-16 {
			font-size: 19px;
		}
		
		@media (max-width: 480px) {
			.form-padding {
				padding: 40px 15px;
			}
			.nest-logo {
				padding-bottom: 120px;
			}
		}
		
		@media (min-width: 768px) {
			.col-sm-15 {
				width: 20%;
				float: left;
			}
		}
		
		@media (max-width: 992px) {
			.benefits-table {
				background: #f6f6f6;
				padding: 20px 0
			}
			.circle {
				height: auto;
				padding: 0;
			}
			.or-bg {
				padding: 10px;
			}
			.circle .content {
				15px 0;
				margin-top: 0
			}
			.box {
				margin-bottom: 35px;
			}
			.head-content h1 {
				font-size: 25px;
				font-weight: bold;
				color: #ffffff;
				line-height: 30px !important;
				margin-top: 20px;
			}
			.sub-head-content {
				font-size: 18px;
				font-weight: normal;
				color: #ffffff;
			}
			.get-scholarship-now {
				font-size: 26px;
			}
			.select-programme-heading {
				font-size: 23px;
			}
		}
		
		@media (min-width: 992px) {
			.col-md-15 {
				width: 20%;
				float: left;
			}
		}
		
		@media (min-width: 1200px) {
			.col-lg-15 {
				width: 20%;
				float: left;
			}
		}
		
		@media (min-width: 992px)and (max-width:1200px) {
			.circle .content {
				font-size: 1.5vw;
			}
			.head-content h1 {
				font-size: 50px;
				font-weight: bold;
				color: #ffffff;
				line-height: 60px !important;
				margin-top: 20px;
			}
		}
	</style>
</head>

<body class="stretched">

	<!-- Document Wrapper
    ============================================= -->
	<div id="wrapper" class="clearfix">

		<section id="slider" class="" style="background: url(images/header.png) no-repeat; background-size: cover" data-height-xl="650" data-height-lg="650" data-height-md="650" data-height-sm="600" data-height-xs="550">
			<div class="container clearfix">
				<div class="col-md-12">
					<div class="col-md-6 col-xs-6 mt20"><img src="images/logo.png">
					</div>
					<div class="col-md-6 col-xs-6 mt35">
						<div class="think-big"><img src="images/think-big.png">
						</div>
					</div>

				</div>

				<div class="clearfix"></div>
				<div class="col-md-10 col-md-offset-1  col-xs-12 col-xs-offset-0 text-center head-content">
					<h1 class="mb10">Get a study grant of upto<br>
<span>Rs. 3 lac</span> per student</h1>
					<div class="sub-head-content"> to study at<br><span class="font-16"> IITs/ NITs/ IIMs/ NLUs/ IHMs/ NIDs/ IITs (IDC/DoD)/ IIITDM/ NIFTs, on qualifying</span>
					</div>
					<img class="mt40 nest-logo" src="images/nest-logo.png"> 
					
				</div>
			</div>

		</section>

		<!-- BOX Content Start-->
		<section class="container clearfix select-programme">
			<div class="select-programme-heading mb25">Select Your Programme</div>
			<div class="col-md-15">
				<div class="box bb" data-class="engineering">
					<div class="radio-outer">
						<input id="engineering" value="Engineering:12th" class="radio-style" name="radio-group-3" type="radio">
						<label for="engineering" class="radio-style-3-label"></label>
					</div>
					<div class="box-head-img"><img src="images/engineering.png">
					</div>
					<div class="box-head mt10">Engineering</div>
					<div class="box-sub-head mt10 pb30">IIT/ NIT</div>
				</div>
			</div>
			<div class="col-md-15">
				<div class="bb box" data-class="mba">
					<div class="radio-outer">
						<input value="Management:Graduation" id="mba" class="radio-style" name="radio-group-3" type="radio">
						<label for="mba" class="radio-style-3-label"></label>
					</div>
					<div class="box-head-img"><img src="images/management.png">
					</div>
					<div class="box-head mt10">Management</div>
					<div class="box-sub-head mt10 pb30">IIM</div>
				</div>
			</div>
			<div class="col-md-15">
				<div class="bb box" data-class="design">
					<div class="radio-outer">
						<input value="Design:12th" id="design" class="radio-style" name="radio-group-3" type="radio">
						<label for="design" class="radio-style-3-label"></label>
					</div>
					<div class="box-head-img"><img src="images/design.png">
					</div>
					<div class="box-head mt10">Design</div>
					<div class="box-sub-head mt10 pb30">NID/ NIFT/ IIT/ IIIT </div>
				</div>
			</div>
			<div class="col-md-15">
				<div class="bb box" data-class="law">
					<div class="radio-outer">
						<input value="Law:12th" id="law" class="radio-style" name="radio-group-3" type="radio">
						<label for="law" class="radio-style-3-label"></label>
					</div>
					<div class="box-head-img"><img src="images/law.png">
					</div>
					<div class="box-head mt10">LAW</div>
					<div class="box-sub-head mt10 pb30">NLU</div>
				</div>
			</div>
			<div class="col-md-15">
				<div class="bb box" data-class="hotel-management">
					<div class="radio-outer">
						<input value="HTLMGT:12th" id="hotel-management" class="radio-style" name="radio-group-3" type="radio">
						<label for="hotel-management" class="radio-style-3-label"></label>
					</div>
					<div class="box-head-img"><img src="images/hotel-management.png">
					</div>
					<div class="box-head mt10">Hotel Management</div>
					<div class="box-sub-head mt10 pb30">IHM</div>
				</div>
			</div>
		</section>
		<!-- BOX Content End-->

		<!-- Form Start-->
		<section class="container clearfix">
			<div class="get-scholarship-now">Get Scholarship Now</div>
			<div class="sub-get-scholarship-now mb30">Avail study grant of upto Rs. 3 lac per student</div>

			<div class="col-md-12 bg-white form-padding">
				<div id="otp" class="hide otp-div col-md-4 col-md-offset-4">
					<div id="closeotp" class="close1" style="display:none">x</div>


					<!-- content goes here -->
					<div class="portlet-body form text-center">
						<div class="sub-get-scholarship-now mb30">One Time Password</div>
						<form class="otp-form" id="otpform">

							<div class="input-group">
								<input type="password" placeholder="Enter One Time Password" class="form-control pwd" value="" required id="txtotp" name="otptextbox">
								<span class="input-group-btn">
													<button class="otp-btn btn reveal" id="otpbtn" type="button"><i class="icon-ok"></i></button>
												</span>
							
							</div>
							<div id="resentmsg" class="pt15">Wait for <span id="countersec"></span> seconds for OTP.<br/><span class="disabled" style="color:#CCC">Click Here to resend OTP</span>
							</div> <a id="rotp" class="pt15">Click Here to resend OTP</a>
						</form>
					</div>


				</div>

				<form id="frmSignUp" name="frmSignUp" class="schoolform clearfix mb0">





					<div class="row ">
						<div class="col-md-4 form-group">
							<label class="control-label form-text " for="f_name">Your name</label>
							<input class="form-control text-box" id="f_name" required name="f_name" type="text"/>
						</div>
						<div class="col-md-4 form-group">
							<label class="control-label form-text" for="f_email">Your email</label>
							<input class="form-control text-box" data-rule-required="true" data-msg-required="Email is required." data-rule-customemail="true" onblur="fun_RemoteCheckEmail(event)" type="email" id="f_email" required name="f_email" type="text"/>
						</div>


						<div class="col-md-4 form-group">
							<label class="control-label form-text" for="Gender">Gender</label><br>

							<label class="radio-inline">
      <input type="radio" required id="male" type='radio' name='Gender' value="M"><span class="radiogen">Male</span>
    </label>
						
							<label class="radio-inline">
      <input type="radio" id="female" type='radio' name='Gender' value="F"><span class="radiogen">Female</span>
    </label>
						



						</div>

					</div>
					<div class="row">
						<div class="col-md-4 form-group">
							<label class="control-label form-text" for="name">Your phone number</label>
							<input class="form-control text-box" onblur="fun_RemoteCheckPhone(event)" onkeypress="fun_KeyFilter(this, event, 'digit')" id="f_contactnumber" required name="f_contactnumber" type="text"/>
						</div>

						<div class="col-md-4 form-group">
							<label class="control-label form-text" for="name">Your state</label>
							<select required class="form-control psstate text-box" name="f_state" id="f_state">
								<option value="">Select State</option>
								<option value="Andaman And Nicobar">Andaman And Nicobar</option>
								<option value="Andhra Pradesh">Andhra Pradesh</option>
								<option value="Arunachal Pradesh">Arunachal Pradesh</option>
								<option value="Assam">Assam</option>
								<option value="Bihar">Bihar</option>
								<option value="Chandigarh">Chandigarh</option>
								<option value="Chhattisgarh">Chhattisgarh</option>
								<option value="Dadra And Nagar Hav">Dadra And Nagar Hav</option>
								<option value="Daman And Diu">Daman And Diu</option>
								<option value="Delhi">Delhi</option>
								<option value="Goa">Goa</option>
								<option value="Gujarat">Gujarat</option>
								<option value="Haryana">Haryana</option>
								<option value="Himachal Pradesh">Himachal Pradesh</option>
								<option value="Jammu And Kashmir">Jammu And Kashmir</option>
								<option value="Jharkhand">Jharkhand</option>
								<option value="Karnataka">Karnataka</option>
								<option value="Kerala">Kerala</option>
								<option value="Lakshadweep">Lakshadweep</option>
								<option value="Madhya Pradesh">Madhya Pradesh</option>
								<option value="Maharashtra">Maharashtra</option>
								<option value="Manipur">Manipur</option>
								<option value="Meghalaya">Meghalaya</option>
								<option value="Mizoram">Mizoram</option>
								<option value="Nagaland">Nagaland</option>
								<option value="Odisha">Odisha</option>
								<option value="Puducherry">Puducherry</option>
								<option value="Punjab">Punjab</option>
								<option value="Rajasthan">Rajasthan</option>
								<option value="Sikkim">Sikkim</option>
								<option value="Tamil Nadu">Tamil Nadu</option>
								<option value="Telangana">Telangana</option>
								<option value="Tripura">Tripura</option>
								<option value="Uttar Pradesh">Uttar Pradesh</option>
								<option value="Uttarakhand">Uttarakhand</option>
								<option value="West Bengal">West Bengal</option>
							</select>
						</div>
						<div class="col-md-4 form-group">
							<label class="control-label form-text" for="name">Select programme</label>
							<select required class="form-control psstate text-box" name="programme" id="programme">
								<option value="">Select programme</option>
								<option value="Engineering:12th">Engineering</option>
								<option value="Management:Graduation">Management</option>
								<option value="Design:12th">Design</option>
								<option value="Law:12th">Law</option>
								<option value="HTLMGT:12th">Hotel Management</option>
							</select>
						</div>
					</div>

					<div class="col-md-12 text-center">
						<button id="signup" class="button button-circle button-orange" type="submit" value="submit" name="template-contactform-submit">REGISTER NOW</button>


					</div>
				</form>
			</div>

		</section>


		<!-- Form end-->
		<!-- Benefits For Taking  LPUNEST Start-->
		<section class="bg-white clearfix mt50 pb50">
			<div class="get-scholarship-now mt50">Benefits For Taking LPUNEST</div>
			<div class="sub-get-scholarship-now mb30">National Entrance and Scholarship Test</div>
			<div class="container">
				<div class="col-md-12 benefits-table">
					<div class="col-md-5">
						<div class="circle">
							<span class="content">
		Get study grant of upto Rs. 3 Lac per student to study at IITs/ NITs/ IIMs/ NLUs/ IHMs/ NIDs/ IITs (IDC/DoD)/ IIITDM/ NIFTs
		<span>
		</div>
		</div>
		<div class="col-md-2 or-bg"><div class="or">OR</div></div>
		<div class="col-md-5">
		<div class="circle"><span class="content">Get admission into LPU Programmes and avail Scholarship up to Rs. 5 Lac per student.</span>
						
						</div>
					</div>
				</div>

				<!--<div class="col-md-12 mb30 mt30"><b>Note:</b> Above study grant is available for only those students who are taking admission in B.Tech./B.E./B.S. programmes
of the above mentioned institutes in 2019. </div>-->


			</div>
		</section>
		<!-- Benefits For Taking  LPUNEST End-->
		<section class="clearfix mt20 text-center pt30 pb20">
			<div class="col-md-12"> <img src="images/schedules-icon.png"> <span class="schedule-head ">LPUNEST Schedules </span>
				<p class="pl30 mb5">National Entrance and Scholarship Test will be conducted in 2 schedules:</p>
				<p class="pl30 mb5">Schedule I: <span class="text-coloe-blue"> 21st January to 05th February 2019</span>
				</p>
				<p class="pl30 mb5">Schedule II: <span class="text-coloe-blue"> 05th April to 30th April 2019</span>
				</p>

			</div>
		</section>



		<!-- Apply Now & Avail Benefits Start-->
		<section class="bg-white clearfix mt20">
			<div class="avail-benefits mt40">Apply Now & Avail Benefits</div>
			<div class="col-md-12 text-center mb50 mt25 pb15">
				<a href="https://admission.lpu.in" target="_blank" class="button button-circle button-orange-apply-now">Apply Now</a>
			</div>




		</section>
		<!-- Apply Now & Avail Benefits End-->



		<!--Footer Start -->

		<footer id="footer" class="dark remove-div pt10" style="background-color: #222;">
			<div id="copyrights" style="padding:10px 0">
				<div class="container clearfix">
					<div class="row clearfix">
						<div class="col-md-6 col-sm-12 mt20">
							<div class="copyrights-menu copyright-links clearfix">
								<!--Copyrights &copy; 2014 All Rights Reserved by Canvas Inc.<br>-->
								<img width="auto" height="auto" src="//www.lpu.in/images/footer-widget-logo.png" alt="" class="alignleft" style="margin-top: 20px; padding-right: 18px; border-right: 1px solid #4A4A4A;"/>
								<p class="pt15 mb0">
									India's Largest University* <strong>Lovely Professional University</strong>, Jalandhar-Delhi, G.T. Road, Phagwara, Punjab (INDIA) -144411.<br/>Website: //www.lpu.in
								</p>
							</div>
						</div>
						<div class="col-md-6 col-sm-12 tright mt15">

							<div class="fright clearfix ">
								<div class="fleft clearfix">
									<div class="fleft">
										<a href="https://www.facebook.com/LPUUniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-facebook">
										<i class="icon-facebook"></i>
										<i class="icon-facebook"></i>
									  </a>
									
										<a href="https://twitter.com/lpuuniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										  </a>
									
										<a href="https://plus.google.com/+LpuIn-lovely-professional-university/posts" target="_blank" class="social-icon si-small si-borderless nobottommargin si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										  </a>
									
										<a href="https://www.linkedin.com/company/lovely-professional-university" target="_blank" class="social-icon si-small si-borderless nobottommargin si-linkedin">
											<i class="icon-linkedin"></i>
											<i class="icon-linkedin"></i>
										  </a>
									
										<a href="https://www.youtube.com/user/LPUuniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-gplus">
											<i class="icon-youtube"></i>
											<i class="icon-youtube"></i>
										  </a>
									
									</div>
									<div class="clear"></div>
								</div>
							</div>
							<div class="clearfix"></div>
							<div class="fright col-md-12 mb30 clearfix">
								<div class="footer-content">
									Tel: +91-1824-404404 / Toll Free: 1800 102 4431<br> SMS LPU to 53030<br> Email: admissions@lpu.co.in
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- #copyrights end -->
		</footer>
		<!--Footer End -->


		<!-- Go To Top
	============================================= -->
		<div id="gotoTop" class="icon-angle-up"></div>

		<!-- External JavaScripts
	============================================= -->
		<script src="js/jquery.js"></script>
		<script src="js/plugins.js"></script>

		<!-- Footer Scripts
	============================================= -->
		<script src="js/functions.js"></script>

	</div>


	<!-- All Model Start-->
	<div id="engineering-model" class="modal fade" role="dialog">
		<div class="modal-dialog modal-lg">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">LPUNEST Study Grant for Engineering Programmes</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
					

						<!--
<strong class="modal-heading">LPU announces grand opportunity for aspiring engineers</strong><br>
  Study Grant of upto Rs. 2 Lac per student to 10 students from  every IIT & NIT on qualifying LPUNEST. LPUNEST (LPU National  Entrance and Scholarship Test) is not only a gateway to the Engineering  Programmes at LPU but in fact an <em>Entrance  Test for Life</em>. LPUNEST performance can lead to following objectives:

  <li><strong>Entrance  Test</strong> for Admission in LPU Engineering Programmes</li>
  <li><strong>Scholarship</strong> up to Rs. 5 Lac per for Admission in LPU</li>
  -->
						<ul class="list-img pl20">
							<li> 10 B.E./ B.Tech./ B.S. students who will be taking admission in 2019 will get Grant of Rs. 2 Lac to study at each IIT<a data-toggle="modal" data-target="#23iit">( Click Here to view the Institute list)</a> and Rs. 1 Lac at each NIT<a data-toggle="modal" data-target="#31nit">( Click Here to view the Institute list)</a>. Qualifying LPUNEST will be compulsory to avail this grant. The following table illustrates the total Study Grant.</li>
						</ul>
						<div class="table-responsive">
							<table class="table table-striped table-bordered" border="0" cellspacing="0" cellpadding="0">
							<col width="14%">
							<col width="5%">
							<col width="15%">
							<col width="8%">
							<col width="12%">
							<col width="9%">
							<col width="17%">
							<col width="20%">
								<tr>
									<td><strong>Discipline</strong>
									</td>
									<td><strong>Institute</strong>
									</td>
									<td><strong>Subject to Admission in</strong>
									</td>
									<td><strong>No. of Institutes</strong>
									</td>
									<td><strong>Number of students considered for benefit</strong>
									</td>
									<td><strong>Total number of students considered</strong>
									</td>
									<td><strong>Tuition Fee Benefit</strong>
									</td>
									<td><strong>Total study grant</strong>
									</td>
								</tr>
								<tr>
									<td valign="bottom">Engineering</td>
									<td>IIT</td>
									<td> B.E./ B.Tech./ B.S.</td>
									<td><a data-toggle="modal" data-target="#23iit">23 </a>
									</td>
									<td>10</td>
									<td>230</td>
									<td>₹2,00,000</td>
									<td>₹4,60,00,000</td>
								</tr>

								<tr>
									<td valign="bottom">Engineering</td>
									<td>NIT</td>
									<td> B.E./ B.Tech./ B.S.</td>
									<td><a data-toggle="modal" data-target="#31nit">31 </a>
									</td>
									<td>10</td>
									<td>310</td>
									<td>₹1,00,000</td>
									<td>₹3,10,00,000</td>
								</tr>
								<tr>
									<td valign="bottom"></td>
									<td></td>
									<td>Total</td>
									<td><strong>54</strong>
									</td>
									<td></td>
									<td><strong>540</strong>
									</td>
									<td></td>
									<td><strong>₹7.7 Crores</strong>
									</td>
								</tr>
							</table>
						</div>
						Note: Above study grant is available for the students taking admission in UG Engineering (B.Tech, B.E OR B.S.) programs of the above mentioned institutes.<br> Example:
						<ul class="list-img pl20">
							<li>Any IIT (say IIT Guwahati) – 22 applicants apply for the study grant and only 9 have qualified LPUNEST then all 9 from this institute will rewarded with the study grant.</li>
							<li>Any other IIT( say IIT Delhi) --  22 applied and all have qualified LPUNEST, then top 10  based on their performance in the LPUNEST</li>
							<li>In case there is any clash for the grant in the eligible beneficiaries, then candidate having better score in LPUNEST will be considered.  In case two or more students are having same marks in a LPUNEST exam, then candidate having more marks in best three subjects will be considered for the study grant. In case of further tie, best two subject marks will be considered (or best one in case of clash). In case there is still tie, eldest candidate (on the basis of date of birth) will be considered for the award.</li>
						</ul>
				</div>
				<div class="modal-footer border-zero text-center">
					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>
		</div>
	</div>
	<div id="design-model" class="modal fade" role="dialog" style="overflow-y:scroll;">
		 <div class="modal-dialog modal-lg">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">LPUNEST Study Grant for Design/Fashion Programmes</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
					
						
						<!--<strong class="modal-heading">LPU announces grand opportunity for aspiring professionals</strong><br>
  Study Grant Rs. 1 Lac per student to 5 students from every  IIT(IDC), NID, IIITDM, NIFT on qualifying LPUNEST. LPUNEST (LPU National  Entrance and Scholarship Test) is not only a gateway to the Design Programmes  at LPU but in fact an <em>Entrance Test for  Life</em>. LPUNEST performance can lead to following objectives:

  <li><strong>Entrance  Test</strong> for Admission in LPU Design/Fashion Programmes</li>
  <li><strong>Scholarship</strong> up to Rs. 3.2 Lac per student for Admission in LPU</li>
  -->
						<ul class="list-img pl20">
							<li> 5 students from each NID/IITs(IDC/DoD)/IIITDM/NIFT<a data-toggle="modal" data-target="#design-city">( Click Here to view the Institute list)</a> will be offered Study Grant of Rs. 1 Lac summing total study grant of Rs. 1.15 Crores. Qualifying LPUNEST will be compulsory to avail this grant. The following table illustrates the total Study Grant.</li>
						</ul>
						<div class="table-responsive">
							<table class="table table-striped table-bordered" border="0" cellspacing="0" cellpadding="0">
							<col width="14%">
							<col width="23%">
							<col width="10%">
							<col width="6%">
							<col width="10%">
							<col width="9%">
							<col width="14%">
							<col width="14%">
								<tr>
									<td align="center"><strong>Discipline</strong>
									</td>
									<td align="center"><strong>Institute</strong>
									</td>
									<td align="center"><strong>Subject    to Admission in</strong>
									</td>
									<td align="center"><strong>No. of    Institutes</strong>
									</td>
									<td align="center"><strong>Number    of students considered for benefit</strong>
									</td>
									<td align="center"><strong>Total    number of students considered</strong>
									</td>
									<td align="center"><strong>Tuition    Fee Benefit</strong>
									</td>
									<td align="center"><strong>Total    study grant</strong>
									</td>
								</tr>
								<tr>
									<td align="center">Design (UG)</td>
									<td align="center">National Institute of Design</td>
									<td align="center">B.Des</td>
									<td align="center">3</td>
									<td align="center">5</td>
									<td align="center">15</td>
									<td align="center">₹1,00,000</td>
									<td align="center">₹15,00,000</td>
								</tr>
								<tr>
									<td align="center">Design (UG)</td>
									<td align="center">IIT(IDC/ DoD)</td>
									<td align="center">B.Des</td>
									<td align="center">3</td>
									<td align="center">5</td>
									<td align="center">15</td>
									<td align="center">₹1,00,000</td>
									<td align="center">₹15,00,000</td>
								</tr>
								<tr>
									<td align="center">Design (UG)</td>
									<td align="center">IIITDM</td>
									<td align="center">B.Des</td>
									<td align="center">1</td>
									<td align="center">5</td>
									<td align="center">5</td>
									<td align="center">₹1,00,000</td>
									<td align="center">₹5,00,000</td>
								</tr>
								<tr>
									<td align="center">Fashion (UG)</td>
									<td align="center">NIFT</td>
									<td align="center">B. Des, B.F.Tech</td>
									<td align="center">16</td>
									<td align="center">5</td>
									<td align="center">80</td>
									<td align="center">₹1,00,000</td>
									<td align="center">₹80,00,000</td>
								</tr>
								<tr>
									<td align="center"></td>
									<td align="center"></td>
									<td align="center">Total</td>
									<td align="center"><strong><a  data-toggle="modal" data-target="#design-city">23</a></strong>
									</td>
									<td align="center"></td>
									<td align="center"><strong>115</strong>
									</td>
									<td align="center"></td>
									<td align="center"><strong>₹1.15    Crores</strong>
									</td>
								</tr>
							</table>
						</div>
						Note: Above study grant is available for the students taking admission in UG B.Des/B.Ftech programs of the above mentioned institutes.<br> Example:
						<ul class="list-img pl20">
							<li>Any IIT (say IIT Bombay) – 15 applicants apply for the study grant and only 4 have qualified LPUNEST then all 4 from this institute will rewarded with the study grant.</li>
							<li>Any other NID - 15 applied and all have qualified LPUNEST, then top 5 based on their performance in the LPUNEST</li>
							<li>In case there is any clash for the grant in the eligible beneficiaries, then candidate having better score in LPUNEST will be considered.  In case two or more students are having same marks in a LPUNEST exam, then candidate having more marks in best three subjects will be considered for the study grant. In case of further tie, best two subject marks will be considered (or best one in case of clash). In case there is still tie, eldest candidate (on the basis of date of birth) will be considered for the award.</li>
						</ul>
				</div>
				<div class="modal-footer border-zero text-center">

					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>

		</div>
	</div>
	<div id="hotel-management-model" class="modal fade" role="dialog" style="overflow-y:scroll;">
		<div class="modal-dialog modal-lg">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">LPUNEST Study Grant for Hotel Management Programmes</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
						
						<!--
<strong class="modal-heading">LPU announces grand opportunity for aspiring professionals</strong><br>
  Study Grant of Rs. 1 Lac per student to 5 students from every  IHM/ITTM (National Level as listed) on qualifying LPUNEST. LPUNEST (LPU  National Entrance and Scholarship Test) is not only a gateway to the Hotel Management  Programmes at LPU but in fact an <em>Entrance  Test for Life</em>. LPUNEST performance can lead to following objectives:

  <li><strong>Entrance  Test</strong> for Admission in LPU Hotel Management Programmes</li>
  <li><strong>Scholarship</strong> up to Rs. 3.2 Lac per student for Admission in LPU</li>-->
						<ul class="list-img pl20">
							<li> 5 students from each IHM<a data-toggle="modal" data-target="#20ihm">( Click Here to view the Institute list)</a> will be offered Study Grant of Rs. 1 Lac. Qualifying LPUNEST will be compulsory to avail this grant. The following table illustrates the total Study Grant.</li>
						</ul>
						<div class="table-responsive">
							<table class="table table-striped table-bordered" border="0" cellspacing="0" cellpadding="0">
								<col width="14%">
							<col width="9%">
							<col width="11%">
							<col width="8%">
							<col width="12%">
							<col width="9%">
							<col width="17%">
							<col width="20%">
								<tr>
									<td><strong>Discipline</strong>
									</td>
									<td><strong>Institute</strong>
									</td>
									<td><strong>Subject to Admission in</strong>
									</td>
									<td><strong>No. of Institutes</strong>
									</td>
									<td><strong>Number of students considered for benefit</strong>
									</td>
									<td><strong>Total number of students considered</strong>
									</td>
									<td><strong>Tuition Fee Benefit</strong>
									</td>
									<td><strong>Total study grant</strong>
									</td>
								</tr>
								<tr>
									<td>Hotel Management and Tourism</td>
									<td>IHM</td>
									<td>B.Sc</td>
									<td><a data-toggle="modal" data-target="#20ihm">20</a>
									</td>
									<td>5</td>
									<td>100</td>
									<td>₹1,00,000</td>
									<td>₹1,00,00,000</td>
								</tr>
							</table>
						</div>
						Note: Above study grant is available for the students taking admission in B.Sc programs of the above mentioned institutes.<br> Example:
						<ul class="list-img pl20">
							<li>Any IHM (say IHM Chandigarh) – 15 applicants apply for the study grant and only 4 have qualified LPUNEST then all 4 from this institute will rewarded with the study grant.</li>
							<li>Any other IHM (say IHM Guwahati) -- 15 applied and all have qualified LPUNEST, then top 5 based on their performance in the LPUNEST</li>
							<li>In case there is any clash for the grant in the eligible beneficiaries, then candidate having better score in LPUNEST will be considered.  In case two or more students are having same marks in a LPUNEST exam, then candidate having more marks in best three subjects will be considered for the study grant. In case of further tie, best two subject marks will be considered (or best one in case of clash). In case there is still tie, eldest candidate (on the basis of date of birth) will be considered for the award.</li>
						</ul>
				</div>
				<div class="modal-footer border-zero text-center">

					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>

		</div>
	</div>
	<div id="law-model" class="modal fade" role="dialog" style="overflow-y:scroll;">
		<div class="modal-dialog modal-lg">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">LPUNEST Study Grant for LAW Programmes</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
<!--<strong class="modal-heading">LPU announces grand opportunity for aspiring professionals</strong><br>
  Study Grant of Rs. 1 Lac per student to 5 students from every  NLU (as listed) on qualifying LPUNEST. LPUNEST (LPU National Entrance  and Scholarship Test) is not only a gateway to the Law Programmes at LPU but in  fact an <em>Entrance Test for Life</em>.  LPUNEST performance can lead to following objectives:
	  <li><strong>Entrance  Test</strong> for Admission in LPU Law Programmes</li>
	  <li><strong>Scholarship</strong> up to Rs. 6 Lac per student for Admission in LPU</li>-->
							<ul class="list-img pl20">
							<li> 5 students from each of NLU&rsquo;s<a data-toggle="modal" data-target="#5law">( Click Here to view the Institute list)</a> will be offered Study Grant of Rs. 2 Lac. Qualifying LPUNEST will be compulsory to avail this grant. The following table illustrates the total Study Grant.</li>
						</ul>
						<div class="table-responsive">
							<table class="table table-striped table-bordered" border="0" cellspacing="0" cellpadding="0">
							<col width="14%">
							<col width="9%">
							<col width="20%">
							<col width="8%">
							<col width="12%">
							<col width="9%">
							<col width="14%">
							<col width="14%">							
							<tr>
									<td align="center"><strong>Discipline</strong>
									</td>
									<td align="center"><strong>Institute</strong>
									</td>
									<td align="center"><strong>Subject    to Admission in</strong>
									</td>
									<td align="center"><strong>No. of    Institutes</strong>
									</td>
									<td align="center"><strong>Number    of students considered for benefit</strong>
									</td>
									<td align="center"><strong>Total    number of students considered</strong>
									</td>
									<td align="center"><strong>Tuition    Fee Benefit</strong>
									</td>
									<td align="center"><strong>Total    study grant</strong>
									</td>
								</tr>
								<tr>
									<td align="center">Law (UG)</td>
									<td align="center">National Law University</td>
									<td align="center">B.A. LLB(Hons)/<br> B.Com LLB (Hons)/<br> BBA LLB (Hons)/<br> B.Sc LLB (Hons)</td>
									<td align="center"><a data-toggle="modal" data-target="#5law">5</a>
									</td>
									<td align="center">5</td>
									<td align="center">25</td>
									<td align="center">₹2,00,000</td>
									<td align="center">₹50,00,000</td>
								</tr>
							</table>
						</div>
						Note: Above study grant is available for the students taking admission in B.A. LLB(Hons)/B.Com LLB (Hons)/BBA LLB (Hons)/B.Sc LLB (Hons) programs of the above mentioned institutes.<br> Example:
						<ul class="list-img pl20">
							<li>Any NLU (say NLU Cuttack) – 15 applicants apply for the study grant and only 4 have qualified LPUNEST then all 4 from this institute will rewarded with the study grant.</li>
							<li>Any other NLU (say NLU Ranchi) -- 15 applied and all have qualified LPUNEST, then top 5 based on their performance in the LPUNEST</li>
							<li>In case there is any clash for the grant in the eligible beneficiaries, then candidate having better score in LPUNEST will be considered.  In case two or more students are having same marks in a LPUNEST exam, then candidate having more marks in best three subjects will be considered for the study grant. In case of further tie, best two subject marks will be considered (or best one in case of clash). In case there is still tie, eldest candidate (on the basis of date of birth) will be considered for the award.</li>
						</ul>
				</div>
				<div class="modal-footer border-zero text-center">

					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>

		</div>
	</div>
	<div id="mba-model" class="modal fade" role="dialog" style="overflow-y:scroll;">
		<div class="modal-dialog modal-lg">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">LPUNEST Study Grant for MBA Programmes</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
						
						<!--<strong class="modal-heading">LPU announces grand opportunity for aspiring professionals</strong><br>
  Study Grant Rs. 3 Lac per student to 10 students from every IIM  on qualifying LPUNEST. LPUNEST (LPU National Entrance and Scholarship  Test) is not only a gateway to the Management Programmes at LPU but in fact an <em>Entrance Test for Life</em>. LPUNEST performance  can lead to following objectives:

  <li><strong>Entrance  Test</strong> for Admission in LPU MBA Programmes</li>
  <li><strong>Scholarship</strong> up to Rs. 3 Lac per student for Admission in LPU</li>-->
						<ul class="list-img pl20">
							<li>5 students from each IIM<a data-toggle="modal" data-target="#20iim">( Click Here to view the Institute list)</a> will be offered Study Grant of Rs. 3 Lac. Qualifying LPUNEST will be compulsory to avail this grant. The following table illustrates the total Study Grant.</li>
						</ul>
						<div class="table-responsive">
							<table class="table table-striped table-bordered" border="0" cellspacing="0" cellpadding="0">
							<col width="14%">
							<col width="9%">
							<col width="11%">
							<col width="8%">
							<col width="12%">
							<col width="9%">
							<col width="17%">
							<col width="20%">
								<tr>
									<td align="center"><strong>Discipline</strong>
									</td>
									<td align="center"><strong>Institute</strong>
									</td>
									<td align="center"><strong>Subject    to Admission in</strong>
									</td>
									<td align="center"><strong>No. of    Institutes</strong>
									</td>
									<td align="center"><strong>Number    of students considered for benefit</strong>
									</td>
									<td align="center"><strong>Total    number of students considered</strong>
									</td>
									<td align="center"><strong>Tuition    Fee Benefit</strong>
									</td>
									<td align="center"><strong>Total    study grant</strong>
									</td>
								</tr>
								<tr>
									<td align="center">Management</td>
									<td align="center">IIM</td>
									<td align="center">Post Graduate Programmes</td>
									<td align="center"><a data-toggle="modal" data-target="#20iim">20</a>
									</td>
									<td align="center">5</td>
									<td align="center">100</td>
									<td align="center">₹3,00,000</td>
									<td align="center">₹3,00,00,000</td>
								</tr>
							</table>
						</div>
						Note: Above study grant is available for the students taking admission in PGP/MBA programs of the above mentioned institutes.<br> Example:
						<ul class="list-img pl20">
							<li>Any IIM (say IIM Delhi) – 15 applicants apply for the study grant and only 4 have qualified LPUNEST then all 4 from this institute will rewarded with the study grant.</li>
							<li>Any other IIM (say IIM Calcutta) -- 15 applied and all have qualified LPUNEST, then top 5 based on their performance in the LPUNEST</li>
							<li>In case there is any clash for the grant in the eligible beneficiaries, then candidate having better score in LPUNEST will be considered.  In case two or more students are having same marks in a LPUNEST exam, then candidate having more marks in best three subjects will be considered for the study grant. In case of further tie, best two subject marks will be considered (or best one in case of clash). In case there is still tie, eldest candidate (on the basis of date of birth) will be considered for the award.</li>
						</ul>
				</div>
				<div class="modal-footer border-zero text-center">

					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>

		</div>
	</div>





	<div id="20ihm" class="modal fade" role="dialog" style="overflow-y:scroll;">
		<div class="modal-dialog modal-lg">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">List of IHMs</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
							
						<ul class="list-img pl20">
							<li class="col-md-3"> Bengaluru</li>
							<li class="col-md-3"> Bhubaneswar</li>
							<li class="col-md-3"> Chennai</li>
							<li class="col-md-3"> Gandhinagar </li>
							<li class="col-md-3"> Goa </li>
							<li class="col-md-3"> Gurdaspur</li>
							<li class="col-md-3"> Guwahati</li>
							<li class="col-md-3"> Gwalior </li>
							<li class="col-md-3"> Hajipur </li>
							<li class="col-md-3"> Hyderabad </li>
							<li class="col-md-3"> Jaipur </li>
							<li class="col-md-3"> Kolkata </li>
							<li class="col-md-3"> Lucknow </li>
							<li class="col-md-3"> Mumbai </li>
							<li class="col-md-3"> New Delhi</li>
							<li class="col-md-3"> Shillong </li>
							<li class="col-md-3"> Shimla </li>
							<li class="col-md-3"> Srinagar </li>
							<li class="col-md-3"> Thiruvananthapuram </li>
							<li class="col-md-3"> Bhopal </li>



						</ul>
				</div>
				<div class="clearfix"></div>
				<div class="modal-footer border-zero text-center clearfix">
					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>
		</div>
	</div>




	<div id="20iim" class="modal fade" role="dialog" style="overflow-y:scroll;">
		<div class="modal-dialog modal-lg">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">List of IIMs</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
					
						<ul class="list-img pl20">
							<li class="col-md-3"> Ahmedabad</li>
							<li class="col-md-3"> Bangalore</li>
							<li class="col-md-3"> Calcutta</li>
							<li class="col-md-3"> Lucknow</li>
							<li class="col-md-3"> Indore</li>
							<li class="col-md-3"> Nagpur</li>
							<li class="col-md-3"> Udaipur</li>
							<li class="col-md-3"> Trichy</li>
							<li class="col-md-3"> Kashipur</li>
							<li class="col-md-3"> Kozikhode</li>
							<li class="col-md-3"> Bodh Gaya</li>
							<li class="col-md-3"> Rohtak</li>
							<li class="col-md-3"> Ranchi</li>
							<li class="col-md-3"> Sirmaur</li>
							<li class="col-md-3"> Amritsar</li>
							<li class="col-md-3"> Shillong</li>
							<li class="col-md-3"> Raipur</li>
							<li class="col-md-3"> Jammu</li>
							<li class="col-md-3"> Sambalpur</li>
							<li class="col-md-3"> Vishakhapatnam</li>


						</ul>
				</div>
				<div class="clearfix"></div>
				<div class="modal-footer border-zero text-center clearfix">
					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>
		</div>
	</div>










	<div id="5law" class="modal fade" role="dialog" style="overflow-y:scroll;">
		<div class="modal-dialog modal-lg">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">List of NLUs</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
					
						<ul class="list-img pl20">
							<li class="col-md-6"> National Law School of India University, Bengaluru</li>
							<li class="col-md-6"> NALSAR University of Law, Hyderabad</li>
							<li class="col-md-6"> The West Bengal National University of Juridical Sciences, Kolkata</li>
							<li class="col-md-6"> National Law University, Delhi</li>
							<li class="col-md-6"> Maharashtra National Law University, Mumbai</li>

						</ul>
				</div>
				<div class="clearfix"></div>
				<div class="modal-footer border-zero text-center clearfix">
					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>
		</div>
	</div>





	<div id="23iit" class="modal fade" role="dialog" >
		<div class="modal-dialog modal-lg">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">List of IITs</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
						
						<ul class="list-img pl20">
							<li class="col-md-3"> Bombay</li>
							<li class="col-md-3"> Bhubaneswar</li>
							<li class="col-md-3"> Bhilai</li>
							<li class="col-md-3"> Dharwad</li>
							<li class="col-md-3"> Dhanbad</li>
							<li class="col-md-3"> Delhi</li>
							<li class="col-md-3"> Guwahati</li>
							<li class="col-md-3"> Goa</li>
							<li class="col-md-3"> Gandhinagar</li>
							<li class="col-md-3"> Indore</li>
							<li class="col-md-3"> Hyderabad</li>
							<li class="col-md-3"> Jodhpur</li>
							<li class="col-md-3"> Jammu</li>
							<li class="col-md-3"> Kharagpur</li>
							<li class="col-md-3"> Kanpur</li>
							<li class="col-md-3"> Mandi</li>
							<li class="col-md-3"> Madras</li>
							<li class="col-md-3"> Patna</li>
							<li class="col-md-3"> Palakkad</li>
							<li class="col-md-3"> Ropar</li>
							<li class="col-md-3"> Roorkee</li>
							<li class="col-md-3"> Varanasi</li>
							<li class="col-md-3"> Tirupati</li>

						</ul>
				</div>
				<div class="clearfix"></div>
				<div class="modal-footer border-zero text-center clearfix">
					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>
		</div>
	</div>



	<div id="31nit" class="modal fade" role="dialog" style="overflow-y:scroll;">
		<div class="modal-dialog modal-lg">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">List of NITs</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
						
						<ul class="list-img pl20">
							<li class="col-md-3"> Agartala</li>
							<li class="col-md-3"> Allahabad</li>
							<li class="col-md-3"> Andhra Pradesh</li>
							<li class="col-md-3"> Arunachal Pradesh</li>
							<li class="col-md-3"> Bhopal</li>
							<li class="col-md-3"> Calicut</li>
							<li class="col-md-3"> Delhi</li>
							<li class="col-md-3"> Durgapur</li>
							<li class="col-md-3"> Goa</li>
							<li class="col-md-3"> Hamirpur</li>
							<li class="col-md-3"> Jaipur</li>
							<li class="col-md-3"> Jalandhar</li>
							<li class="col-md-3"> Jamshedpur</li>
							<li class="col-md-3"> Kurukshetra</li>
							<li class="col-md-3"> Manipur</li>
							<li class="col-md-3"> Meghalaya</li>
							<li class="col-md-3"> Mizoram</li>
							<li class="col-md-3"> Nagaland</li>
							<li class="col-md-3"> Nagpur</li>
							<li class="col-md-3"> Patna</li>
							<li class="col-md-3"> Puducherry</li>
							<li class="col-md-3"> Raipur</li>
							<li class="col-md-3"> Rourkela</li>
							<li class="col-md-3"> Sikkim</li>
							<li class="col-md-3"> Silchar</li>
							<li class="col-md-3"> Srinagar</li>
							<li class="col-md-3"> Surat</li>
							<li class="col-md-3"> Surathkal</li>
							<li class="col-md-3"> Tiruchirappalli</li>
							<li class="col-md-3"> Uttarakhand</li>
							<li class="col-md-3"> Warangal</li>
						</ul>
				</div>
				<div class="clearfix"></div>
				<div class="modal-footer border-zero text-center clearfix">
					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>
		</div>
	</div>




	<div id="design-city" class="modal fade" role="dialog" style="overflow-y:scroll;">
		<div class="modal-dialog modal-lg">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header border-zero">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><strong class="modal-heading">List of NIFTs</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
					<div class="col-md-12 pa0">
						
						<ul class="list-img pl20">
							<li class="col-md-3"> Bhopal</li>
							<li class="col-md-3"> Bhubneshwar</li>
							<li class="col-md-3"> Bengaluru</li>
							<li class="col-md-3"> Chennai</li>
							<li class="col-md-3"> Delhi</li>
							<li class="col-md-3"> Gandhinagar </li>
							<li class="col-md-3"> Hyderabad</li>
							<li class="col-md-3"> Jodhpur</li>
							<li class="col-md-3"> Kangra </li>
							<li class="col-md-3"> Kannur</li>
							<li class="col-md-3"> Kolkata </li>
							<li class="col-md-3"> Mumbai</li>
							<li class="col-md-3"> Patna</li>
							<li class="col-md-3"> Raebareli</li>
							<li class="col-md-3"> Srinagar </li>
							<li class="col-md-3"> Shillong</li>

						</ul>
					</div>
					</div>
					<div class="clearfix"></div>
					<div class="modal-header border-zero pb0">
					
					<h4 class="modal-title"><strong class="modal-heading">List of NIDs</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
					<div class="col-md-12 pa0 mt10">
						<ul class="list-img pl20">
							<li class="col-md-3"> Ahmdabad </li>
							<li class="col-md-3"> Kurukshetra </li>
							<li class="col-md-3"> Vizag</li>
						</ul>
					</div>
					</div>
<div class="clearfix"></div>
					<div class="modal-header border-zero pb0">
					
					<h4 class="modal-title"><strong class="modal-heading">List of IIT(IDC)s</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">
					<div class="col-md-12 pa0 mt10">						
						<ul class="list-img pl20">
							<li class="col-md-3"> Hyderabad </li>
							<li class="col-md-3"> Guwahati </li>
							<li class="col-md-3"> Bombay</li>
						</ul>
					</div>
					</div>
<div class="clearfix"></div>
					<div class="modal-header border-zero pb0 mt10">
					
					<h4 class="modal-title"><strong class="modal-heading">List of IIITDM</strong></h4>
				</div>
				<div class="modal-body mr20 ml20">

					<div class="col-md-12 pa0 ">
						<ul class="list-img pl20">
							<li class="col-md-3">Jabalpur</li>
						</ul>


					</div>
				</div>
				<div class="clearfix"></div>
				<div class="modal-footer border-zero text-center clearfix">
					<a data-dismiss="modal" class="button button-circle ok">OK</a>
				</div>
			</div>
		</div>
	</div>


	<!-- All Model end-->
	<script type="text/javascript" src="//www.lpu.in/js/jquery.js"></script>
	<script type="text/javascript" src="//www.lpu.in/js/plugins.js"></script>
	<script type="text/javascript" src="//www.lpu.in/js/sweetalert2.min.js"></script>
	<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
	<script src="//admission.lpu.in/Scripts/custom.js" type="text/javascript"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
	<script src="//www.lpu.in/js/additional-methods.min.js"></script>
	<script src="//www.lpu.in/js/jquery.blockui.min.js"></script>
	<script type="text/javascript" src="../js/AdmissionwithOTP.js"></script>
	
<script>
function setModalMaxHeight(element) {
  this.$element     = $(element);  
  this.$content     = this.$element.find('.modal-content');
  var borderWidth   = this.$content.outerHeight() - this.$content.innerHeight();
  var dialogMargin  = $(window).width() < 768 ? 20 : 60;
  var contentHeight = $(window).height() - (dialogMargin + borderWidth);
  var headerHeight  = this.$element.find('.modal-header').outerHeight() || 0;
  var footerHeight  = this.$element.find('.modal-footer').outerHeight() || 0;
  var maxHeight     = contentHeight - (headerHeight + footerHeight);

  this.$content.css({
      'overflow': 'hidden'
  });
  
  this.$element
    .find('.modal-body').css({
      'max-height': maxHeight,
      'overflow-y': 'auto'
    });
}

$('.modal').on('show.bs.modal', function() {
  $(this).show(); 
  setModalMaxHeight(this);
});

$(window).resize(function() {
  if ($('.modal.in').length == 1) {
    setModalMaxHeight($('.modal.in'));
  }
});



/* CodeMirror */
$('.code').each(function() {
  var $this = $(this),
      $code = $this.text(),
      $mode = $this.data('language');

  $this.empty();
  $this.addClass('cm-s-bootstrap');
  CodeMirror.runMode($code, $mode, this);
});
</script>
	<script>
		$(".bb").click( function () {
			$("#"+$(this).attr("data-class")).prop("checked", true);
			$("#"+$(this).attr("data-class")).trigger("change");
			$("#"+$(this).attr("data-class")).trigger("click");
		});
		$( document ).ready( function () {
			
			
			
			$( "#engineering" ).click( function () {
				$( "#engineering-model" ).modal( 'show' );
			} );
			$( "#design" ).click( function () {
				$( "#design-model" ).modal( 'show' );
			} );
			$( "#hotel-management" ).click( function () {
				$( "#hotel-management-model" ).modal( 'show' );
			} );
			$( "#law" ).click( function () {
				$( "#law-model" ).modal( 'show' );
			} );
			$( "#mba" ).click( function () {
				$( "#mba-model" ).modal( 'show' );
			} );

		} );
	</script>
	<script src="//www.lpu.in/js/functions.js"></script>




</body>

</html>