<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="Lovely Professional University" />

	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!-- Stylesheets
	============================================= -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700" rel="stylesheet">
	<link rel="stylesheet" href="//www.lpu.in/css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/style.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/dark.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/animate.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/magnific-popup.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/vmap.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/responsive.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/home-custom.css" type="text/css" />
	<link rel="stylesheet" href="css/jquery.dataTables.min.css" type="text/css" />
	
	<script type="text/javascript" src="//www.lpu.in/js/jquery.js"></script>
	<script type="text/javascript" src="//www.lpu.in/js/plugins.js"></script>   
	<script type="text/javascript" src="//www.lpu.in/js/readmore-js/readmore.min.js"></script>
    
	<script type="text/javascript">
		$( document ).ready(function() {
			$('.entry-content').readmore({
			  speed: 100,
			  height: 50,
			  collapsedHeight: 100,
			  startOpen: false,
			  lessLink: '<a href="#" style="text-align: right">Read Less <i class="icon-arrow-up"></i></a>',
			  afterToggle: function(){
				$('.portfolio').isotope();			
			}
			});
		});
	</script>
	
	<style>	

.heading-block::after {
    margin-top: 10px;
    width: 20%;
    border-top: 4px solid #F58220 !important;
}
.border-none:after{border-top: none !important;}
		.portfolio-3 .portfolio-item .portfolio-image, .portfolio-3 .portfolio-item .portfolio-image a, .portfolio-3 .portfolio-item .portfolio-image img{
			width:100%;
		}
				
		.entry {
    position: relative;
    margin: 0;
    padding: 0;
    border-bottom: 0;
}

	</style>
	
	
	<!-- Document Title
	============================================= -->
	<title>Research and Development - Lovely Professional University</title>
	<meta name="description" content="To create research environment that fosters creativity, LPU has collaborations with international community which inspires faculty and students to pursue research in one of the leading research intensive universities in India." />
	  <link rel="manifest" href="/manifest.json">


<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P8ZP9K2');</script>
<!-- End Google Tag Manager -->
<!-- ===================================================== -->
<!-- Description of the code :AdWords Remarketing Tag -->
<!-- Applied Date: 06-Mar-2018 format  ( 05-Mar-2018 )  -->
<!-- Applicable for  Year: 2018 -->
<!-- Required Till: Permanent or Possible Month-Year till code is required -->
<!-- Source Agency : AdGlobal Etc -->
<!-- Contact Person : Abha  -->
<!-- ===================================================== -->
<!-- Global site tag (gtag.js) - Google AdWords: 980757795 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-980757795"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'AW-980757795');
</script>

<!-- ============ End Of Code  ============================== -->

<!-- ===================================================== -->
<!-- Description of the code :Facebook Pixel -->
<!-- Applied Date: 06-Mar-2018 format  ( 05-Mar-2018 )  -->
<!-- Applicable for  Year: 2018 -->
<!-- Required Till: Permanent or Possible Month-Year till code is required -->
<!-- Source Agency : AdGlobal Etc -->
<!-- Contact Person : Abha  -->
<!-- ===================================================== -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '1512138752380429');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=1512138752380429&ev=PageView&noscript=1"
/></noscript>
<!-- ============ End Of Code  ============================== -->

 	<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
	<script>
	  var OneSignal = window.OneSignal || [];
	  OneSignal.push(function() {
		OneSignal.init({
		  appId: "39fdbe81-037d-4888-82d6-1d2db7fb38b3",
		});
	  });
	</script>
 
</head>

<body class="stretched home-bg">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Top Bar
		============================================= -->
		<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P8ZP9K2"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<style>
/*#top-bar {
    margin-top: 0 !important;
}*/
#header.sticky-header #header-wrap{
	top:0 !important;
}
#page-menu.sticky-page-menu #page-menu-wrap, .main-nav-scrolled{
	top:60px !important;
}


/*Hello Bar Start*/

.lpu-hello-bar{background-color:#fccb92 ; color:#000000; padding:9px 10px; text-align:center; }
.font18{font-size:18px;}
.section-mt40{margin-top:40px !important;} <!--for landing page -->
.font15b{font-size:16px;font-weight:bold !important;}
@media(max-width:430px){.font18{font-size:16px;}
.font15b{font-size:14px;font-weight:bold !important;}}
@media(max-width:800px)
{.lpu-hello-bar{position:static !important;}#top-bar{margin-top:0;}
.section-mt40{margin-top:0 !important;} <!--for landing page -->
}
</style>

<script type="text/javascript">
$( document ).ready(function() {
			var lastdate, today, bday, diff, days;
			lastdate = [15,7,2018]; 
			today = new Date($('#getdate').val());
			bday = new Date(lastdate[2],lastdate[1]-1,lastdate[0]);
			
			diff = bday.getTime()-today.getTime();
			days = Math.floor(diff/(1000*60*60*24));
			
			if(parseInt(days)>0){
				var count=parseInt(days)+1;
				if(count==1)
				{
					$('#nest-last-date').html("Last <strong>"+count +" days</strong>   left to apply for admission with  scholarship. Last Date: 15th July 2018. ");	
				}
				else{
					$('#nest-last-date').html("Last <strong>"+count +" days</strong> left to apply for admission with  scholarship. Last Date: 15th July 2018.");	
				}
			}
			else if(parseInt(days)==0)
			{
				$('#nest-last-date').html("Last day left to apply for admission with  scholarship. Last Date: 15th July 2018. ");
			}
			else
			{
				$('#nest-last-date').html('Applications invited for LPUNEST (Ph.D.) 2018-19 Spring Term. ');
			}
	});
     	
          
    </script>
<div class="lpu-hello-bar" id="lpu-bar">



	<div class="font-f" id="topbartext">
		<i class="icon icon-bullhorn" aria-hidden="true"></i>
		 Applications invited for Admission-2019. <b class="font15b">
			<a data-link="hellobar-lpunest" data-href="//nest.lpu.in/main.aspx" target="_blank" class="applylnk hide-on-lp" style="color:#000000 !important;">
			Apply Now.</a> </b>
		<br>
		  <input type='hidden' id='getdate' value="" />
	</div>

<!--
<div id="oc-posts-top-bar" class="owl-carousel posts-carousel">	
 <div class="oc-item">
	<div class="font-f" id="topbartext">
		<i class="icon icon-bullhorn" aria-hidden="true"></i>
		<span id="nest-last-date"></span> Results of Transforming Education Awards is declared.  <b class="font15b">
			<a data-link="hellobar-lpunest" data-href="https://www.lpu.in/educationawards/account/login" target="_blank" class="applylnk hide-on-lp" style="color:#000000 !important;">
			Click here.</a></b>
		<br>
		  <input type='hidden' id='getdate' value="" />
</div>
</div>	
	
	
	 <div class="oc-item">
	<div class="font-f" id="topbartext">
		<i class="icon icon-bullhorn" aria-hidden="true"></i>
		<span id="nest-last-date"></span>Nominations for Transforming Education Awards 2019 is open.  <b class="font15b">
			<a class="hide-on-lp" href="https://www.lpu.in/educationawards"  style="color:#000000 !important;" target="_blank"> Nominate Now.</a> </b>
		<br>
		  <input type='hidden' id='getdate' value="" />
	</div>
	</div>
	
	
	
		 <div class="oc-item">
	<div class="font-f" id="topbartext">
		<i class="icon icon-bullhorn" aria-hidden="true"></i>
		<span id="nest-last-date"></span>  Applications invited for LPUNEST-2019. <b class="font15b">
			<a data-link="hellobar-lpunest" data-href="//nest.lpu.in/main.aspx" target="_blank" class="applylnk hide-on-lp" style="color:#000000 !important;">
			Apply Now.</a> </b>
		<br>
		  <input type='hidden' id='getdate' value="" />
	</div>
	</div>		
	
	
	
	
	
	</div>-->
	
		
	</div>
	

<!-- Hello Bar End-->

<div id="top-bar" class="ps-top-bar slider-top-link">
			<div class="container-fluid clearfix">
				<div class="col_half nobottommargin mr0">
					<div class="top-links dark">
						<ul>
            <li class="hidden-xs hidden-xxs hidden-sm hidden-md"><a href="https://ums.lpu.in/lpuums" target="_blank">Parent's Login</a></li>
            <li class="hidden-xs hidden-xxs hidden-sm hidden-md"><a href="https://ums.lpu.in/lpuums" target="_blank">UMS</a></li>
			<li class="hidden-xs hidden-xxs hidden-sm hidden-md"><a href="//www.lpu.in/jobs/">Jobs</a></li>
            <!--<li class="hidden-xs hidden-xxs hidden-sm"><a href="//www.lpu.in/about_lpu/tour_lpu.php">Campus Visit</a></li> -->
		
			<li class="hidden-xs hidden-xxs hidden-sm"><a href="http://happenings.lpu.in/" target="_blank">Happenings</a></li>
			<li class="hidden-xs hidden-xxs hidden-sm"><a href="https://www.lpu.in/disha/" target="_blank"> Career Guidance </a> </li>
			<li class="hidden-xs hidden-xxs hidden-sm"><a href="//conferences.lpu.in/" target="_blank"> Conferences </a> </li>
				<li ><a href="//www.lpu.in/studygrant" target="_blank" >Study Grant</a></li>
			<li ><a data-link="topbar-lpunest" data-href="//nest.lpu.in/main.aspx" target="_blank" class="nest-result applylnk">LPUNEST</a></li>
			<!--<li class="hidden-xs hidden-xxs hidden-sm"><a href="//nest.lpu.in/main.aspx" target="_blank" >LPUNEST</a></li>-->
			<li class="hidden-xs hidden-xxs hidden-sm"><a href="//admission.lpu.in/">Result </a></li>
			<li class="hidden-xs hidden-xxs hidden-sm"><a href="//www.lpu.in/international/" target="_blank">International Admissions </a></li>
			<li ><a href="//www.lpu.in/contact_us/contact-us.php">Contact Us</a></li>     
		    

			<!--<li><a id="educationawards" href="#" data-toggle="modal" data-target="#myLargeModal">Education Awards</a></li>			 -->
          </ul>
					</div>
				</div>
				<div class="col_half fright nobottommargin mr0 top-ts">				
					<div id="top-social">
						<ul>
						   <li class="d-one"><a  data-toggle="tooltip" data-placement="bottom" title="" href="https://api.whatsapp.com/send?phone=+91-9876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202018." target="_blank" class="si-whatsapp"><span class="ts-icon"><i style="font-size: 14px; font-weight: bold; padding-top: 11px;" class="fa fa-whatsapp"></i></span></a></li>
							<li><a href="https://www.facebook.com/LPUUniversity" target="_blank" class="si-facebook"><span class="ts-icon"><i class="icon-facebook"></i></span></a></li>
							<li><a href="https://twitter.com/lpuuniversity" target="_blank" class="si-twitter"><span class="ts-icon"><i class="icon-twitter"></i></span></a></li>
							<li><a href="https://plus.google.com/u/0/102445329734305802454/posts" target="_blank" class="si-gplus"><span class="ts-icon"><i class="icon-gplus"></i></span></a></li>
							<li><a href="https://www.linkedin.com/company/lovely-professional-university" target="_blank" class="si-linkedin"><span class="ts-icon"><i class="icon-linkedin"></i></span></a></li>
							<li><a href="https://www.youtube.com/user/LPUuniversity" target="_blank" class="si-youtube"><span class="ts-icon"><i class="icon-youtube"></i></span></a></li>
							<li><a href="" class="si-call ppwnd"><span class="ts-icon"><i class="icon-call"></i></span></a></li>
							<li><a href="mailto:admissions@lpu.co.in" class="si-email3"><span class="ts-icon"><i class="icon-email3"></i></span></a></li>
							 <li><a href="//www.lpu.in/about_lpu/tour_lpu.php" target="_blank" class="si-call"><span class="ts-icon"><i class="icon-globe"></i></span><span class="ts-text">360<sup>0</sup> View</span></a>
							</li>
						  </ul>
					</div>
				</div>
			</div>
		</div>
		
		<script type="text/javascript">

						$(document).ready(function() {
							 $("#oc-posts-top-bar").owlCarousel({
								margin: 20,
								autoplayTimeout:5000,								
								loop:true,
								nav: false,
								navText: ['<i class="icon-angle-left"></i>','<i class="icon-angle-right"></i>'],
								autoplay: true,
								autoplayHoverPause: true,
								dots: false,
								responsive:{
									0:{ items:1 },
									600:{ items:1 },
									1000:{ items:1 },
									1200:{ items:1 }
								}
							});

						});

					</script>
					
								
				<!-- Header
		============================================= -->
		
<header id="header" class="full-header ps-header" data-responsive-class="not-dark">
	<div id="header-wrap">
		<div class="container clearfix">
			<div id="primary-menu-trigger"><i class="icon-reorder"></i>
			</div>
			<div id="logo">
				<a href="//www.lpu.in/" class="standard-logo" data-sticky-logo="//www.lpu.in/images/logo/logo-media.png" data-dark-logo="//www.lpu.in/images/logo/logo-dark.png" data-mobile-logo="//www.lpu.in/images/logo/logo-media.png"><img src="//www.lpu.in/images/logo/logo.png"  alt="LPU Logo" width="auto" height="auto" /></a>
				<a href="//www.lpu.in/" class="retina-logo" data-sticky-logo="//www.lpu.in/images/logo/logo-media@2x.png" data-dark-logo="//www.lpu.in/images/logo/logo-dark.png" data-mobile-logo="//www.lpu.in/images/logo/logo-media@2x.png"><img width="auto" height="auto" src="//www.lpu.in/images/logo/logo-media@2x.png"  alt="LPU Logo"></a>
			</div>
			<nav id="primary-menu">
				<ul>
					<li>
						<a href="#">
							<div>About</div>
						</a>
						<div class="mega-menu-content style-2 clearfix" style="padding:0 !important">
							<ul>

								<li class="mega-menu-title">
									<a>
										<div>Get Started</div>
									</a>
									<div class="col-xs-12 mb0 pl0 pr0">
										<ul>
											<li>
												<a href="//www.lpu.in/about_lpu/infrastructure.php">
													<div>Infrastructure</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/about_lpu/accreditation.php">
													<div>Accreditation and Tie Ups</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/about_lpu/ranking.php">
													<div>Ranking</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/placements.php">
													<div>Placements</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/about_lpu/alumni.php">
													<div>Alumni</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/about_lpu/leadership.php">
													<div>Leadership</div>
												</a>
											</li>
											<li><a href="//www.lpu.in/about_lpu/vision-mission.php">
												<div>Vision and Mission</div>
												</a></li>
											<li>
												<a href="//www.lpu.in/admission/lpu-in-your-town.php#lpu-town">
													<div>Location</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/about_lpu/tour_lpu.php">
													<div>Tour LPU</div>
												</a>
											</li>
										</ul>
									</div>
								</li>
							</ul>
						</div>
					</li>
					<li class="mega-menu sub-menu">
						<a href="#">
							<div style="border-bottom:2px solid #F68121;"> Admissions</div>
						</a>
						<div class="mega-menu-content style-2 clearfix col-4" style="padding:0 !important">
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Get Started</div>
									</a>
									<ul>

										<li>
											<a href="//www.lpu.in/admission/admissions.php">
												<div>Overview</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/ProgramSearch.php#Apply">
												<div>How To Apply?</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/scholarship/scholarship.php">
												<div>Scholarship</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/admission/lpu-in-your-town.php#lpu-town">
												<div>LPU in Your Town</div>
											</a>
										</li>
									
										<li>
											<a href="//www.lpu.in/admission/career_assessment.php">
												<div>Career Assessment</div>
											</a>
										</li>
										<li>										
										<a href="//www.lpu.in/events/freshmeninduction/index.php"><div>Reporting and Induction </div></a>
										</li><li>										
										<a target="_blank"  href="//www.lpu.in/international/"><div>International Applicants</div></a>
										</li>
										
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Programmes By Qualification</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/programmes/all/10th">
												<div>After 10th <small> (Diploma Programmes)</small></div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/all/12th">
												<div>After 12th  <small> (Under Graduation Programmes)</small></div>
											</a>
										</li>
										
										<li>
											<a href="//www.lpu.in/programmes/all/Graduation">
												<div>After Graduation <small> (Master Programmes)</small></div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/all/Post Graduation">
												<div>After Post Graduation</div>
											</a>
										</li>
										<li><a href="//nest.lpu.in/phd/">
										  <div>Doctoral Programmes</div>
										  </a></li>
										  
										  <!--<li><a href="//www.lpu.in/after-doctoral-programmes/index.php">
										  <div>After Doctoral Programmes</div>
										  </a></li> -->
										  
										  
										  <li>
											<a href="//www.lpu.in/programmes/all/Diploma or Certificate">
												<div>After Diploma or Certificate</div>
												
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/all">
												<div>All Programmes</div>
											</a>
										</li>
										
										<!--<li>
											<a href="//www.lpu.in/programmes/ProgramSearch.php">
												<div>Programme Search</div>
											</a>
										</li>-->
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Programmes by type</div>
									</a>
									<ul>
										
										<li>
											<a href="//www.lpu.in/programmes/regular">
												<div>Standard or Regular Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/lateral">
												<div>Lateral Entry Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/admission/integrated-bachelors-masters-programmes.php">
												<div>Integrated Bachelors-Masters Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/admission/honours-programmes-options.php">
												<div>Honours Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/admission/dual-degree-programmes-options.php">
												<div>Dual Degree Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/parttime">
												<div>Part Time Programmes</div>
											</a>
										</li>
										
										 <li><a href="//www.lpu.in/admission/short-term-courses.php">
										  <div>Short Term Courses</div>
										  </a></li>	
										  <li>
											<a href="//www.lpu.in/engineering/" target="_blank">
												<div>Top Engineering Courses (B.Tech - M.Tech)</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>International Applicants</div>
									</a>
									<ul>

									<li><a  target="_blank"  href="//www.lpu.in/international"><div>Overview</div></a></li>
									 <li><a target="_blank" href="//www.lpu.in/international/programmes/ProgramSearch.php"><div>Programme Offered</div></a> </li>
									 <li><a target="_blank"  href="//www.lpu.in/international/english-language-requirement.php"><div>English Language Requirement</div></a> </li>
								  <li><a target="_blank"  href="//www.lpu.in/international/scholarship.php"><div>Scholarship</div></a> </li>
								  <li><a  target="_blank" href="//www.lpu.in/international/how_to_apply.php"><div>How to Apply</div></a> </li>
																		
									</ul>
								</li>
							</ul>
						</div>
					</li>
					
					
					
					
					<li class="mega-menu sub-menu hide">
						<a href="#">
							<div>International</div>
						</a>
						<div class="mega-menu-content style-2 clearfix col-4" style="padding:0 !important">
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Get Started</div>
									</a>
									<ul>

										<li>
											<a href="//www.lpu.in/international/how_to_apply.php">
												<div>How to Apply</div>
											</a>
										</li>
										<li>
											<a href="//admission.lpu.in">
												<div>Apply Online</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/how_to_pay.php">
												<div>How to Pay</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/scholarship.php">
												<div>Schlorship</div>
											</a>
										</li>
									
										<li>
											<a href="//www.lpu.in/international/booklet_and_forms.php">
												<div>Admission Guidelines</div>
											</a>
										</li>
																				
											<li>
											<a href="//www.lpu.in/OnlineAdmission/LetterAuthentication.aspx">
												<div>Admission Authetication</div>
											</a>
										</li>
										
											<li>
											<a href="//www.lpu.in/international/english-language-requirement.php">
												<div>English Language Requirement</div>
											</a>
										</li>
										
										<li>
											<a href="//www.lpu.in/international/across_globe.php">
												<div>Our Global Representatives</div>
											</a>
										</li>
										
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Programme Offered</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/international/programmes/all/Grade 10th (O Level)">
												<div>Diploma (after O level)</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/programmes/all/Grade 12th (A Level)">
												<div>Under Graduate (after A level)</div>
											</a>
										</li>
										
										<li>
											<a href="//www.lpu.in/international/programmes/all/Graduation">
												<div>Post Graduate (after Graduation)</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/programmes/all/Graduation">
												<div>Doctoral (after Post Graduation)</div>
											</a>
										</li>
										<li><a href="//www.lpu.in/international/english-language-programme.php">
										  <div>English Language Programmes</div>
										  </a></li>
										  <li>
											<a href="//www.lpu.in/international/study_india_programme.php">
												<div>Study India Programmes</div>
												
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/study_abroad_programme.php">
												<div>Term Exchange Programmes</div>
											</a>
										</li>
										
										<!--<li>
											<a href="//www.lpu.in/programmes/ProgramSearch.php">
												<div>Programme Search</div>
											</a>
										</li>-->
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Summer School Programme</div>
									</a>
									<ul>
										
										<li>
											<a href="//www.lpu.in/international/summer_school/index.php">
												<div>International Summer School Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_eligibility.php">
												<div>Eligibility</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_accommodation_and_facilities.php">
												<div>Accomodation and Other Facilities</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_registeration_and_fee_structure.php">
												<div>Registration and Fee Structure</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_proposed_schedule.php">
												<div>Schedule and Details</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_visa_requirement_and_guidelines.php">
												<div>Visa Requirement and Guidelines</div>
											</a>
										</li>
										
										 <li><a href="//www.lpu.in/international/summer_school/int_gallery.php">
										  <div>Gallary</div>
										  </a></li>	
										  
										   <li><a href="//www.lpu.in/international/summer_school/int_faq.php">
										  <div>FAQ's</div>
										  </a></li>	
										  
										     <li><a href="//www.lpu.in/international/summer_school/int_contact.php">
										  <div>Contact Us</div>
										  </a></li>	
										  
										  
										  
										  
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Student Support and FAQs</div>
									</a>
									<ul>

									<li><a  target="_blank"  href="//www.lpu.in/international/pre_arrival.php"><div>Pre Arrival Information</div></a></li>
									 <li><a target="_blank" href="//www.lpu.in/international/post_arrival.php"><div>Post Arrival Information</div></a> </li>
									 <li><a target="_blank"  href="//www.lpu.in/international/after_you_graduate.php"><div>After You Graduate</div></a> </li>
								  <li><a target="_blank"  href="//www.lpu.in/international/returning_back.php"><div>Returning Back Home</div></a> </li>
								  <li><a  target="_blank" href="//www.lpu.in/international/international_student_experience.php"><div>Students Testimonials</div></a> </li>
								   <li><a  target="_blank" href="//www.lpu.in/international/general-faq.php"><div>Joining Related FAQs</div></a> </li>
									<li><a  target="_blank" href="//www.lpu.in/international/admission_related_faqs.php"><div>Admission Related FAQs</div></a> </li>
								  <li><a  target="_blank" href="//www.lpu.in/international/visa-frro-faq.php"><div>VISA/FRRO Related FAQs</div></a> </li>
								   <li><a  target="_blank" href="//www.lpu.in/international/general_information_related_to_visa.php"><div>Visa Requirement and Guidelines</div></a> </li>
								   <li><a  target="_blank" href="//www.lpu.in/international/visa_extensions.php"><div>Visa Extensions</div></a> </li>
																		
									</ul>
								</li>
							</ul>
						</div>
					</li>
					
					<li class="mega-menu">
						<a href="#">
							<div>Academics</div>
						</a>
						<div class="mega-menu-content col-3 style-2 clearfix">
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>How We Teach</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/academics/live-projects.php">
												<div>Live projects</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/industry-immersion.php">
												<div>Industry Immersion</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/Interdisciplinary-minors.php">
												<div>Interdisciplinary Minors</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/curriculum-innovations.php">
												<div>Curriculum innovations</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/guest-lectures.php">
												<div>Guest lectures / Workshops</div>
											</a>
										</li>

										<li>
											<a href="//www.lpu.in/academics/assessment-and-evaluation.php">
												<div>Assessment and Evaluation</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/mentoring-advising.php">
												<div>Mentoring and advising</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Highlights</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/academics/research.php">
												<div>Research @ LPU</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/faculty-development.php">
												<div>Human Resource Development Center</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/placements.php">
												<div>Placements</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/libraries-laboratories.php">
												<div>Libraries and Laboratories</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/calendar_regular_programmes.php">
												<div>Academic Calendar</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/holiday-list.php">
												<div>Holiday List</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Disciplines / Departments </div>
									</a>
									<div>
										<ul>
											<li><a href="#disciplines-popup" data-lightbox="inline" class="mb0">LPU has 45+ disciplines / departments  for your career path.<br><br><div class="pull-right mt-20">View All</div></a>
											</li>
											
										</ul>
									</div>
								</li>
							</ul>
						</div>
					</li>
				
				<li>
						<a href="//www.lpu.in/placements.php">
							<div>Placements</div>
						</a>
						<!-- <div class="mega-menu-content style-2 clearfix" style="padding:0 !important">
               <ul>
              <li class="mega-menu-title"><a>
                  <div>Campus Placement</div>
                  </a>
              <div class="col-xs-12 mb0 pl0 pr0">
               <ul>
                  <li><a href="#">
                    <div>Link 1</div>
                    </a></li>
					 <li><a href="#">
                    <div>Link 2</div>
                    </a></li>
					 <li><a href="#">
                    <div>Link 3</div>
                    </a></li>
					 <li><a href="#">
                    <div>Link 4</div>
                    </a></li>
					 <li><a href="#">
                    <div>Link 5</div>
                    </a></li>
                    <li><a href="#">
                    <div>Link 6</div>
                    </a></li>
                  </ul>
              </div>
              </li>
              </ul>
            </div>-->
					</li>
			

			
			
			
			
			

			<li class="mega-menu">
						<a href="#">
							<div>Campus Life</div>
						</a>
						
						<div class="mega-menu-content col-2 style-2 clearfix">
						
							
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Campus Life</div>
									</a>
									
									<div class="col-md-12 mb0 pl0 pr0">
									<div class="col-md-6 ma0 pa0"><ul>
											<li>
												<a href="//www.lpu.in/campus_life/entrepreneurship.php">
													<div>Entrepreneurship</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/sports.php">
													<div>Sports</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/art-and-culture.php">
													<div>Art and Culture</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/campus-events.php">
													<div>Campus Events</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/student-organisations.php">
													<div>Student Organizations</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/community-services.php">
													<div>Community Service</div>
												</a>
											</li>
										</ul>
									</div>
									<div class="col-md-6 ma0 pa0"><ul>
											
											<li>
												<a href="//www.lpu.in/campus_life/visitors.php">
													<div>Visitors</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/diversity.php">
													<div>Diversity</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/on-campus-jobs.php">
													<div>On Campus Jobs</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/fun-zone.php">
													<div>Fun Zone</div>
												</a>
											</li>
											
										</ul>
									</div>
										
									</div>
								
								
								</li>
							</ul>
						

							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Student Services</div>
									</a>
									
									<div class="col-md-12 mb0 pl0 pr0">
									<div class="col-md-6 ma0 pa0"><ul>
											<li>
												<a href="//www.lpu.in/student_services/security.php">
													<div>Campus Security</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/healthcare.php">
													<div>Uni Hospital</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/ums.php">
													<div>University Management System</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/residence.php">
													<div>Residential Facilities</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/transport.php">
													<div>Transportation Facilities</div>
												</a>
											</li>
										</ul>
									</div>
									<div class="col-md-6 ma0 pa0"><ul>
											
											<li>
												<a href="//www.lpu.in/student_services/shopping-dining.php">
													<div>Shopping and Dining</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/banking-postal-services.php">
													<div>Banking and Postal Services</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/education-loan-assistance.php">
													<div>Education Loan Assistance</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/placements.php">
													<div>Placements</div>
												</a>
											</li>
											<li>
												<a href="http://startupschool.lpu.in/" target="_blank">
													<div>Startup School</div>
												</a>
											</li>
										</ul>
									</div>
										
									</div>
								
								
								</li>
							</ul>
						
						</div>
					
						
						
				</li>

				<li class="mega-menu">
						<a href="#">
							<div>Schools</div>
						</a>
						<div class="mega-menu-content col-3 style-2 clearfix">
							<ul>
								<li class="mega-menu-title">
									
									<ul>
										<li>
											<a href="//schools.lpu.in/business/" target="_blank">
												<div>Business</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/computer-science-engineering/" target="_blank">
												<div>Computer Science and Engineering</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/mechanical-engineering/" target="_blank">
												<div>Mechanical Engineering</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/civil-engineering/" target="_blank">
												<div>Civil Engineering</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">
												<div>Electronics and Electrical Engineering</div>
											</a>
										</li>
										
																				<li>
											<a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">
												<div>Bioengineering and Biosciences</div>
											</a>
										</li>
												
										<li>
											<a href="//schools.lpu.in/architecture-design/" target="_blank">
												<div>Architecture and Design</div>
											</a>
										</li>
										
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									
									<ul>
										<li>
											<a href="//schools.lpu.in/hotel-management-and-tourism/" target="_blank">
												<div>Hotel Management and Tourism</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/computer-applications/" target="_blank">
												<div>Computer Application</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/pharmaceutical-sciences" target="_blank">
												<div>Pharmaceutical Sciences</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/agriculture/" target="_blank">
												<div>Agriculture</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/fashion-design/" target="_blank">
												<div>Design</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/journalism-film-production/" target="_blank">
												<div>Journalism, Films And Creative Arts</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/physical-sciences/" target="_blank">
												<div>Chemical Engineering And Physical Sciences</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									
									<ul>
										<li>
											<a href="//schools.lpu.in/law/" target="_blank">
												<div>Law</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/polytechnic/" target="_blank">
												<div>Polytechnic</div>
											</a>
										</li>
										
										<li>
											<a href="//schools.lpu.in/physiotherapy-and-paramedical-sciences/" target="_blank">
												<div>Physiotherapy and Paramedical Sciences</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/education/" target="_blank">
												<div>Education</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/physical-education/" target="_blank">
												<div>Physical Education</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/social-sciences/" target="_blank">
												<div>Social Sciences and Languages</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							
						</div>
					</li>
				
				
				<li class="scroll-menu"><a href="https://nest.lpu.in/" target="_blank"><div>Apply Now</div></a></li>
				<!--<li class="scroll-menu"><a href="http://www.lpu.in/contact_us/contact-us.php" target="_blank"><div>Enquire Now</div></a></li>-->
				</ul>
				<div id="top-search">
					<a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
					<form action="//www.lpu.in/result.php" name="form2" id="form2">
						<input type="hidden" name="cx" value="partner-pub-016589675364233558975:gl7zrlhae3u"/>
						<input type="hidden" name="cof" value="FORID:11"/>
						<input type="hidden" name="ie" value="ISO-8859-1"/>
						<input type="text" name="q" onclick="make_blank();" class="form-control" placeholder="Type &amp; Hit Enter.."/>
					</form>
				</div>
			</nav>
		</div>
	</div>
</header>		<!-- #header end -->
		<div id="page-menu" class="sticky-page-menu">

			<div id="page-menu-wrap">

				<div class="container clearfix">

					<div class="menu-title"> <span>Research</span> </a></div>
<!--
					<nav>
						<ul>
							<li class="current"><a href="#">About</a></li>
							<li><a href="#">Academics</a></li>
							<li><a href="#">Research &amp; Entrepreneurship</a></li>
							<li><a href="#">Student Stories</a></li>
							<li><a href="#">Alumni Speak</a></li>
						</ul>
					</nav>

				<div id="page-submenu-trigger"><i class="icon-reorder"></i></div>
-->
				</div>

			</div>

		</div>
		
		<!-- Content place here
		============================================= -->
			<div class="clearfix"></div>
		
		
		<section id="slider" style="background-image: url('images/header.jpg'); background-position: center center;height: 550px;background-size:cover">
			<div class="container clearfix">
				<div class="vertical-middle">
							<div class="caption-bg text-center">
								<h1>Research @ LPU</h1>
								<span>LPU researchers won a huge research grant worth 10.8 Millions through Indo Canadian Impact project from DBT, GOI</span>
							</div>
					</div>
			</div>			
					<div class="video-overlay" style="background-color: rgba(0,0,0,0.6);"></div>
		</section>
		
		
	
		
		
		
		
		
				
		<section id="content">
			<div class="section section-white content-wrap pt50 mt0 mb0 pb0">
				<div class="container clearfix">
				
					<div class="heading-block center border-none">
						<h2>Industry Sponsored & Collaborated Labs</h2>
						<span>LPU has various industry partnerships aimed at promoting research.</span>
					</div>
					
					
					<div id="portfolio" class="portfolio portfolioa grid-container portfolio-3 portfolio-masonry clearfix">

						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research1.jpg" class="image_fade">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Cisco</h3>
								<span class="pb15 pl20 pr25">Provide training to students in CCNA as per academy standards.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research2.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Oracle</h3>
								<span class="pb15 pl20 pr25">Oracle University offers certifications like OCP, OCA etc. for different oracle products through Oracle Cloud services.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research3.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">NSE</h3>
								<span class="pb15 pl20 pr25">Tie-up for joint MBA & BBA ‘Financial Market’ (FM) programs that provide practical knowledge and skills required to operate in the finance market.</span>
							</div>
						</article>
						
						
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research4.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Google</h3>
								<span class="pb15 pl20 pr25">Google Center of Excellence at LPU campus offers special Android certification as part of the syllabus.</span>
							</div>
						</article>
						
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research5.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">EMC<sup>2</sup></h3>
								<span class="pb15 pl20 pr25">University collaborated with EMC<sup>2</sup> for advance career in storage and information management.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research6.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Cadence</h3>
								<span class="pb15 pl20 pr25">VLSI lab with Cadence (leading provider of EDA and semiconductor IP) builds technical and research skills.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research7.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Safeducate</h3>
								<span class="pb15 pl20 pr25">Led by Stanford and Cambridge alumni, Safeducate brings international operational know-how of the supply chain logistics.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research8.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Microsoft Imagine Academy</h3>
								<span class="pb15 pl20 pr25">Basic fundamentals and advanced concepts of IT to sustain in industry.</span>
							</div>
						</article>
						
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research16.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">MoU with Punjab Remote Sensing Center</h3>
								<span class="pb15 pl20 pr25">To enhance the research in the field of Geo-spatial technologies and to explore the feasibility of launching Satellite-Payload for future societal applications.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research17.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">MoU with Christian Medical College</h3>
								<span class="pb15 pl20 pr25">Collaborative work for rural health endeavors, outreach programme, institutional development, capacity building, consultancy services and promotion of technology for societal benefits, disease diagnostics and more.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research18.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">MoU with National Institute of Urban Affairs</h3>
								<span class="pb15 pl20 pr25">Research based collaboration that focuses on decentralized sanitation system.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research19.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">MoU with JEOL India Ltd</h3>
								<span class="pb15 pl20 pr25">Research and development of processes, tools and techniques for joint academic research.</span>
							</div>
						</article>
						
						
					</div>
			
					
					
					
				</div>		
			</div>					
		</section>
		
		
		
  <section>
			<div class="container clearfix pt50 mt0 mb0 pb0">
			<div class="col-md-12 grid-innr">
			<div class="heading-block center pt30">
					<h2>LPU Faculty Research Scholars</h2>
				
				</div>
				<div class="col-sm-7 col-xs-12">
					<div class="heading-block mb20">
						<h3>LPU FACULTY GOT P<span style="text-transform:none;color:#444;">h</span>.D. FROM PRESIDENT OF INDIA</h3>
					</div>
					<p>LPU Faculty received their doctorate degrees (Ph.Ds.) from His Excellency, Sh. Pranab Mukherjee on 8th University Convocation held on 2nd May 2017. Hailing from various academic disciplines, scholars achieved their feats, while as a part of the LPU family.</p>

				</div>
			
		
				<div class="col-sm-5 col-xs-12 pl0">
					  
            <div class="entry-image clearfix">
            
            
     
              <div class="portfolio-image" >
                      <div data-pause="4000" data-speed="2000" data-arrows="false" class="fslider">
                          <div class="flexslider">
                              <div class="flex-viewport" style="overflow: hidden; position: relative; ">
                                   <div class="slider-wrap" style="width: 400%; transition-duration: 0s; transform: translate3d(-740px, 0px, 0px);">
                                      <div class="slide clone" aria-hidden="true" style="width: auto; margin-right: 0px; float: left; display: block;">
                                      <a href="imgs/convo-8-1.jpg" data-lightbox="image"><img width="auto" height="auto" alt="LPU Postal Stamp" src="imgs/convo-8-1-thumb.jpg" draggable="false"></a>
                                      </div>
									  
                                      <div class="slide clone" aria-hidden="true" style="width: auto; margin-right: 0px; float: left; display: block;"> <a href="imgs/convo-8-2.jpg" data-lightbox="image"><img width="auto" height="auto" alt="LPU Postal Stamp" src="imgs/convo-8-2-thumb.jpg" draggable="false"></a></div>
									  
									    <div class="slide clone" aria-hidden="true" style="width: auto; margin-right: 0px; float: left; display: block;"> <a href="imgs/convo-8-3.jpg" data-lightbox="image"><img width="auto" height="auto" alt="LPU Postal Stamp" src="imgs/convo-8-3-thumb.jpg" draggable="false"></a></div>
                                      
                                  
                                  </div>
                              </div>
                            
                          </div>
                      </div>
                      
                     
                  </div>
            
      
                </div>
           
				</div>
				
				</div>
			</div>
		</section>
		
		<section id="content">
			<div class="content-wrap pb0">
				<div class="promo promo-light promo-full uppercase mt50 header-stick">
					<div class="container clearfix">
					<div class="col-md-9">
						<h3 style="letter-spacing: 2px;font-size:16px">Ph.D Scholars Details</h3>
						<span class="">Research @ LPU</span>
						</div>
						<div class="col-md-3 pt40">
						<a class="button button-large button-border button-rounded popup-modal" href="#test-modal">View More</a>
												</div>
					</div>
				</div>
			</div>
		</section>
		
		
		
		<!-- Content place here end -->
		<section>
			<div class="container clearfix pt50 mt0 mb0 pb0">
				<div class="col-md-12 grid-innr">
				<div class="heading-block center pt30">
					<h2>Research Papers</h2>
					<span>Hundreds Published in Scopus Indexed Journals </span>
				</div>
				<div class="col-sm-5 col-xs-12 pl0">
					<div class="entry clearfix">
						<div class="entry-image clearfix">
							<div class="portfolio-single-image masonry-thumbs col-4" data-big="3" data-lightbox="gallery">
								
        <a href="imgs/research/publications/1.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/1.jpg" alt=""></a>
        
        
								<a href="imgs/research/publications/2.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/2.jpg" alt=""></a>
        
								<a href="imgs/research/publications/7.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/7.jpg" alt=""></a>
        
        
								<a href="imgs/research/publications/4.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/4.jpg" alt=""></a>
        
        
								<a href="imgs/research/publications/5.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/5.jpg" alt=""></a>
        
        
        
								<a href="imgs/research/publications/6.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/6.jpg" alt=""></a>
        
        
								<a href="imgs/research/publications/3.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/3.jpg" alt=""></a>
        
        
								<a href="imgs/research/publications/8.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/8.jpg" alt=""></a>
        
        
								<a href="imgs/research/publications/9.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/9.jpg" alt=""></a>
        
        
								<a href="imgs/research/publications/10.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/10.jpg" alt=""></a>
        
        
        
        
								<a href="imgs/research/publications/11.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/11.jpg" alt=""></a>
        
        
        
        
								<a href="imgs/research/publications/12.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/12.jpg" alt=""></a>
        
								<a href="imgs/research/publications/13.jpg" data-lightbox="gallery-item"><img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/publications/13.jpg" alt=""></a>
        
							</div>
						</div>
					</div>
					<script type="text/javascript">

						jQuery(window).load(function(){

							var $container = $('#posts');

							$container.isotope({ transitionDuration: '0.65s' });

							$(window).resize(function() {
								$container.isotope('layout');
							});

						});

					</script>
				</div>
				<div class="col-sm-7 col-xs-12">
					<div class="heading-block mb20">
						<h3>OVER 700 Publication Last Year</h3>
					</div>
					<p>Lovely Professional University is committed to excelling in research and development in all the disciplines. Let the record speak for itself!</p>

					<span class="mb10 col-xs-12 pa0"><b>Our Publication Record</b></span>
					<div class="col-xs-12 col-sm-8">
						<div class="table-responsive mt15">
							  <table class="table text-center">
								<thead>
								  <tr>
									<th align="center">#</th>
									<th align="center">Years</th>
									<th align="center">No. of Publications</th>
									<th align="center">Download</th>
								  </tr>
								</thead>
								<tbody>
								  
								  <tr>
									<td>1</td>
									<td>2015</td>
									<td>705</td>
									<td><a href="pdf/Final-2015-Publications-Data.pdf" class="icon-grey"><span class="icon-cloud-download" aria-hidden="true"></span></a></td>
								  </tr>
								  <tr>
									<td>2</td>
									<td>2016</td>
									<td>1164</td>
									<td><a href="pdf/publication-2016.pdf" class="icon-grey"><span class="icon-cloud-download" aria-hidden="true"></span></a></td>
								  </tr>
								  <tr>
									<td>3</td>
									<td>2017</td>
									<td>1115</td>
									<td><a href="pdf/publication-2017.pdf" class="icon-grey"><span class="icon-cloud-download" aria-hidden="true"></span></a></td>
								  </tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			</div>
		</section>
		
		<div class="clearfix"></div>
		
		
		
		<section class="section mb0 pt0 mt0">
			<div class="content-wrap pb0">
				<div class="container clearfix">
				
					<div class="heading-block center border-none">
						<h2>Intellectual Property Development</h2>
						<span>LPU is doing novel research in various fields. Give it a look...</span>
					</div>
					
					
					
					<div id="portfolio" class="portfolio grid-container portfoliob portfolio-3 portfolio-masonry clearfix">

						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img alt="Open Imagination" style="height:200px;" src="imgs/research/patent1.jpg" class="image_fade">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A Drilling Machine And A Method Of Drilling</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN291173</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">A drilling machine consisting of a drill chuck, a floating head with a tool holder attached to the chuck, a guide 5 fixed to the pillar of the machine to guide the tool to cut a desired profile and a work-piece holder having a work piece and attached to the base of the machine.</span>
							</div>
						</article>
						
			
							
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent46.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">SYSTEM AND METHOD FOR GENERATING A SYMMETRICALLY BALANCED
OUTPUT</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>US16/140,245</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content"> BaReNPI True Random System - the invention demonstrates a true random system exhibiting the properties of true randomness. The invention has been provided to be beneficial, can be applied to various domains of research including cryptography, stochastic behaviour analysis, future prediction, data categorization and many more other applications.</span>
							</div>
						</article>

						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img alt="Open Imagination" style="height:200px;" src="imgs/research/patent8.jpg" class="image_fade">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Improved coal tar formulation for treatment of dandruff and other scalp diseases and its method of preparation thereof</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN2764/DEL/2013 WO2015040637A1</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The invention pertains to an improved, coal tar aqueous formulation and its method of preparation thereof. The formulation comprises coal tar, water and emulsifiers as the major ingredients. It offers distinct advantages of enhanced efficacy in treatment of diseases of scalp.</span>
							</div>
						</article>

  
<article class="portfolio-item grid-outer">
						<div class="entry-image">
								<img alt="Open Imagination" style="height:200px;" src="imgs/research/patent9.jpg" class="image_fade">
							</div>
							
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Improved Oral Targeted Drug Delivery System</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN2220/DEL/2010 WO2012035561A2</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention discloses an Improved Oral Targetted Drug Delivery System (O-TDDS) particularly suited for delivery of drugs having activity against the diseases located in the colon e.g. colon cancer, ulcerative colitis, protozoal infections.</span>
							</div>
						</article>
						
						
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent10.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A COMPOSITION FOR ANTI HYPERLIPIDEMIC ACTIVITY</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711014028</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The composition consists of an extract of at least one herb, bos indicus, and metallic nanoparticle. In one aspect, the at least one herb may comprise a terminalia arjuna, an allium sativum, a garcinia indica, a tamarindus indica, a cassia fistula, an elettaria cardamomum a glycyrrhiza glabra and alike. In another aspect, the metallic nanoparticle may comprise a gold nanoparticle, a silver nanoparticle, a copper or copper oxide nanoparticle, a zinc nanoparticle, an iron or iron oxide nanoparticle, and combination thereof.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent11.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A PLUG GAUGE</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711013294</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Disclosed is a plug gauge (100) for inspecting a diameter of a hole (402). In one embodiment, the plug gauge (100) comprises a first truncated cone (102), a second truncated cone (104), and a central bar (106) connecting the first truncated cone (102) and the second truncated cone (104). Further, the first truncated cone (102) and the second truncated cone (104) comprise a scale engraved on their lateral surface. During operation, at least one of the first truncated cone (102) and second truncated cone (104) is inserted in the hole (402) for inspecting the diameter of the hole (402).</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent13.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A FITNESS BRACELET</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711010067</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">A wearable device that provides a technological solution for overcoming the procrastination habit or problem which people tend to have while executing their exercise related daily routine. It may be understood that the wearable device ensures that the people should follow their exercise routine commitments, which are made earlier in the day or night. In one embodiment, the wearable device is a bracelet that may be wore around a wrist or an ankle. The wearable device comprising a Bluetooth™, a power source, a lockin motor, a vibrator, a beeper, and an Arduino controller. In order to overcome the procrastination habit, the wearable device is communicatively coupled with a smart phone.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent14.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">SYSTEM AND METHOD FOR MONITORING FOOD HYGIENE LEVEL IN REFRIGERATORS AND OTHER STORAGES</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711011948</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Disclosed is a monitoring system for monitoring hygiene level of food items kept in storage units such as refrigerators. The monitoring system comprises a plurality of sensors that monitors gases released from the spoiled food. After processing sensory information, captured from the plurality sensors, the monitoring system notifies a user on his/her smart phone about the degrading quality of the food items. In one aspect, the user may be notified in form of graphs and percentage, informing about the quality of the food items. In this manner the monitoring system, based on the integration of Internet of Things (IoT) devices with the plurality of sensors, improves the efficiency of the food items preservation in the storage units.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent15.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">AN ADJUNCT TO NON-SURGICAL PERIODONTAL THERAPY AND PREPARATION METHOD THEREOF</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711023120</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Disclosed is a method for preparing a microsphere. The method comprises melting Polyethylene Glycol (PEG) and Chitin together to form a molten PEG-Chitin mixture. The method further comprises, adding propylene glycol in the molten PEG-Chitin mixture to form a PEG-Chitin-propylene glycol mixture. Further, the method comprises dispersing Ornidazole particles in the PEG-Chitin-propylene glycol mixture to form an Ornidazole-PEG-Chitin-propylene glycol mixture and forming a liquid paraffin mixture of a heavy liquid paraffin and a light liquid paraffin. Furthermore, the method comprises stirring a thin film of the Ornidazole-PEG-Chitin-propylene glycol mixture into the liquid paraffin mixture until a pre-defined time period for preparing a microsphere suspended in the liquid paraffin mixture.</span>
							</div>
						</article>
						
						
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent18.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">METHOD FOR PREPARING A DRUG LOADED OIL-IN-WATER MACROEMULSION</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711034483</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Disclosed is a method for preparing a drug loaded oil-in-water macroemulsion. The method comprises processing a drug molecule using either a modified vapour pressure diffusion method and an anti-solvent precipitated method. The drug molecule may be processed using one of Curcumin, Adapalene, Fenugreek or Ginger. Further, the processed drug molecules are dispersed in an oil phase before emulsification. The oil phase comprises of a first non-volatile oil phase and a second non-volatile oil phase. The oil phase may then be added to the water phase along with a surfactant while constantly stirring using a low-shear size-reduction machinery such as magnetic stirrer and electric stirrer.</span>
							</div>
						</article>
						
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent19.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">METHOD FOR PREVENTING BAGGAGE THEFT AND FACILITATING HASSLE FREE COLLECTION OF BAGGAGE AT AIRPORTS</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711034788</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Disclosed is a system for hassle free collection of baggage by passengers at an airport. The present system reduces the anxiety of the passengers standing around a conveyor belt for baggage collection along with the minimization of baggage loss at the airport. The present system further facilitates to reduce the annoyance at baggage collection counter and theft cases at airports.</span>
							</div>
						</article>
						
						
						
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent20.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Bottle Neck cap assembly</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811001386</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention describes a bottle cap system which can avoid reuse and misuse of plastic bottles.  The system is so designed to facilitate easy bottle opening along with indication to the user about the use of the bottle.</span>
							</div>
						</article>
						
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent21.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Driving Style Profiler</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711041513</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention provides a solution to rash driving. The system so developed classifies the driver according to their driving pattern and informs the people around including police station to avoid accidents related to rash driving.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent22.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">TOPICAL FORMULATION OF CAPSIATE WITH AGED GARLIC EXTRACT TO PREVENT COLD INJURIES </h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711041514</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention describes a formulation which is prepared as a topical cream to protect against cold feet and chill burn in winters or snowy or hilly regions.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent23.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Filtration assembly for wastewater treatment </h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811002650</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention describes a filtration assembly used cleaning grey water having organic or inorganic impurities which can be used as an onsite arrangement also.</span>
							</div>
						</article>
						
						
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent24.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A DEVICE FOR MEASURING THE INFILTRATION RATE OF WATER THROUGH PERVIOUS CONCRETE</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811008145</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">This is a device for field and lab testing of infiltration rate of water through a pervious concrete. The life of concrete can also be tested with the use of this device. The device is mantled and dismantled easily both for lab as well as field use.</span>
							</div>
						</article>
						
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent25.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A device for amplification of genetic materials</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN 201811008377</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">A very simple and cost effective device for amplification of genetic materials which works on temperature cycles. The device is user friendly and can be operated through any display device.</span>
							</div>
						</article>
						
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent26.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">METHODS OF PREPARATION OF GREEN PAINTS AND PRIMERS USING PLANT WASTE MATERIAL</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN IN201811010341</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention relates to methods to prepare green paints and primers from plant waste material seed and peel, also their applications.</span>
							</div>
						</article>
						
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent27.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">INTELLIGENT BLIND ASSISTING CLOSET</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN IN201811016365</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">A device related to a society covering all age groups and the blind people as well for managing their closet in their normal day to day life.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent28.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A PLATFORM INDEPENDENT INTERNET OF THINGS (IOT) CONTROL-BASED SYSTEMS FOR THE TREATMENT OF INDUSTRIAL EFFLUENTS</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811016398</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The invention relates to a simple, cost effective and IoT based methods for treating industrial wastewaters. More particularly, the present invention relates to the use of IoT control system for microbial treatment of industrial wastewaters containing dyes.</span>
							</div>
						</article>
						
						
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent29.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A PROCESS OF DEGRADATION OF TEXTILE DYES</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811009348</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention relates to relates to methods of degradation of  nitrogen containing dyes by using microorganism consortium isolated from textile effluents and soil, subculture on mineral salt medium.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent30.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A PROCESS TO REMOVE HEAVY METALS FROM INDUSTRIAL EFFLUENT USING BIOCHAR</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811009349</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The invention relates to a simple, safe, customized and cost-effective methods to remove heavy metals from industry effluent.  The technique used for producing biochar for purification is very innovative and user friendly.</span>
							</div>
						</article>
						
						
								<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent31.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">DRUG DELIVERY SYSTEMS OF SPINACEA OLERACEA</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811022935</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The technology relates to novel drug delivery systems of Spinacea oleracea which can be used as an antidiabetic and antioxidant agent. </span>
							</div>
						</article>
						
						
								<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent32.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A NOVEL N-BIT COMPRESSOR BASED HIGH-SPEED MULTIPLIER ALGORITHM FOR LOW POWER ARITHMETIC CIRCUITS</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811022936</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention is in the field of digital multiplier, for low power arithmetic circuits, more particularly to a new N-bit compressor and a high speed algorithm. </span>
							</div>
						</article>
						
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent33.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">SELF NANO EMULSIFYING DRUG DELIVERY SYSTEM (SNEDDS) OF ENICOSTEMMA LITTORALE FOR THE MANAGEMENT OF DIABETES MELLITUS</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811022937</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Disclosed is a method to prepare SNEDDS formulation of Enicostemma littorale to treat diabetes mellitus. The formulation developed is stable and can be easily marketed. The formulation is also used for its antioxidant activity. The process developed is robust and easily scalable for the Industry.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent34.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A NOVEL AND ECO FRIENDLY PROCESS TO REMOVE SALINITY FROM SEA WATER</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811019564</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The technology is very robust and unique to purify saline water from food products. It is a simple, economic and ecofriendly methods for treating sea water to decrease its salt content.</span>
							</div>
						</article>
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent35.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A CUSTOMIZED CARD FOR SELF REGULATION OF BAD HABBITS</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811018821</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Disclosed is a customized card for self regulation of bad habits. The user can identify the restricted items or even vendor and can block them for a certain period of time. The restriction imposed will not change until set duration expires. This will help the user to regulate his bad habits of smoking, compulsive buying, drinking and many more. </span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent36.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">NOVEL SEAT LOCATOR SYSTEM FOR THEATERS AND AUDITORIUMS</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811026355</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The technology relates to novel tracking system for seat locating in various seating arenas like theaters and auditoriums.</span>
							</div>
						</article>
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent37.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">NOVEL MULTI-SEASON TEMPERATURE MODULATING DRINKING WATER BOTTLE</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811026354</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention is a novel product related to a bottle more particularly to a portable drinking water bottle with temperature adjusting mechanism </span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent38.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A novel method for water quality parameter evaluation using machine learning</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811024276</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Disclosed is a method for a water quality management related to an intelligent system of machine learning for evaluating the quality of water.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent39.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">NOVEL METHOD FOR PREPARATION OF GRAFTED CO-POLYMER USING ACRYLAMIDE AND RUMI MASTAGI</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811024277</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The technology relates to a novel, simple, economic and easy method for preparation of new polymeric system as grafted copolymer of acrylamide and Rumi mastagi.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent40.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">NOVEL PROCESS OF RECYCLING POLYSTYRENE WASTE FOR MAKING OF POROUS CONCRETE</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811024278</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The invention relates to pavements and paving materials with use of waste thermocol crockery and packaging materials therein, an eco-friendly method to recycle the waste materials to make such pavements and paving materials further porous concrete.</span>
							</div>
						</article>
						
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent41.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">AN EFFECTIVE PREGNANCY E-HEALTHCARE SYSTEM INTEGRATED WITH REAL TIME MONITORING AND ATTENTIVENESS</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811030615</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present system provides a complete healthcare solution for women during pregnancy time and more particularly a gadget system covering all the health parameter of women to the health care of baby in mother’s womb.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent42.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A NOVEL DOUBLY-ACTUATED HYDRAULIC VALVE</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811034526</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention is about agricultural automation related to precision water application systems, more particularly to a doubly-actuated hydraulic valve for irrigation systems in agricultural field environment.</span>
							</div>
						</article>
						
						
								<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent43.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A NOVEL METHOD FOR ENERGY RECOVERY FROM WASTE WATER</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811037217</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention is related to field of energy conservation more particularly recovery of waste energy from the water cooler with flexible design implementation to improving the energy efficiency.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent44.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A NOVEL MODIFIED BIOMASS GASIFIER</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811037218</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention is a device related to an economic and ecofriendly methods for utilizing biomass for the production of energy fuel which can fulfill all the daily needs of energy requirement of the society as well as can be used for industrial energy production from bio-waste.</span>
							</div>
						</article>
						
						
						
								<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/patent45.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A NOVEL SYSTEM FOR CANAL IRRIGATION</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201811037216</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention is about canal irrigation technique related to a rigid module more particularly a combination of masonry well-constructed in the bank of a parent channel with flexible construction, in order to maintain constant water supply to farmers.</span>
							</div>
						</article>
						
						
						
						
							
						
						
						<article class="portfolio-item grid-outer">
							
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Media for invitro dissolution testing of polysaccharide based colon targeted formulations and method thereof</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN2485/DEL/2013</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">The present invention discloses a novel, probiotic based dissolution media for in vitro testing of drug release from colon specific polysaccharide based formulations comprising a mixture of nutrition sources and specific polysaccharide digesting microbe(s) added externally.</span>
							</div>
						</article>
						
						
							<article class="portfolio-item grid-outer">
							
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">SITABY: The Posture Proctor</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN3648/DEL/2015</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Sitting is bliss to the human; it is posture which is most widely used by the people for work, travel, dinning, and entertainment. The correct posture affects our body systems a lot. SitAby is going to be a game changer in stance correction, ailment eradication and habit breaking of erroneous sitting.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Electric Shock Alarm System</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN2129/DEL/2009</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">This invention relates to prevent human beings from getting an electric shock by touching metal body of an appliance having a leakage current.The present invention uses an electronic circuit consisting of a bridge rectifier to drive a small speaker which works on DC and an LED to indicate the contact of phase with the metal body in case of any leakage.</span>
							</div>
						</article>
						
						
						
						
						<article class="portfolio-item grid-outer">
						
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Bag-o-Moto</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN2128/DEL/2009</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Bag-O-Moto is a simple collapsible and foldable gadget capable of easy movement within large campuses of Organisations or Universities where people are required to carry loads up to 15 Kg. The person can also ride the gadget alongwith the load strapped on to the gadget.</span>
							</div>
						</article>
						
					
						
						<article class="portfolio-item grid-outer">
						
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">SACCHARIFICATION OF BIOMASS USING MICROORGANISM COUPLED WITH ELECTRO-STIMULATION</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711008957</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">A method to increase the rate of enzymatic saccharification of biomass by electro-stimulation maintained inside the fungal co-cultures of lignin peroxidase and endo and exoglucanase and β-glucosidase producing strains of fungus. It maybe be understood that the electro-stimulation of enzymatic hydrolysis effects the enzyme based degradation of lingo-cellulose by increasing the pore size of biomass under the effect of phononic vibration of electric current.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">A BIODEGRADABLE SACHET FOR CLEANING DELICATE CLOTHES</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711022154</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">A biodegradable sachet for cleaning delicate clothes which includes detergent with fragrance and anti bacterial/ antifungal compounds.</span>
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">BIOFILTER FOR REMOVAL OF PERMANENT HARDNESS FROM HARD WATER</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN201711025361</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">A biofilter to remove permanent hardness from water. The technology is very simple and cost effective.</span>
							</div>
						</article>
						
						
						
					</div>
					
										
					
					
				</div>		
			</div>
		</section>

		
		
		<section>
			<div class="content-wrap mt0 pb0 mb0 pt50">
				<div class="container clearfix">
			
					<div class="heading-block center border-none">
						<h2>Sponsored Projects</h2>
						<span>In collaboration with the industry & governments.</span>
					</div>
					
					<div id="portfolio" class="portfolio grid-container portfolioc portfolio-3 portfolio-masonry clearfix">

						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research9.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Corrosion Auditing</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>1st Oct 2015</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">To carry out in situ corrosion auditing in oil & gas pipelines by implementing suitable economic methods to control corrosion</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research10.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Novel Heterocyclic Scaffolds</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>20th Oct 2015</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Designing & combining components to Formulate the Novel Heterocyclic Scaffolds as potential anti-diabetic agents to reduce toxicity.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research11.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Self-focusing ultra-short pulses</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>12th April 2013</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">By using strong focused laser profiles for producing exciting nonlinear phenomena, like harmonic generation, soft-x-ray in plasma under density transition.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research12.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">SNEDDS</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>2nd Oct 2013</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content"><strong>Self nano emulsifying drug delivery systems</strong> formulates polypeptide-k, an oral phytoinsulin for the treatment of diabetes mellitus as an alternative to insulin.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research14.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Bi-layer Therapeutic System</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>4th Feb 2016</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Developing nano carrier bi-layer therapeutic system to ensure transportation of drug molecules to the affected area for the treatment of nail diseases.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research15.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Molecule Investigation</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>14th May 2013</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Analysing the transfer of radiations from cosmic objects using the collisional rate coefficients of <strong>H2CS and H2CC molecules.</strong></span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/research/research13.jpg" >
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">IC-Impact</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>18th Jan 2016</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Innovative low-cost green technology for treatment of wastewater discharging into tributaries and rivers.</span>
							</div>
						</article>
						
												
						<article class="portfolio-item grid-outer">
							
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Sugar Free Draksha Asava</h3>
								<ul class="entry-meta clearfix pb15 pl20 pr25">
									<li>IN3680/DEL/2012</li>
								</ul>
								<span class="pb15 pl20 pr25 entry-content">Sugar free Draksha Asava is completely herbal fermented liquid preparation. It is free from sugars while it contains not more than 10% and not more than 3% of self generated alcohol. It has therapeutic value for piles, tastelessness, heart diseases, and many other diseases.</span>
							</div>
						</article>
						
						
					</div>
					

					
					
					
				</div>				
			</div>
		</section>
  
  
		<section class="section mb0 pt0 mt0 pb0">
			<div class="content-wrap pb0 pt50">
				<div class="container clearfix">
					
					<div class="heading-block center border-none">
						<h2>Conferences</h2>
						<span>Research conferences are a continuum at LPU</span>
					</div>
					
					
					<!-- Posts
					============================================= -->
					
					<div id="portfolio" class="portfolio grid-container portfoliod portfolio-3 portfolio-masonry clearfix">

						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con5.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">International Conference on Strategies for Global competitiveness and Economic growth</h3>
								<span class="pb15 pl20 pr25">Dissemination of contemporary research on a wide range of strategic issues related to global competitiveness of business and holistic growth of economies.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con6.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">NICHE – Neo International Conference on Habitable Environments</h3>
								<span class="pb15 pl20 pr25">The NICHE II – 2015 conference’s principle aim was to examine and observe how we can shift towards welfare and equity within habitable environment.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con12.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Prospects and competitive challenges in Global Hospitality and Tourism Industry</h3>
								<span class="pb15 pl20 pr25">Aimed  to discuss challenges in global hospitality and tourism industry.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con12.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Shannon 100- 3<sup style="text-transform:lowercase;">rd</sup> international conference on computing sciences</h3>
								<span class="pb15 pl20 pr25">Propose new technologies, share experiences and discuss future solutions for design infrastructure for ICT.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con2.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">5<sup style="text-transform:lowercase;">th</sup> Nursing conference</h3>
								<span class="pb15 pl20 pr25">To review the needs of today's nursing, updates in practices and workstations to learn the skills & technological aspects required during care of sick patients.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con4.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">EBAS- Conference on Exploring Basic and Applied Science</h3>
								<span class="pb15 pl20 pr25">To share knowledge and applications of basic and applied sciences to future generation frontiers in order to meet the challenges being faced by society.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con10.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Emerging opportunities in pharmacy profession</h3>
								<span class="pb15 pl20 pr25">The aim of the conference was to increase awareness regarding the different opportunities available for the pharmacy professionals</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con7.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Recent Trends in Pharma Industry: Bridging the Gaps in Pharmaceutical Education</h3>
								<span class="pb15 pl20 pr25">To discuss crucial matters concerning innovative technologies used in drug delivery and diagnostics budding in the area of pharmaceutical sciences.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con1.jpg" >
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">4<sup style="text-transform:lowercase;">th</sup> Nursing Conference on Emergency & Resuscitation</h3>
								<span class="pb15 pl20 pr25">In order to educate the nursing students of the state about management of emergency and resuscitation cases.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con11.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Shaping a Future Classroom: A Global Perspective</h3>
								<span class="pb15 pl20 pr25">This conference aimed recent system of education, future education, shaping future class room and its various aspects.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con8.jpg" >
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Turing100-International Conference on Computing Sciences</h3>
								<span class="pb15 pl20 pr25">Conducted in collaboration with IEEE, INNS & CRSI . To discuss practical challenges encountered and the solutions adopted in the broad area of computing Sciences.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con9.jpg" >
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Wilkes100-International Conference on Computing Sciences</h3>
								<span class="pb15 pl20 pr25">Conducted in collaboration with INNS, ACRS & Elsevier.  To celebrate the birth centenary of father of British computing and discuss real world problems and solutions in the area of computing.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con3.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Bhartiya Vigyan Sammelan</h3>
								<span class="pb15 pl20 pr25">BVS is a collaborative effort of Vijnana Bharti (VIBHA) with Lovely Professional University and Punjab Technology University with the theme Science for Global Development.</span>
							</div>
						</article>
                        
                        
                        
                        
                        	<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con14.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">NICHE (Neo International Conference on Habitable Environments) - 2016</h3>
								<span class="pb15 pl20 pr25">Taking cognizance of the concern for environment, LPU organizes NICHE to bring Architects, Environmentalists, Urban Planners, Academicians, and students for concerted efforts on creating Sustainable Habitats for the NextGen.</span>
							</div>
						</article>
						
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/con16.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">ICICS 2016 : International Conference on Intelligent Circuits and Systems</h3>
								<span class="pb15 pl20 pr25">ICICS is an LPU endeavour to take congnizance of emerging technological advancements by bringing together the academians, technologists, and industry experts for ideation on communication systems and computing technology.</span>
							</div>
						</article>
						
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/stevia.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">International symposium on Stevia-the natural sweet revolution</h3>
							
							</div>
						</article>
						
								<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/education.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">International conference on Global Trends in teacher education</h3>
							
							</div>
						</article>
						
						
								<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/nctace.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">National conference on technical advancements in civil engineering</h3>
							
							</div>
						</article>
						
						
							<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/lpunasyacon.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">National conference on Amalgamation of recent Pharmaceutical Developments in Ayurveda</h3>
							
							</div>
						</article>
						
						
						<article class="portfolio-item grid-outer">
							<div class="entry-image">
								<img width="auto" height="auto" class="lazy" data-lazyload="imgs/conference/sgceg.jpg">
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25 uppercasenew">Strategies for Global Competitiveness and Economic Growth - 2017</h3>
							
							</div>
						</article>
						
					</div>
					
					
					<script type="text/javascript">

						jQuery(window).load(function(){

							var $container = $('#portfolio');

							$container.isotope({ transitionDuration: '0.65s' });

							$('#portfolio-filter a').click(function(){
								$('#portfolio-filter li').removeClass('activeFilter');
								$(this).parent('li').addClass('activeFilter');
								var selector = $(this).attr('data-filter');
								$container.isotope({ filter: selector });
								return false;
							});

							$('#portfolio-shuffle').click(function(){
								$container.isotope('updateSortData').isotope({
									sortBy: 'random'
								});
							});

							$(window).resize(function() {
								$container.isotope('layout');
							});

						});

					</script>

					

				</div>
			</div>
		</section>
		
		
		
		
		
		
		
		
		
		
		<section >	
			<div class="content-wrap pb0 pt50">
				<section id="section-Facilities" class="page-section">
					<div class="container clearfix">

						<div class="heading-block center border-none">
							<h2>Research Enablement</span></h2>
							<span>How we help our researchers..</span>
						</div>
						
						
						<div id="portfolio" class="portfolio grid-container portfolioe portfolio-3 portfolio-masonry clearfix">

							<article class="portfolio-item grid-outer">
								<div class="portfolio-desc">
									<h3 class="pl20 pr25 uppercasenew">Research Excellence Awards</h3>
									<span class="pb15 pl20 pr25">Research Excellence Awards are presented to the achievers during Teachers day celebration every year.  LPU Chancellor Award of cash incentive Rs. 1 lakh is awarded to 5 faculty members, LPU Pro Chancellor Award of cash incentive Rs.50,000 is awarded to 10 faculty members, LPU Vice Chancellor Award of cash incentive Rs.25,000 is awarded to 20 faculty members and LPU Young Researcher Award of cash incentive Rs.10,000 is awarded to 20 faculty members.</span>
								</div>
							</article>
							
							<article class="portfolio-item grid-outer">
								<div class="portfolio-desc">
									<h3 class="pl20 pr25 uppercasenew">University Scholarly Communication Grant (USCG)</h3>
									<span class="pb15 pl20 pr25">The goals of USCG are to foster greater dissemination of the work of LPU Scholars, Showcase intellectual productivity of the University across the world and to support innovative models of scholarly publishing. This grant is available to LPU community where in University shares the article processing charges for publishing papers in journals of repute. (Journals indexed in WoS/Scopus).</span>
								</div>
							</article>
							
							<article class="portfolio-item grid-outer">
								<div class="portfolio-desc">
									<h3 class="pl20 pr25 uppercasenew">Travel Grant</h3>
									<span class="pb15 pl20 pr25">LPU is committed to increase the exposure of its faculty and staff by encouraging them to attend national and international conferences, collaborative research work, workshops, seminars and symposia for their professional growth and excellence. University provides support to its research community by providing them travel grant, which can be up to 40000 INR, to meet the expenses of attending research related events.</span>
								</div>
							</article>
							
							<article class="portfolio-item grid-outer">
								<div class="portfolio-desc">
									<h3 class="pl20 pr25 uppercasenew">Monetary benefits to principal investigator of sponsored research projects</h3>
									<span class="pb15 pl20 pr25">Principal and co-investigators of the externally sponsored research projects are provided 25% of overhead charges as well relaxation in the teaching load.</span>
								</div>
							</article>
							
							<article class="portfolio-item grid-outer">
								<div class="portfolio-desc">
									<h3 class="pl20 pr25 uppercasenew">Leave point</h3>
									<span class="pb15 pl20 pr25">The research contribution of the LPU faculty helps them to earn leave points which can be availed as leaves for attending research and academic related events.</span>
								</div>
							</article>
							
						</div>
												
						
					<script type="text/javascript">

						jQuery(window).load(function(){

							//var $container = $('.portfolioa, .portfoliob, .portfolioc, .portfoliod, .portfolioe');
							var $container = $('.portfolio');

							$container.isotope({ transitionDuration: '0.65s' });

							$('#portfolio-filter a').click(function(){
								$('#portfolio-filter li').removeClass('activeFilter');
								$(this).parent('li').addClass('activeFilter');
								var selector = $(this).attr('data-filter');
								$container.isotope({ filter: selector });
								return false;
							});

							$('#portfolio-shuffle').click(function(){
								$container.isotope('updateSortData').isotope({
									sortBy: 'random'
								});
							});

							$(window).resize(function() {
								$container.isotope('layout');
							});

						});

					</script>
						
						<div class="clear"></div>

					</div>					
				</section>
			</div>					
		</section>
		
		
		<!-- Footer
		============================================= -->
			﻿
<!-- Footer============================================= -->
<style>
	.iccash li{margin-bottom:15px;}
	#myLargeModal .mod-btn-6.active {background: #f68220 none repeat scroll 0 0;border-color: #f68220;color: #fff;}	
	#myLargeModal .mod-btn-6:hover {background: #f68220 none repeat scroll 0 0;border-color: #f68220;color: #fff;}	
	.nirf-hd {color: #333333;text-transform: uppercase;font-size: 14px;font-weight: 500;text-decoration: none;line-height: 25px;}	
	.nirf-hd span {text-transform: none;color: #f68220;	text-decoration: underline;	}	
	.nirf li i {color: #f68220;	font-size: 11px;padding-right: 10px;}	
	.vertical-alignment-helper {display: table;height: 100%;width: 100%;}
	.vertical-align-center {display: table-cell;vertical-align: middle;}
	.modal-content {width: inherit;height: inherit;margin: 0 auto;}	
	.disciplines-popup {-webkit-border-radius: 10px !important;-moz-border-radius: 10px !important;border-radius: 10px !important;}	
	.disciplines-popup li {background: rgba(0, 0, 0, 0) url("//www.lpu.in/images/icons/widget-link.png") no-repeat scroll left 5px;line-height: 25px;border: medium none !important;color: #444;font-size: 14px;list-style: outside none none;padding-left: 15px;}	
	#dexample td {border: none !important;background: url(//www.lpu.in/images/icons/widget-link.png) no-repeat;padding: 0 0 0 15px;display: inline-block}	
	#dexample tr {background: none !important;border: medium none;display: inline-block;float: left;padding: 0 0 0 15px;width: 33%;}	
	.no-footer,	.dataTables_wrapper.no-footer .dataTables_scrollBody {border: none !important;}	
	#disciplines-popup table.dataTable thead th,#disciplines-popup table.dataTable thead td {border: none !important;}	
	@media screen and (min-width: 320px) and (max-width: 1023px) {#dexample tr {float: none;width: 100%;}}	
		
	.intercom .feature-box .fbox-icon {	width: 55px;height: 55px;}
	.intercom .feature-box .fbox-icon i {line-height: 58px;background-color: #ff4358;}	
	.intercom .fbox-effect .fbox-icon i:hover,.intercom .fbox-effect:hover .fbox-icon i {background-color: #ff4358;}	
	.intercom .fbox-effect .fbox-icon i:after {box-shadow: none;left: 0;}
	.intercom .badge {position: absolute;z-index: 999;right: 0;cursor: pointer;}	
	.toast-top-left {bottom: 80px;top: auto !important;}	
	.badge-color {background: #ff4358;color: #fff;box-shadow: 0 !important;}	
	.mt75 {	margin-top: 75px}	
	/*body.modal-open {overflow-y: scroll;}*/	
	.intercom .icon-comment:before {content: "\e65f";left: 14px;position: absolute;}	
	.m10 {margin-top: 9%;}
	.m3 {margin-top: 3%;}	
	.modal-dialog {	margin: 0 auto;}	
	.modal-body {padding: 0 15px !important;}	
	#noti .entry-content {background: #fff;}
	.single-modal {width: 300px !important;}
	.double-modal {	width: 600px !important;}
	.col-61 {width: 50% !important;}	
	.col-12 {width: 100% !important;}	
	#myLargeModal .modal-content {background: #EBEBEB;}	
	#myLargeModal .mod-btn {border-color: #2985C6;color: #2985C6;width: 96%;text-align: center;}	
	#myLargeModal .mod-btn:hover {border-color: #2985C6;color: #fff;background: #2985C6;}	
	#myLargeModal .mod-btn-6 {border-color: #2985C6;color: #2985C6;width: 45%;text-align: center;padding: 0 3px!important;font-size: 9px;}	
	#myLargeModal .mod-btn-6:hover {border-color: #2985C6;color: #fff;background: #2985C6;}	
	#myLargeModal .modal-header {padding: 7px;border-color: #d6d6d6;}
	.pr7 {padding-right: 7px;}
	.pl7 {padding-left: 7px;}	
	@media(max-width:770px) {#noti .entry-content p {min-height: auto !important;}#myLargeModal.modal{overflow-y:scroll !important;}}	
	.popupwindow {cursor: pointer;}
</style>

<!--Start of Zendesk Chat Script-->
<script type="text/javascript">
window.$zopim || (function(d, s) {
    var z = $zopim = function(c) {
            z._.push(c)
        },
        ps = z.s =
        d.createElement(s),
        e = d.getElementsByTagName(s)[0];
    z.set = function(o) {
        z.set.
        _.push(o)
    };
    z._ = [];
    z.set._ = [];
    ps.async = !0;
    ps.setAttribute("charset", "utf-8");
    ps.src = "https://v2.zopim.com/?5zU5ycyGChvBrSvnk5mgdxLN5fzikAC3";
    z.t = +new Date;
    ps.
    type = "text/javascript";
    e.parentNode.insertBefore(ps, e);
	
})(document, "script");
</script>
<!--End of Zendesk Chat Script-->


<div class="right-new-bar  hidden-sm hidden-xs hidden-xxs">


<div class="mb5 text-right"><a target="_blank"  href="//iviewd.com/lpu/"><img width="" height="auto" src="//www.lpu.in/images/virtual-tour.png" alt=""></a></div>




	<div class="right-icons apply-now" style="display:none !important">
		<div class="rotate" href="#LoginModal1" data-lightbox="inline" style="cursor:pointer">Apply Now</div>
	</div>
	<div class="right-icons call">
		<a href="" class="ppwnd white-tooltip" data-toggle="tooltip" data-placement="left" title="Schedule a Call">
		<i class="icon-call ml5"></i></a>
	</div>
	<div class="right-icons d-one">
		<a href="" target="_blank" class="white-tooltip si-whatsapp hidden-sm hidden-xs hidden-xxs" data-toggle="tooltip" data-placement="left" title="">
			<img width="auto" height="auto" src="//www.lpu.in/images/whatsapp-icon.png" alt="">
		</a>		
	</div>

	<div class="right-icons international">
		<a href="" target="_blank" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="For SAARC Nations::+91-9780005961 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;For Other Nations::+91-9855322332">
			<img width="auto" height="auto" src="//www.lpu.in/images/whatsapp-icon.png" alt="">
		</a>
	</div>
	<div class="right-icons international">
		<a href="//www.lpu.in/international/contact-us.php" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="Enquire Now ">
			<img width="auto" height="auto" src="//www.lpu.in/images/enquire-icon.png" alt="">
		</a>
	</div>
	<div class="right-icons international">
		<a href="//admission.lpu.in" target="_blank" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="Apply Now">
			<img width="auto" height="auto" src="//www.lpu.in/images/apply-now-icon.png" alt="">
		</a>
	</div>
	<div class="right-icons ltown"><a href="//www.lpu.in/admission/lpu-in-your-town.php#lpu-town" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="LPU in Your Town"><i class="icon-location ml3"></i></a>
	</div>
	<div class="right-icons chatimg hide" style="height:43px;">
	</div>
</div>
<footer id="footer" class="dark remove-div" style="background-color: #222;">
	<div class="container mt15 clearfix" style="font-size:8px">E&OE </div>
	<div class="container">
		<!-- Footer Widgets
				============================================= -->
		<div class="footer-widgets-wrap clearfix" style="padding:20px 0 10px 0">
			<div class="col_two_third">
				<div class="widget clearfix">
					<!-- -->
					<div class="row">
						<div class="col-md-5 col-sm-12 col-xs-12 bottommargin-sm widget_links">
							<h4 class="mb10">Admissions</h4>
							<ul>
								<li><a href="//www.lpu.in/admission/admissions.php"> Admissions 2019 - 20 </a>
								</li>
								<li><a href="//www.lpu.in/international/international_students.php"> International Admissions 2019 - 2020 </a>
								</li>
								<li><a target="_blank" href="//www.lpude.in/admissions/overview.php">Distance Education Admissions</a>
								</li>
								<li><a href="//www.lpu.in/scholarship/scholarship.php">Scholarship</a>
								</li>
								<li><a title="Fee Deposit" href="//www.lpu.in/frmloginaccounts.aspx">Fee Deposit</a>
								</li>
								<li><a title="Top Engineering Courses (B.Tech - M.Tech)" href="//www.lpu.in/engineering/" target="_blank">
								Top Engineering Courses</a>
								</li>
							</ul>
							<h4 class="mb10 mt20">Media</h4>
							<ul>
								<li><a href="//www.lpu.in/tv-ads.php">TV Ads</a>
								</li>
								<li class="hide"><a href="//www.lpu.in/print-ads.php">Print Ads</a>
								</li>
								<li><a href="//www.lpu.in/newshome.aspx">Media Coverage</a>
								</li>
							</ul>
						</div>
						<div class="col-md-4 col-sm-12 col-xs-12 bottommargin-sm widget_links">
							<h4 class="mb10">Other Links:</h4>
							<ul>
								<li><a href="//alumni.lpu.in" target="_blank"> Alumni </a>
								</li>
								<li><a href="//www.lpu.in/campus_life/entrepreneurship.php"> Entrepreneurship </a>
								</li>
								<li class="hide"><a href="//www.lpu.in/campus_life/campus-events.php"> Events </a>
								</li>
								
								
								<li><a href="//www.lpu.in/EventCertificate/index.aspx"> Download Event Certificate </a>
								<li><a href="//www.lpu.in/authenticate" target="_blank" title="Certificate Authentication">Certificate Authentication</a>
								</li>
								<li><a target="_blank" title="Fee Deposit" href="//nad.gov.in/">National Academic Depository</a>
								</li>
								<li><a href="//www.lpu.in/jpd" target="_blank" title="Joint Placement Drive">Joint Placement Drive</a>
								</li>
								<li> <a data-toggle="modal" data-target="#convocation" href="#">9th Convocation Gallery</a> </li>
								<li> <a href="//www.lpu.in/knowledge-brain-storm/index.php">Knowledge Brainstorm</a> </li>
								<li> <a href="" class="" data-toggle="modal" data-target="#nirf">NIRF</a>
								</li>
								<li> <a href="//www.lpu.in/lpusummerschool/index.php">LPU Summer School 2018</a> </li>
							</ul>
						</div>


						<div class="col-md-3 col-sm-12 col-xs-12  widget_links">

							<h4 class="mb10">&nbsp;</h4>
							<ul>
							<li> <a href="//schools.lpu.in" target="_blank">Schools.lpu.in</a> </li>
								<li><a id="bt-notification" href="#" data-toggle="modal" data-target="#myLargeModal">Education Awards</a>
								</li>
								<li> <a href="//www.lpu.in/explorica/index.php" target="_blank">Explorica</a> </li>
								<li> <a href="//www.lpu.in/downloads/ssr.pdf" target="_blank">LPU SSR</a> </li>
								<li> <a href="https://ums.lpu.in/lpuums/" target="_blank">Parent's Login</a> </li>
								<li> <a href="https://ums.lpu.in/lpuums/" target="_blank">UMS Login</a>
								</li>
								<li><a href="//www.lpu.in/about_lpu/tour_lpu.php" target="_blank">Campus Visit</a>
								</li>
								<li><a href="//www.lpu.in/jobs/jobs_at_lpu.php" target="_blank">Jobs At LPU</a>
								</li>
								<li><a href="//www.lpu.in/contact_us/contact-us.php" target="_blank">Contact</a> </li>
								<li><a href="https://docs.google.com/forms/d/e/1FAIpQLScHTG-vQoSOKIRPGnuNZ2bc66M6BOpJXOxBUxOFAUdfz35UkA/viewform" target="_blank">Supplier Registration</a>
								</li>
								<!--<li><a href="//www.lpu.in/downloads/Corigendum-Indian-Express-29-8-18.html" target="_blank">Corrigendum</a></li>-->
						</div>
					</div>
					
				</div>
			</div>
			<div class="col-md-3 col-sm-12 col-xs-12">				
				<div class="widget clearfix" style="margin-bottom: -20px;">
					<div class="row">
						<div class="col-md-12 clearfix bottommargin-sm">
							<a href="//www.lpu.in/about_lpu/tour_lpu.php" style="margin-right: 10px;">
                				<img width="auto" height="auto" src="//www.lpu.in/images/360.gif"> 
              				</a>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 clearfix">
							<h4 class="mt0 pr10" style="display:inline;float:left">Download App</h4>
							<div style="display:inline;float:left">
								<a title="Appstore" class="social-icon si-rounded si-appstore" href="https://itunes.apple.com/in/app/lputouch/id509819753?mt=8" target="_blank">
							<i class="icon-appstore"></i>
							<i class="icon-appstore"></i>
						</a>
						<a title="Android" class="social-icon si-rounded si-android" href="https://play.google.com/store/apps/details?id=ums.lovely.university&hl=en" target="_blank">
							<i class="icon-android"></i>
							<i class="icon-android"></i>
						</a>							
							</div>
							<div class="clearfix"></div>
								<div class="col-md-12 col-sm-12 col-xs-12 pl0 widget_links">
              <div class="mb10">Subscribe Newsletter</div>
            <!-- <p class="mb0">Stay updated about latest happenings, events and campus news</p>-->
          <div id="widget-subscribe-form-result" data-notify-type="success" data-notify-msg=""></div>
          <div id="widget-subscribe-form-result2" data-notify-type="error" data-notify-msg=""></div>
			
			<div class="widget subscribe-widget clearfix mt15 mb15">
				<form id="widget-subscribe-form" action="#" role="form" method="post" class="nobottommargin">
					<div class="input-group divcenter">
						<span class="input-group-addon"><i id="spinner" class="icon-email2"></i></span>
							<input style="height:32px;" type="email" id="widget-subscribe-form-email" name="email" class="form-control required email plr6" placeholder="Enter your Email">
							<span class="input-group-btn">
								<button class="btn btn-success plr6" id="subs-btn" type="submit">Go</button>
							</span>
								</div>
							</form>
						</div>
		
            </div>
							
							
							<div>
								<span title="Tel"><strong>Tel:</strong></span> +91-1824-404404 <br>
								<span title="Toll Free"><strong>Toll Free:</strong></span> 1800 102 4431<br>
								<!--<span title="Helpline"><strong>Helpline:</strong></span> 01824 444545<br>-->
							</div>
							<div class="col_last tleft mt20">
								<div class="fleft clearfix">
									<div class="fleft">
										<a href="https://www.facebook.com/LPUUniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-facebook">
										<i class="icon-facebook"></i>
										<i class="icon-facebook"></i>
									  </a>
										<a href="https://twitter.com/lpuuniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										  </a>
										<a href="https://plus.google.com/+LpuIn-lovely-professional-university/posts" target="_blank" class="social-icon si-small si-borderless nobottommargin si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										  </a>
										<a href="https://www.linkedin.com/company/lovely-professional-university" target="_blank" class="social-icon si-small si-borderless nobottommargin si-linkedin">
											<i class="icon-linkedin"></i>
											<i class="icon-linkedin"></i>
										  </a>	
										<a href="https://www.youtube.com/user/LPUuniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-gplus">
											<i class="icon-youtube"></i>
											<i class="icon-youtube"></i>
										  </a>
									</div>
									<div class="clear"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- .footer-widgets-wrap end -->

	</div>
	
			<!-- Copyrights
			============================================= -->
	<div id="copyrights" style="padding:10px 0">
		<div class="container clearfix">
			<div class="row clearfix">
				<div class="col-md-6 col-sm-12">
					<div class="copyrights-menu copyright-links clearfix">
						<!--Copyrights &copy; 2014 All Rights Reserved by Canvas Inc.<br>-->
						<img width="auto" height="auto" src="//www.lpu.in/images/footer-widget-logo.png" alt="" class="alignleft" style="margin-top: 20px; padding-right: 18px; border-right: 1px solid #4A4A4A;"/>
						<p class="pt15 mb0">
							India's Largest University* <strong>Lovely Professional University</strong>, Jalandhar-Delhi, G.T. Road, Phagwara, Punjab (INDIA) -144411.<br/>Website: //www.lpu.in
						</p>
					</div>
				</div>
				<div class="col-md-6 col-sm-12 tright hidden-xs mt15">
					<div class="fright clearfix">
						<div class="copyrights-menu copyright-links nobottommargin">
							<a href="//www.lpu.in/downloads/Ragging.pdf" target="_blank">Anti-Ragging</a>/ <a style="cursor:pointer" target="_blank" data-toggle="modal" data-target="#sexual-harrassment-footer">ICCASH</a>/ <a href="//www.lpu.in/privacy.php">Privacy Policy</a>/ <a href="//www.lpu.in/disclaimer.php">Disclaimer</a> / <a href="//www.lpu.in/downloads/student-grievance-redressal-policy.pdf">Student Grievance Redressal</a> / <a href="#">RTI</a> / Problem with this page ? <a href="mailto:webmaster@lpu.co.in?subject=Mail from lpu.in Website">Contact Webmaster</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- #copyrights end -->
</footer>

	<!-- sexual-harrassment-footer modal start -->
	<div id="sexual-harrassment-footer" class="modal fade" role="dialog">
  <div class="modal-dialog modal-dialog-centered">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ICCASH</h4>
      </div>
      <div class="modal-body">
        <ol class="mt20 ml20 iccash"><li> <a href="https://www.lpu.in/downloads/sexual-harrassment-of-women-act-and-rules-2013.pdf" target="_blank"> The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013</a></li>
<li> <a href="https://www.lpu.in/downloads/UGC_regulations-harassment.pdf"  target="_blank">UGC ( Prevention, Prohibition and Redressal of sexual harassment of Women employees and students in Higher Educational Institutions ) Regulations, 2015</a></li>

<li> <a href="https://www.lpu.in/downloads/handbook-for-prevention-of-sexual-harassment%20at-workplace.pdf"  target="_blank">Handbook on Sexual Harassment of Women at Workplace issued by the Ministry of Women and Child Development, Government of India</a></li>
<li><a href="https://www.lpu.in/downloads/composition-of-ICCASH.pdf"  target="_blank"> Composition of Internal Complaints Committee against Sexual harassment</a></li>
<li> "Sexual Harassment Complaint Registration: - <a href="mailto:iccash@lpu.co.in" target="_top">iccash@lpu.co.in</a> </li>
<li><a href="//www.lpu.in/downloads/Anti-Sexual-Harrasment-policy.pdf" target="_blank">Anti Sexual Harrasment Policy</a> </li>

</ol>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
		<!-- sexual-harrassment-footer modal end -->




<!-- Go To Top -->
<div id="gotoTop" class="icon-angle-up"></div>
<!-- start intake top bar -->
<div id="intake" class="modal fade mt50" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-body mt30">
				<h4 class="text-center mb0"><strong>Admissions for 2017-2018 are closed, except for the following programmes.</strong><br></h4>
				<div class="col-md-12 pa0 mt20">
					<div class="col-md-12">
						<div class="title-block">
							<h4>B.Ed.</h4>
							<span>
								<a href="//admission.lpu.in/" target="_blank" class="more-link">Click Here</a>
							</span>
							<br> The last date to apply for admission is 31st August 2017.
						</div>
					</div>
					<div class="col-md-12">
						<div class="title-block">
							<h4> Integrated B.Ed. - M.Ed.</h4>
							<span>
								<a href="//admission.lpu.in/" target="_blank" class="more-link">Click Here</a>
							</span>
							<br> The last date to apply for admission is 31st August 2017.
						</div>
					</div>
					To enquire for admission in programmes other than mentioned above, <a href="//www.lpu.in/contact_us/contact-us.php" class="btn btn-default btn-xs">Click Here</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<div class="modal1 mfp-hide" id="disciplines-popup">
	<div class="block divcenter disciplines-popup" style="background-color: #FFF; width: 80%;">
		<div class="row nomargin clearfix">
			<div class="col-sm-12 col-padding pa30">
				<div class="heading-block center mb30">
					<h2>Disciplines / Departments</h2> </div>
				<table id="dexample" class="display" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electronics &amp; Communication Engg. (ECE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/business/" target="_blank">Management</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/pharmaceutical-sciences/" target="_blank">Pharmaceutical Sciences</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/computer-science-engineering/" target="_blank">Computer Science &amp; Engineering (CSE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/business/" target="_blank">Commerce</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/computer-science-engineering/" target="_blank">Information Technology (IT)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/business/" target="_blank">Economics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physiotherapy-and-paramedical-sciences/" target="_blank">Physiotherapy</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electronics &amp; Computer Engineering</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/law/" target="_blank">Law</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physiotherapy-and-paramedical-sciences/" target="_blank">Medical Laboratory Sciences</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">Mechanical Engineering (ME)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/hotel-management-and-tourism/" target="_blank">Hotel Management and Tourism</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biotechnology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">ME - Mechatronics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Architecture</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Microbiology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">Aerospace Engineering</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Planning</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Forensic Sciences</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Interior &amp; Furniture Design</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biochemistry</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Product &amp; Industrial Design</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Botany</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">Automobile Engineering (AE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/fashion-design/" target="_blank">Fashion Design</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Zoology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electrical Engineering (EE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Multimedia &amp; Animation</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Chemistry</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electrical and Electronics Engineering (EEE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Journalism &amp; Film Production</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Physics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/civil-engineering/" target="_blank">Civil Engineering (CE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Fine Arts</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Mathematics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biotechnology (BT)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Performing Arts</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Arts (Humanities)</a>
							</td>
						</tr>
						
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Psychology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">English and Foreign Languages</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biomedical Engineering</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Sociology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Indian Languages</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Chemical Engineering (CHE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">History</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Public Administration</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">CHE - Petroleum</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Political Science</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/polytechnic/" target="_blank">Polytechnic</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Geography</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Library Science</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/computer-applications/" target="_blank">Computer Applications</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/agriculture/" target="_blank">Food Technology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/education/" target="_blank">Education</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/agriculture/" target="_blank">Agriculture</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/agriculture/" target="_blank">Nutrition and Dietetics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-education/" target="_blank">Physical Education</a>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!-- Modal noti start -->
<div class="modal fade" id="myLargeModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" id="modal-width">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title upcom text-center" id="myLargeModalLabel">Events</h4>
				<!--<h4 class="modal-title upcom1 text-center">Knowledge BrainStorm</h4>-->
			</div>
			<div class="modal-body" id="single-modal">
				<div id="noti" class="row clearfix">
				
				
				
				
				
				<!--start3rd-->
					<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/studygrant.jpg" alt="studygrant">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
							<strong>Benefits of Taking LPUNEST</strong><br>
								Now qualifying LPUNEST can also get you an assured study grant of upto Rs. 3 Lac per student to study at IITs/ NITs/ IIMs/ NLUs / IHMs/ NIDs/ IIT( DoD/ IDC)/ IIITDM/ NIFTs. <strong>OR</strong> Get admission into LPU programmes and avail scholarship of upto Rs. 5 Lac per student.
							</p>
							<div class="text-center">								
							
								
								<a class="button button-small active button-border button-rounded" href="//www.lpu.in/studygrant/index.php" target="_blank">Read More</a>

							</div>
						</div>
					</div>
					<!--end3rd-->
				
				
					<!--start3rd-->
					<!--<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/knowledge.jpg" alt="knowledge-brain-storm">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
								<strong>“Knowledge Brainstorm” (KBS),</strong> conducted under Transforming Education Awards for school students of North Eastern states, has proved to be the most preferred aptitude test for the young minds. KBS has been designed to examine the general skills, critical thinking, analytical skills, and intellectual promise of school students.
							</p>
							<div class="text-center">								
							
								
								<a class="button button-small active button-border button-rounded" href="//www.lpu.in/knowledge-brain-storm/index.php" target="_blank">Read More</a>

							</div>
						</div>
					</div>-->
					<!--end3rd-->
					
					<!--start3rd-->
					<!--<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5 col-md-6">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/convocation.jpg" alt="FRESHMEN INDUCTION 2018" style="opacity: 1;">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
								<strong>9th Convocation on 22nd October 2018</strong><br> Lovely Professional University solicit your presence on the occasion of the “9th Annual Convocation Ceremony” for the class of 2017 and 2018 scheduled for Monday 22nd of October 2018 at 1000 hrs. Shri M. Venkaiah Naidu, Hon’ble Vice-President of India, has very kindly consented to be the Chief Guest and deliver the Convocation Address. 
							</p>
							<div class="text-center">	
								<a class="button button-small active button-border button-rounded" href="convocation/index.aspx" target="_blank">Read More </a>
							</div>
						</div>
					</div>-->
					<!--end3rd-->
					
					
					<!--start3rd-->
					<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5 col-md-6">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/educationawards.jpg" alt="AIU 2018" style="opacity: 1;">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
								<strong>Transforming Education Awards</strong><br>After the grand success of its first edition, the 2nd Edition of Transforming Education Awards is slated to be a much better affair as compared to last year. Upload a video of your inspiring teacher and win a grant of Rs. 50000 for your school, award of Rs. 25000 for your Teacher, and Rs. 10000 for yourself.   
							</p>
								<div class="text-center">	
								<a class="button button-small active button-border button-rounded" href="https://www.lpu.in/educationawards" target="_blank">Read More </a>
							</div>
						
						</div>
					</div>
					<!--end3rd-->
					
					
				</div>
			</div>
		</div>
	</div>
</div>

<!--<div class="modal fade" id="nirf" role="dialog">
	<div class="vertical-alignment-helper">
		<div class="modal-dialog vertical-align-center">
			<div class="modal-content cent">
				<div style="background-color:#2985c6;" class="modal-header">
					<button type="button" style="color:#fff; opacity:1;" class="close" data-dismiss="modal">&times;</button>
					<h4 style="background:#2985c5; color:#fff;" class="modal-title">NIRF</h4>
				</div>
				<div class="modal-body">
				<h4 class="text-center mt15 border-bottom">2018</h4>
					<ul class="iconlist nirf" style="margin-top:20px;">
						<li><a href="https://www.lpu.in/downloads/nirf/Architecture.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture<br></a>
						</li>
						<li><a href="https://www.lpu.in/downloads/nirf/Management.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a>
						</li>
						<li><a href="https://www.lpu.in/downloads/nirf/Pharmacy.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a>
						</li>
						
					</ul>
					<h4 class="text-center mt15 border-bottom">2019</h4>
					
					<ul class="iconlist nirf" style="margin-top:20px;">
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Engineering</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Overall</a></li>
						
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>-->

<div class="modal fade" id="nirf" role="dialog">
	<div class="vertical-alignment-helper">
		<div class="modal-dialog vertical-align-center">
			<!-- Modal content-->
			<div class="modal-content cent">
				<div style="background-color:#2985c6;" class="modal-header">
					<button type="button" style="color:#fff; opacity:1;" class="close" data-dismiss="modal">&times;</button>
					<h4 style="background:#2985c5; color:#fff;" class="modal-title">NIRF</h4>
				</div>
				<div class="modal-body">
				
						<div class="tabs tabs-bb clearfix" id="tab-9">

							<ul class="tab-nav clearfix">
								<li><a href="#tabs-33">2018</a></li>
								<li><a href="#tabs-34">2019</a></li>
							</ul>

							<div class="tab-container">

								<div class="tab-content clearfix" id="tabs-33">
									<ul class="iconlist nirf" style="margin:0 0 0 30px;">
										<li><a href="https://www.lpu.in/downloads/nirf/Architecture.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture<br></a>
										</li>
										<li><a href="https://www.lpu.in/downloads/nirf/Management.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a>
										</li>
										<li><a href="https://www.lpu.in/downloads/nirf/Pharmacy.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a>
										</li>
										
									</ul>
								</div>
								<div class="tab-content clearfix" id="tabs-34">
									<ul class="iconlist nirf" style="margin:0 0 0 30px">
										<li><a href="https://www.lpu.in/downloads/nirf/Architecture-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Management-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Pharmacy-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Engineering-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Engineering</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Overall-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Overall</a></li>										
									</ul>
								</div>
								

							</div>

						</div>

				</div>
				<div class="modal-footer">
					<ul class="iconlist text-center nirf" style="margin:0 !important;">
					<li class="nirf-hd">Email ID for Comments & Feedback : <span>registrar@lpu.co.in</span>
						</li>
					</ul>
				  </div>
			</div>
		</div>
	</div>
</div>






<div class="modal fade" id="convocation" role="dialog">
	<div class="modal-dialog modal-lg modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<div class="modal-title" style="font-size:18px; font-weight:400; color:#232020;"><b>9th Convocation</b></div>
			</div>
			<div class="modal-body">
				The photographs of the students, who attended the 9th Convocation are attached under the following links. Students can download the photographs based on the line number allocated to them, for the ceremony.
				<div class="col-md-12 pa0 mt20">
					<div class="col-md-12">
						<div class="title-block">
							<h4>Convocation (Gold Medalist and Ph.D)</h4>
							<span>
								<a href="https://photos.app.goo.gl/rc8kQAN5wERJhrLA7" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="divider mt10 mb10"><em class="icon-circle"></em>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 1)</h4>
							<span>
								<a href="https://photos.app.goo.gl/TUxf8rNFqDHMhphw5" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 2)</h4>
							<span>
								<a href="https://photos.app.goo.gl/hiHDZi2p45nvB4az6" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
				</div>
				<div class="divider mt10 mb10"><em class="icon-circle"></em>
				</div>
				<div class="col-md-12 pa0">
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 3)</h4>
							<span>
								<a href="https://photos.app.goo.gl/8efLx5unJD5AML3C9" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 4)</h4>
							<span>
								<a href="https://photos.app.goo.gl/AhpHq8WZhNU6pTEt7" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
				</div>
				<div class="divider mt10 mb10"><em class="icon-circle"></em>
				</div>
				<div class="col-md-12 pa0">
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 5)</h4>
							<span>
								<a href="https://photos.app.goo.gl/sHJLeF4z61nAsvUh7" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 6)</h4>
							<span>
								<a href="https://photos.app.goo.gl/nFQJppXSfGpYe4XBA" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<input type='hidden' id='getday' value="Wednesday" />


<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" defer></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" type="text/css"/>
<script src="//www.lpu.in/js/jquery.popupwindow.js" defer></script>

<script type="text/javascript">

            function isValidEmailAddress(emailAddress) {
            var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
            return pattern.test(emailAddress);
            }
         

          

	$(document).ready(function() {
		
	 $("#subs-btn").click(function () {
            if (!isValidEmailAddress($("#widget-subscribe-form-email").val())) {
            $('#widget-subscribe-form-result2').attr('data-notify-msg', 'Please enter a valid email address');
            SEMICOLON.widget.notifications($('#widget-subscribe-form-result2'));
            }
            else {
            $("#spinner").removeClass('icon-email2').addClass('icon-line-loader icon-spin');
            var id = $("#widget-subscribe-form-email").val();
            $.ajax({
            url: "../SubscribeNewsletter.asmx/Subscribe",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: "{email:'" + id + "'}",
            success: function (msg) {
            $("#spinner").removeClass('icon-line-loader icon-spin').addClass('icon-email2');
            $("#widget-subscribe-form-email").val('');
            if(msg.d=="success")
            {

            $('#widget-subscribe-form-result').attr('data-notify-msg', 'You have successfully subscribed');
            SEMICOLON.widget.notifications($('#widget-subscribe-form-result'));

            }
            else if(msg.d=="error")
            {
            $('#widget-subscribe-form-result2').attr('data-notify-msg', 'You have already subscribed');
            SEMICOLON.widget.notifications($('#widget-subscribe-form-result2'));

            }
            },
            error: function () {
            $("#widget-subscribe-form-email").val('');
            $("#spinner").removeClass('icon-line-loader icon-spin').addClass('icon-email2');
            }
            });
            return false;

            }
            });
			
		// $( "#educationawards" ).click( function () {
			// $( ".upcom" ).addClass( "hide" );
			// $( ".upcom1" ).removeClass( "hide" );
			// $( ".brainstorm" ).css( "display", "none" );
			// $( "#modal-width" ).removeClass( "double-modal" );
			// $( "#modal-width" ).addClass( "single-modal" );
			// $( ".diff-popup" ).removeClass( "col-md-4" );
			// $( ".diff-popup" ).removeClass( "col-61" );
			// $( ".diff-popup" ).removeClass( "col-md-6" );
		// } );


		$( "#bt-notification" ).click( function () {
			$( ".brainstorm" ).css( "display", "" );

			$( ".upcom" ).removeClass( "hide" );
			$( ".upcom1" ).addClass( "hide" );
			//$(".diff-popup").addClass("col-md-4");
			//$( "#modal-width" ).addClass( "double-modal" );
			//$("#modal-width").addClass("double-modal");
			//$( "#modal-width" ).removeClass( "single-modal" );
			$( ".diff-popup " ).addClass( "col-md-6" );

		} );
		$( "#footer" ).removeAttr( "style" );
		var pathname = window.location.pathname;
		var str_array = pathname.split( '/' );
		if ( str_array[ 1 ].replace( /^\s*/, "" ).replace( /\s*$/, "" ) == "international" ) {
			//alert('Number1');
			$( ".international" ).show();
			$( ".si-whatsapp" ).attr("href","https://api.whatsapp.com/send?phone=+919876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202019.");
			$( ".call" ).hide();
			$( ".ltown" ).hide();
		} else {
			$( ".international" ).hide();

			//Whatsapp Number change
			if ( $('#getday').val() == "Monday" || $('#getday').val() == "Wednesday" || $('#getday').val() == "Friday" ) {
				//alert('Number1');
				$( ".si-whatsapp" ).attr("href","https://api.whatsapp.com/send?phone=+919876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202019.");
				$( ".si-whatsapp" ).attr("title","Whatsapp only +919876022222");
			} else {
				//alert('Number2');
				$( ".si-whatsapp" ).attr("href","https://api.whatsapp.com/send?phone=+919876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202019.");
				$( ".si-whatsapp" ).attr("title","Whatsapp only +919876022222");
			}
		}

		$( '#dexample' ).DataTable( {
			scrollY: 500,
			"paging": false,
			"ordering": false,
			"info": false
		} );

		var numItems = $( '#single-modal .col-md-4' ).length;
		//alert(numItems);
		if ( numItems <= 3 ) {
			$( '#myLargeModal' ).addClass( 'm10' );

		}
		if ( numItems > 3 ) {
			$( '#myLargeModal' ).addClass( 'm3' );
		}
		if ( numItems == 1 ) {
			$( '#modal-width' ).addClass( 'single-modal' );
			$( '#noti .col-md-4' ).addClass( 'col-12' );
		}
		if ( numItems == 2 ) {
			$( '#modal-width' ).addClass( 'double-modal' );
			$( '#noti .col-md-4' ).addClass( 'col-61' );
		}
		var sWidth = $( window ).width();
		if ( sWidth < 770 ) {
			$( '#noti .col-md-4' ).removeClass( 'pl7' );
			$( '#noti .col-md-4' ).removeClass( 'pr7' );
			if ( numItems == 1 ) {
				$( '#modal-width' ).removeClass( 'single-modal' );
				$( '#noti .col-md-4' ).removeClass( 'col-12' );
			}
			if ( numItems == 2 ) {
				$( '#modal-width' ).removeClass( 'double-modal' );
				$( '#noti .col-md-4' ).removeClass( 'col-61' );
			}
		}
	} );

	function homeToast( vtype, vtitle, vmsgtext, vNavigationUrl, type ) {
		if ( type == "link" ) {
			toastr.options = {
				"closeButton": true,
				"debug": false,
				"newestOnTop": true,
				"progressBar": true,
				"positionClass": "toast-top-left",
				"preventDuplicates": true,
				//"onclick": daljit(),
				onclick: function () {
					window.open( vNavigationUrl, '_blank' );
				},
				"showDuration": "12000",
				"hideDuration": "1000",
				"timeOut": "10000",
				"extendedTimeOut": "1000",
				"showEasing": "swing",
				"hideEasing": "linear",
				"showMethod": "fadeIn",
				"hideMethod": "fadeOut"
			}
			toastr[ vtype ]( vmsgtext, vtitle )
		} else if ( type == "popup" ) {
			toastr.options = {
				"closeButton": true,
				"debug": false,
				"newestOnTop": true,
				"progressBar": true,
				"positionClass": "toast-top-left",
				"preventDuplicates": true,
				onclick: function () {
					$( "#" + vNavigationUrl ).trigger( "click" );
				},
				"showDuration": "12000",
				"hideDuration": "1000",
				"timeOut": "10000",
				"extendedTimeOut": "1000",
				"showEasing": "swing",
				"hideEasing": "linear",
				"showMethod": "fadeIn",
				"hideMethod": "fadeOut"
			}
			toastr[ vtype ]( vmsgtext, vtitle )
		}
	}

	function setModalMaxHeight( element ) {
		this.$element = $( element );
		this.$content = this.$element.find( '.modal-content' );
		var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
		var dialogMargin = $( window ).width() < 768 ? 20 : 60;
		var contentHeight = $( window ).height() - ( dialogMargin + borderWidth );
		var headerHeight = this.$element.find( '.modal-header' ).outerHeight() || 0;
		var footerHeight = this.$element.find( '.modal-footer' ).outerHeight() || 0;
		var maxHeight = contentHeight - ( headerHeight + footerHeight );

		this.$content.css( {
			'overflow': 'hidden'
		} );

		this.$element
			.find( '#myLargeModal .modal-body' ).css( {
				'max-height': maxHeight,
				'overflow-y': 'auto'
			} );
	}

	$( '.modal' ).on( 'show.bs.modal', function () {
		$( this ).show();
		setModalMaxHeight( this );
	} );

	$( window ).resize( function () {
		if ( $( '.modal.in' ).length != 0 ) {
			setModalMaxHeight( $( '.modal.in' ) );
		}
	} );
	$( '.ppwnd' ).on( 'click', function ( event ) {
		event.preventDefault();
		$.popupWindow( '//www.lpu.in/ClickToCall.php', {
		//$.popupWindow( '//172.17.60.228/ClickToCall.php', {
			width: 420,
			height: 630
		} );
	} );
</script>
<div style="display:none !important">

<!-- ===================================================== -->
<!-- Description of the code :Google Analytics -->
<!-- Applied Date: 06-Mar-2018 format  ( 05-Mar-2018 )  -->
<!-- Applicable for  Year: 2018 -->
<!-- Required Till: Permanent or Possible Month-Year till code is required -->
<!-- Source Agency : AdGlobal Etc -->
<!-- Contact Person : Abha  -->
<!-- ===================================================== -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-8319620-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-8319620-1');
</script>
<!-- ============ End Of Code  ============================== -->

<!-- ===================================================== -->
<!-- Description of the code :AMO Code -->
<!-- Applied Date: 06-Mar-2018 format  ( 05-Mar-2018 )  -->
<!-- Applicable for  Year: 2018 -->
<!-- Required Till: Permanent or Possible Month-Year till code is required -->
<!-- Source Agency : AdGlobal Etc -->
<!-- Contact Person : Abha  -->
<!-- ===================================================== -->
<img src="//pixel.everesttech.net/px2/5453?px_evt=t&ev_Landing_Page=1" width="1" height="1"/>
<!-- ============ End Of Code  ============================== -->
</div>		<!-- #footer end -->

	</div><!-- #wrapper end -->




	<div id="test-modal" class="mfp-hide get-code-window white-popup-block">
	<h1>Ph.D Scholars Details</h1>
	<div class="pop-scroll">
       <table id="example" class="display" width="100%" cellspacing="0">
        <thead>		
 <tr>
 <th>S.No</th>
				<th>Faculty</th>
				<th>Department</th>
				 <th>Name of Supervisor</th>
				 <th>Name of Ph.D Scholar</th>				
				 <th>Mode of Ph.D</th>
				 <th>Registration Number</th>
				 <th>Date of Registration</th>
			
				 <th>Research Topic</th>
				 <th>Likely Date of Completion of Ph.D</th>
				 <th>Availing Fellowship (YES/NO)</th>
				 <th>Funding Agency of Fellowship</th>
 </tr>
 </thead>
 <tfoot>
 </tfoot>
 <tbody>
 
  <tr>
    <td>1</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr S K Bawa</td>
    <td >Poonam</td>
    <td >Part Time</td>
    <td >40900062</td>
    <td >29-05-2009</td>
    <td >ASSOCIATION BETWEEN LEISURE TIME ACTIVITIES, SOCIAL NETWORK AND HEALTH STATUS  OF WOMEN RETIREES IN INDIA AND UK</td>
    <td >28-05-2015</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>2</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Sanjay Modi</td>
    <td >Megha Mehta</td>
    <td >Part Time</td>
    <td >40900056</td>
    <td >23-05-2009</td>
    <td >TALENT MANAGEMENT PRACTICES IN THE SERVICE SECTOR-A CASE STUDY OF PUNJAB AND HARYANA</td>
    <td >22-05-2015</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>3</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Mihir Mallick</td>
    <td >Amandeep Kaur</td>
    <td >Part Time</td>
    <td >40900121</td>
    <td >07-01-2010</td>
    <td >DEVELOPMENT AND EFFECTIVENESS OF INSTRUCTIONAL MODEL IN LIFE SCIENCE APPROACH IN CONGRUENCE TO THINKING PATTERN AND PARENTAL COGNITIVE STIMULATION.</td>
    <td >06-01-2016</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>4</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Sushil Kumar Singh</td>
    <td >Savita Nirankari</td>
    <td >Part Time</td>
    <td >40900125</td>
    <td >11-01-2010</td>
    <td >ATTITUDE OF SCHEDULED CASTE AND SCHEDULED TRIBE HOUSEHOLDS TOWARDS EDUCATION IN RELATION TO SPENDING PATTERN, SOCIO-ECONOMIC STATUS AND ASPIRATION LEVEL OF THEIR CHILDREN</td>
    <td >10-01-2016</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>5</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Mridula Mishra</td>
    <td >Anjali Khanna</td>
    <td >Part Time</td>
    <td >40900133</td>
    <td >29-01-2010</td>
    <td >ASSOCIATION OF WORK LIFE BALANCE WITH JOB SATISFACTION, JOB STRESS AND EMPLOYEE TURNOVER- A STUDY OF HOSPITALITY SECTOR</td>
    <td >28-01-2016</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>6</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr Pravin Kumar</td>
    <td >Pushkar Singh Adhikari</td>
    <td >Part Time</td>
    <td >41000233</td>
    <td >29-11-2010</td>
    <td >LIFESTYLE AND WELL-BEING OF SELECTED COHORT AGE EX-SPORTSMEN AND NON SPORTSMEN IN RELATION TO THEIR BODY COMPOSITION RESTING METABOLIC RATE AND MEDICAL HEALTH</td>
    <td >28-11-2016</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>7</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Neelam K Sharma</td>
    <td >Nidhi Sharma</td>
    <td >Part Time</td>
    <td >41000003</td>
    <td >17-05-2010</td>
    <td >EFFECT OF YOGIC AND RECREATIONAL ACTIVITIES FOR IMPROVING MALADAPTIVE AND DISTRESSED BEHAVIOUR OF AUTISTIC CHILDREN</td>
    <td >16-05-2016</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>8</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Harmanpreet Kaur</td>
    <td >Pradeep Kumar Singh</td>
    <td >Full Time</td>
    <td >11014218</td>
    <td >15-11-2010</td>
    <td >EFFECT OF TAEKWONDO AND PRANAYAM ON BLOOD LIPID PROFILE IN URBAN OBESE ADOLOSCENTS</td>
    <td >14-11-2016</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>9</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr Niraj</td>
    <td >Sukhmanpreet Kaur</td>
    <td >Full Time</td>
    <td >11014217</td>
    <td >10-11-2010</td>
    <td >INTERACTIVE ABILITY OF CARBAMATES WITH ESSENTIAL METALS OF SOIL</td>
    <td >09-11-2016</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>10</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Rajesh Verma</td>
    <td >Siddharth Sharma</td>
    <td >Part Time</td>
    <td >41000232</td>
    <td >29-11-2010</td>
    <td >MARKET ORIENTATION AND SERVICE QUALITY OF COMMERCIAL BANKS IN PUNJAB</td>
    <td >28-11-2016</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>11</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Neeta Raj Sharma</td>
    <td >Yogender Shokeen</td>
    <td >Part Time</td>
    <td >41100077</td>
    <td >23-07-2011</td>
    <td >TO INVESTIGATE THE ROLE OF TGF -B-SMAD PATHWAY IN CHRONIC MYELOID LEUKEMIA</td>
    <td >22-07-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>12</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Bhavana Adhikari</td>
    <td >Harkiran Kaur Sidhu</td>
    <td >Part Time</td>
    <td >41100101</td>
    <td >30-07-2011</td>
    <td >AN EXAMINATION OF RELATIONSHIP BETWEEN EMOTIONAL INTELLIGENCE, EMPLOYEE ENGAGEMENT, ETHICAL IDEOLOGY AND JOB PERFORMANCE</td>
    <td >29-07-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>13</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Niraj</td>
    <td >Sonu Sharma</td>
    <td >Part Time</td>
    <td >41100086</td>
    <td >26-07-2011</td>
    <td >POLITHENE ASSISTED ENHANCEMENT OF BINDER PROPERTY IN BITUMIN</td>
    <td >25-07-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>14</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Bansi Lal</td>
    <td >Suman Rani</td>
    <td >Part Time</td>
    <td >41100108</td>
    <td >01-08-2011</td>
    <td >INVESTIGATION OF RARE- EARTH ELEMENTS DOPED IN TERBIUM ALUMINUM GARNET AND ZINC OXIDE FOR WHITE LIGHT SOURCES</td>
    <td >31-07-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>15</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Sunil Sharma</td>
    <td >Rohit Gandhi</td>
    <td >Part Time</td>
    <td >41100142</td>
    <td >17-08-2011</td>
    <td >A STUDY OF GENERALIZED WEIGHTED COMPOSITION OPERATORS ON WEIGHTED HARDY SPACES</td>
    <td >16-08-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>16</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jaideep Randhawa</td>
    <td >Satpal Singh</td>
    <td >Part Time</td>
    <td >41100088</td>
    <td >26-07-2011</td>
    <td >POLITICS IN GOTHIC FICTION AND ITS RELEVANCE IN MODERN AGE</td>
    <td >25-07-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>17</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jaideep Randhawa</td>
    <td >Balkar Singh</td>
    <td >Part Time</td>
    <td >41100111</td>
    <td >03-08-2011</td>
    <td >POWER DISCOURSE ANALYSIS OF THE SELECTED TEXTS OF INDIAN SUBALTERN LITERATURE</td>
    <td >02-08-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>18</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jaideep Randhawa</td>
    <td >Vani Khurana</td>
    <td >Part Time</td>
    <td >41100114</td>
    <td >03-08-2011</td>
    <td >AN ANALYSIS OF DEPERSONALIZATION IN THE SELECTED NOVELS OF MARGARET ATWOOD AND ANITA DESAI</td>
    <td >02-08-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>19</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jit Pal Aggarwal</td>
    <td >Mangla Verma</td>
    <td >Part Time</td>
    <td >41100171</td>
    <td >01-09-2011</td>
    <td >THE DELEMMA OF THE OTHER: THE POLITICS OF INDENTURE EXILE AND DISPOSSESSION IN THE POST-COLONIAL FICTION OF V.S. NAIPAUL SALMAN RUSHDIE AND AMITAV GHOSH</td>
    <td >31-08-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>20</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Aneet Kumar</td>
    <td >Maninder Singh</td>
    <td >Part Time</td>
    <td >41100100</td>
    <td >29-07-2011</td>
    <td >PSYCHO-SOCIAL ADJUSTMENT OF HIGHER EDUCATION STUDENTS IN RELATION TO THEIR ACCULTURATIVE STRESS SOCIAL SUPPORT AND ACHIEVEMENT MOTIVATION: A CROSS  CULTURAL STUDY</td>
    <td >28-07-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>21</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Mihir Mallick</td>
    <td >Rekha Rani</td>
    <td >Part Time</td>
    <td >41100150</td>
    <td >18-08-2011</td>
    <td >METACOGNITIVE STRATEGY USAGES AND ATTRIBUTIONAL BELIEFS OF THE ADOLESCENTS: INFLUENCE ON CAREER ASPIRATION AND ACHIEVEMENT ORIENTATION</td>
    <td >17-08-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>22</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Vijay Kumar Chechi</td>
    <td >Simranjit Kaur</td>
    <td >Part Time</td>
    <td >41100170</td>
    <td >01-09-2011</td>
    <td >ACADEMIC RESILIENCE AMONG SENIOR SECONDARY STUDENTS: INFLUENCE OF METACOGNITION SELF EFFICACY LEARNING ENVIRONMENT</td>
    <td >31-08-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>23</td>
    <td >Business and Arts</td>
    <td >Fine Arts and Performing</td>
    <td >Dr. Abid Hadi</td>
    <td >Arjun Kumar Singh</td>
    <td >Part Time</td>
    <td >41100144</td>
    <td >17-08-2011</td>
    <td >JUXTAPOSITION OD FIGURATIVE AND ABSTRACT: A STUDY OF DYNAMICS OF HIMMAT SHAH'S ART</td>
    <td >16-08-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>24</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmaceutical Sciences</td>
    <td >Dr. Amit Bhatia</td>
    <td >Pardeep Kumar</td>
    <td >Part Time</td>
    <td >41100147</td>
    <td >18-08-2011</td>
    <td >STABILITY INDICATING HPLC METHOD DEVELPOMENT AND VALIDATION FOR THE DRUGS USED AS IMMUNOSUPPRESSANT IN COMBINATION THERAPY</td>
    <td >17-08-2017</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>25</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Anand Mohan</td>
    <td >Madhuri Girdhar</td>
    <td >Full Time</td>
    <td >11211261</td>
    <td >06-08-2012</td>
    <td >STRATEGIES FOR ENHANCED PRODUCTION OF POLYHYDROXYBUTYRATEANDITSBLENDINGFORNANOCOMPOSITEPREPARATION</td>
    <td >05-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>26</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Rekha</td>
    <td >Ashiq Khan</td>
    <td >Full Time</td>
    <td >11209265</td>
    <td >24-07-2012</td>
    <td >SYNTHESIS CHARACTERIZATION AND BIOLOGICAL ACTIVITY OF DION COMPLEXES OF THIO-AND SELENOSEMICARBAZONES.&rdquo;</td>
    <td >23-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>27</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Niraj</td>
    <td >Abdul Basit Wani</td>
    <td >Full Time</td>
    <td >11209269</td>
    <td >24-07-2012</td>
    <td >INTERACTION OF SALICYLIC ACID AND ITS DERIVATIVES WITH ESSENTIAL METAL IONS OF SOIL IN PRESENCE/ABSENCE OF SOIL ORGANIC MATTER</td>
    <td >23-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>28</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Sandeep Vij</td>
    <td >Rayees Farooq</td>
    <td >Full Time</td>
    <td >11211191</td>
    <td >04-08-2012</td>
    <td >KNOWLEDGE MANAGEMENT ORIENTATION AND ITS RELATIONSHIP WITH BUSINESS PERFORMANCE</td>
    <td >03-08-2018</td>
    <td >YES</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>29</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Pravin Kumar</td>
    <td >Loveleen Bala</td>
    <td >Full Time</td>
    <td >11208465</td>
    <td >17-07-2012</td>
    <td >EFFECT OF PROPRIOCEPTIVE NEUROMUSCULAR FACILITATION PILATE AND BALLET EXERCISES ON PHYSICAL FITNESS AND OPTIMUM HEALTH OF SCHOOL STUDENTS.</td>
    <td >16-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>30</td>
    <td >Technology and Sciences</td>
    <td >Nutrition&amp;Dietics</td>
    <td >Dr. Leena Parihar</td>
    <td >Cheenam Bhatia</td>
    <td >Full Time</td>
    <td >11211484</td>
    <td >09-08-2012</td>
    <td >EFFECT OF SUNFLOWER SEEDS ON HYPERCHOLESTEROLEMIA FATTY LIVER FASTING BLOOD GLUCOSE IN DIABETES MELLITUS TYPE  PATIENTS.</td>
    <td >08-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>31</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Manoj Kumar</td>
    <td >Pooja Bhadrecha</td>
    <td >Full Time</td>
    <td >11211174</td>
    <td >03-08-2012</td>
    <td >FUNCTIONAL CHARACTERIZATION OF RHIZOSPHERIC MICROORGANISMS ASSOCIATED WITH PLANT SYSTEMS GROWING UNDER EXTREME CLIMATIC CONDITIONS</td>
    <td >02-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>32</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. R.S. Kanwar</td>
    <td >Deepika Bhatia</td>
    <td >Full Time</td>
    <td >11211691</td>
    <td >13-08-2012</td>
    <td >DEVELOPMENT OF INNOVATIVE CLEAN-UP TECHNOLOGY (BIOFILTERS) FOR EFFECTIVE DEGRADATION OF TEXTILE DYE IN INDUSTRIAL WASTE WATER EFFLUENT</td>
    <td >12-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>33</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Joginder Singh Panwar</td>
    <td >Parvinder Kaur</td>
    <td >Full Time</td>
    <td >11211429</td>
    <td >08-08-2012</td>
    <td >DEVELOPMENT OF MICROBIAL CONSORTIUM FOR PHYTOREMEDIATION OF INDUSTRIALLY POLLUTED SOIL REGIONS OF JALANDHAR, PUNJAB</td>
    <td >07-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>34</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Akshay Garg</td>
    <td >Esther Vise</td>
    <td >Full Time</td>
    <td >11211370</td>
    <td >07-08-2012</td>
    <td >CONVENTIONAL AND MOLECULAR CHARACTERIZATION OF MYCOBACTERIUM SP. WITH SPECIAL REFERENCE TO NONTUBERCULOUS MYCOBACTERIA ISOLATED FROM ANIMALHUMAN AND ENVIRONMENTAL SAMPLES </td>
    <td >06-08-2018</td>
    <td >YES</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>35</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Joginder Singh Panwar</td>
    <td >Simranjeet Singh</td>
    <td >Full Time</td>
    <td >11209166</td>
    <td >24-07-2012</td>
    <td >COMPARATIVE SUTDY OF BIODEGRADATION OF PESTICIDES IN THE PRESENCE OF METAL IONS AND HUMIC ACID</td>
    <td >23-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>36</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Sakshi Sharma</td>
    <td >Rajvir Kaur</td>
    <td >Full Time</td>
    <td >11209996</td>
    <td >28-07-2012</td>
    <td >GLASS CEILING:ASSESMENT IMPACT AND ROLE OF MODERATORS IN SERVICE SECTOR</td>
    <td >27-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>37</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. GNPV Babu</td>
    <td >Mandeep Kaur</td>
    <td >Full Time</td>
    <td >11211635</td>
    <td >11-08-2012</td>
    <td >PERFORMANCE OF RURAL COOPERATIVE BANKS IN PERSPECTIVE OF COMPUTERIZATION</td>
    <td >10-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>38</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Anoop Beri</td>
    <td >Shilpa Sharma</td>
    <td >Full Time</td>
    <td >11212107</td>
    <td >19-08-2012</td>
    <td >ROLE OF NAAC ACCREDITION IN QUALITY IMPROVEMENT: AN EVALUATIVE STUDY OF NORTH INDIAN UNIVERSITIES.</td>
    <td >18-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>39</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Mridula Mishra</td>
    <td >Chanchal</td>
    <td >Full Time</td>
    <td >11212171</td>
    <td >20-08-2012</td>
    <td >RELATIONSHIP OF COMPENSATION ON JOB SATISFACTION ORGANISATIONAL COMMITMENT AND EMPLOYEE RETENSION ON SALES PERSONNEL OF PHARMACEUTICAL SECTOR IN PUNJAB.</td>
    <td >19-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>40</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Manohar Lal</td>
    <td >Hardeep Singh</td>
    <td >Full Time</td>
    <td >11212187</td>
    <td >21-08-2012</td>
    <td >PSYCHO-PHYSIOLOGICAL AND MORPHOLOGICAL CHARACTERISTICS OF KABADDI PLAYERS IN RELATION TO THEIR PERFORMANCE.</td>
    <td >20-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>41</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Manohar Lal</td>
    <td >Kiran</td>
    <td >Full Time</td>
    <td >11212189</td>
    <td >21-08-2012</td>
    <td >STUDYOFPSYCHOPHYSICALCHARACTERISTICSOFVEGETARIANANDNONVEGETARIANSPORTSPERSONSINRELATIONTOTHEIRLEVELOFPARTICIPATION</td>
    <td >20-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>42</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr.Sanjay Prasad Panday</td>
    <td >Gowher Ahmad Naik</td>
    <td >Full Time</td>
    <td >11212192</td>
    <td >21-08-2012</td>
    <td >MULTICULTURALISM AND SOCIO-POLITICAL ISSUES IN SELECT NOVELS OF ZADIE SMITH AND AMY TAN</td>
    <td >20-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>43</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Anoop Beri</td>
    <td >Jaswinder Kaur</td>
    <td >Full Time</td>
    <td >11212337</td>
    <td >22-08-2012</td>
    <td >LIFE SATISFACTION OF INTER REGIONAL MIGRANT STUDENTS IN RELATION OF THEIR PERCEIVED STRESS PERSONAL INITIATIVE GROWTH AND COPING STRATEGIES</td>
    <td >21-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>44</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Anoop Beri</td>
    <td >Shabir Ahmad Bhat</td>
    <td >Full Time</td>
    <td >11212391</td>
    <td >22-08-2012</td>
    <td >PERCIEVED JOB PERFORMANCE IN RELATION TO ICT ORIENTATION, WORK ENGAGEMENT AND OCCUPATIONAL STRESS: A STUDY OF PUBLIC AND PRIVATE UNIVERSITY TEACHERS</td>
    <td >21-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>45</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Harmanpreet Kaur</td>
    <td >Suresh Kumar</td>
    <td >Full Time</td>
    <td >11212731</td>
    <td >14-09-2012</td>
    <td >CONSTRUCTION ON STARDARDIZITION SCALE PERCEPTION TO WORDS PROFESSIONAL  COURSE OF PHYSICAL EDUCATION</td>
    <td >13-09-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>46</td>
    <td >Technology and Sciences</td>
    <td >Agriculture</td>
    <td >Dr. Madhu Sharma</td>
    <td >Balwinder Singh</td>
    <td >Part Time</td>
    <td >41200428</td>
    <td >18-08-2012</td>
    <td >EFFECT OF CROP GEOMETRY AND FERTIGATION ON QUALITY AND YIELD OF PARTHENOCRAPIC CUCUMBER CULTIVARS UNDER PROTECTED CULTIVATION</td>
    <td >17-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>47</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Pranav Kumar Prabhakar</td>
    <td >Rajesh Prasad Jayaswal</td>
    <td >Part Time</td>
    <td >41200364</td>
    <td >21-07-2012</td>
    <td > PHYSIOLOGICAL INTERACTION OF PROBIOTICS FOR MANAGEMENT OF HYPERGLYCEMIA.</td>
    <td >20-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>48</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. M. L. Sehgal</td>
    <td >Anil Kumar Bhardwaj</td>
    <td >Part Time</td>
    <td >41200412</td>
    <td >10-08-2012</td>
    <td >CORRELATION OF ELECTRON SPIN RESONANCE NUCLEAR QUADRUPOLE RESONANCE REFLECTANCE AND MAGNETIC PARAMETERS OF TRANSITION METAL ION COMPLEXES: A DENSITY FUNCTIONAL THEORY STUDY</td>
    <td >09-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>49</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Rekha</td>
    <td >Devesh Kumar Sharma</td>
    <td >Part Time</td>
    <td >41200378</td>
    <td >28-07-2012</td>
    <td >EXTRACTION ESTIMATION AND REDUCTION OF HEXAVALENT CHROMIUM IN INDIAN CEMENT SAMPLES.</td>
    <td >27-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>50</td>
    <td >Business and Arts</td>
    <td >Commerce</td>
    <td >Dr. Babli Dhiman</td>
    <td >Jyotishna Puri</td>
    <td >Part Time</td>
    <td >41200398</td>
    <td >05-08-2012</td>
    <td > A STUDY OF INDIVIDUAL INVESTMENT BEHAVIOUR WITH SPECIAL REFERANCE TO FINANCIAL LITERACY RISK TOLERANCE AND ENTERPRENEURIAL ORIENTATION.</td>
    <td >04-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>51</td>
    <td >Business and Arts</td>
    <td >Commerce</td>
    <td >Dr. Sanjay Modi</td>
    <td >Varinder Kumar</td>
    <td >Part Time</td>
    <td >41200409</td>
    <td >09-08-2012</td>
    <td >THE ROLE OF SPRITUAL VALUES IN TRANSFORMATIONAL LEADERSHIP:AN EXPLORATORY STUDY</td>
    <td >08-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>52</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Babita Pandey</td>
    <td >Aman Singh</td>
    <td >Part Time</td>
    <td >41200414</td>
    <td >10-08-2012</td>
    <td >INTELLIGENT TECHNIQUES FOR THE DIAGNOSIS OF LIVER DISEASE</td>
    <td >09-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>53</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Mritunjay Kumar Rai</td>
    <td >Gulshan Kumar</td>
    <td >Part Time</td>
    <td >41200451</td>
    <td >13-09-2012</td>
    <td >DESIGN AND EVALUATION OF LOCALIZATION ALGORITHM IN WIRELESS SENSOR NETWOKS</td>
    <td >12-09-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>54</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Anoop Beri</td>
    <td >Inderjit Kaur Saini</td>
    <td >Part Time</td>
    <td >41200392</td>
    <td >02-08-2012</td>
    <td >EFFECT OF EMOTIONAL INNTELLIGENCE INTERVENTION PROGRAM ON CONFLICT RESOLUTION SELF-EFFICACY AND PSYCHOLOGICAL WELL BEING OF SENIOR SECONDARY STUDENTS</td>
    <td >01-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>55</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. vijay kumar Chechi</td>
    <td >Joy Kirt Waraich</td>
    <td >Part Time</td>
    <td >41200385</td>
    <td >31-07-2012</td>
    <td >SELF EFFICACT AND DECISION MAKING ROLE OF WOMEN IN RELATION TO THEIR EDUCATION LEGAL AWARENESS AND FINANCIAL INDEPENDENCE</td>
    <td >30-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>56</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Aneet Kumar</td>
    <td >Anuradha Sahni</td>
    <td >Part Time</td>
    <td >41200391</td>
    <td >02-08-2012</td>
    <td >SOCIAL NETWORKING AND MULTITASKING AMONG HIGHER EDUCATION STUDENTS- INFLUENCE PSYCHO-SOCIAL ADJUSTMENT ACADEMIC PERFORMANCE AND JUDGEMENT</td>
    <td >01-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>57</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. NEELAM YADAV</td>
    <td >Gurpal Singh Rana</td>
    <td >Part Time</td>
    <td >41200363</td>
    <td >20-07-2012</td>
    <td >ORIENTATION WITH PROSODIC PHONEMES AS PRAGMATIC MARKERS IN CLASSROOM DISCOURSE</td>
    <td >19-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>58</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jit Pal Aggarwal</td>
    <td >Navneen Kaur</td>
    <td >Part Time</td>
    <td >41200379</td>
    <td >28-07-2012</td>
    <td >HIGH POWER LASER INTERACTION WITH PLASMAS AND SEMICONDUCTORS</td>
    <td >27-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>59</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jaideep Randhawa</td>
    <td >Priyanka Mahajan</td>
    <td >Part Time</td>
    <td >41200397</td>
    <td >04-08-2012</td>
    <td >EMERGENCE OF NEW WOMAN: A NEW FEMINISTIC APPROACH IN THE SELECT NOVELS OF MAHASWETA DEVI MANJU KAPOOR RUPA BAJWA AND SHOBHA DE</td>
    <td >03-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>60</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jit Pal Aggarwal</td>
    <td >Shivani</td>
    <td >Part Time</td>
    <td >41200371</td>
    <td >26-07-2012</td>
    <td >THE IMPACT OF COLLIDING CULTURES AND DISPLACEMENT: READING OF THE SELECT NOVELS OF BAPSI SIDHWA, MONICA ALI, TASLIMA NASRIN AND KHALED HOSSEINI</td>
    <td >25-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>61</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Tej Nath Dhar</td>
    <td >Sukhvinderjit Kaur Chopra</td>
    <td >Part Time</td>
    <td >41200415</td>
    <td >11-08-2012</td>
    <td >THE POLITICS OF RETRIEVAL IN FOUR POST COLONIAL NOVELS: A COMPARATIVE STUDY</td>
    <td >10-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>62</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jit Pal Aggarwal</td>
    <td >Varinder Kaur</td>
    <td >Part Time</td>
    <td >41200403</td>
    <td >08-08-2012</td>
    <td >THEATRE AND ANTI-THEATRE: CORROSION OF SELF IN THE SELECT PLAYS OF SAMUEL BECKETT, TENNESSEE WILLIAMS, EDWARD ALBEE, TOM STOPPARD AND JACK GELBER</td>
    <td >07-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>63</td>
    <td >Business and Arts</td>
    <td >Fine Arts and Performing</td>
    <td >Dr. Abid Hadi</td>
    <td >Tejinder Kaur</td>
    <td >Part Time</td>
    <td >41200405</td>
    <td >08-08-2012</td>
    <td >A COMPREHENSIVE STUDY AND DOCUMENTATION OF MURAL PAINTINGS IN GREATER PUNJAB (INDIA AND PAKISTAN)</td>
    <td >07-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>64</td>
    <td >Technology and Sciences</td>
    <td >Microbiology</td>
    <td >Dr. Shalini Singh</td>
    <td >Sujata Das</td>
    <td >Part Time</td>
    <td >41200445</td>
    <td >27-08-2012</td>
    <td >PRODUCTION OF LIGNINOLYTIC ENXYMES FROM NOVEL WILD ISOLATES OF  BASIDIOMYCETES FOR DEGRADATION OF INDUSTRIAL DYES</td>
    <td >26-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>65</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmaceutical Sciences</td>
    <td >Dr. Amit Mittal</td>
    <td >Vibhu Yadav</td>
    <td >Part Time</td>
    <td >41200456</td>
    <td >25-09-2012</td>
    <td >DEVELOPMENT OF REGULATORY GUIDELINES FOR ADVANCED WOUND CARE AND BURN DRESSINGS</td>
    <td >24-09-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>66</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Pravin Kumar</td>
    <td >Deepak Bangari</td>
    <td >Part Time</td>
    <td >41200401</td>
    <td >08-08-2012</td>
    <td >DEVELOPMENT OF REGERESSION EQUATION TO PREDICT KHO-KHO PERFORMANCE WITH THE HELP OF DIGIT RATIO, STRESS-VULNERABILITY AND SELECTED ANTHROPOMETRIC VARIABLES</td>
    <td >07-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>67</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr.Satpal Kaur</td>
    <td >Aruna Rani</td>
    <td >Part Time</td>
    <td >41200407</td>
    <td >09-08-2012</td>
    <td >PSYCHO-PHYSICAL EMPOWERMENT OF WOMEN THROUGH SELF DEFENSE ACTIVITIES: AN EXPERIMENTAL STUDY</td>
    <td >08-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>68</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Varender Singh Patial</td>
    <td >Sanjogdeep Singh</td>
    <td >Part Time</td>
    <td >41200446</td>
    <td >27-08-2012</td>
    <td >BODY IMAGE AND ITS INFLUENCE ON SELF-ESTEEM, EATING ATTITUDE AND BEHAVIOURAL PATTERN OF ADOLESCENTS</td>
    <td >26-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>69</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Neelam K Sharma</td>
    <td >Parmeet Kour Sodhi</td>
    <td >Part Time</td>
    <td >41200430</td>
    <td >18-08-2012</td>
    <td >INFLUENCE OF HARASSMENT AND BULLYING AGAINST INDIAN WOMEN ATHLETES AND ITS IMPACT ON SPORTS PARTICIPATION AND PSYCHO-SOCIAL ADJUSTMENT: A LONGITUDINAL STUDY</td>
    <td >17-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>70</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Jasobanta Sethi</td>
    <td >Rati</td>
    <td >Part Time</td>
    <td >41200362</td>
    <td >20-07-2012</td>
    <td >EFFECT OF ACUTENSE IN PREDIABETES</td>
    <td >19-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>71</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Jasobanta Sethi</td>
    <td >Gayathri R</td>
    <td >Part Time</td>
    <td >41200406</td>
    <td >08-08-2012</td>
    <td >EFFECT OF PROPRIOCEPTIVE NEUROMUSCULAR FACILITATION TECHNIQUE IN PRIMARY DYSMENORRHEA</td>
    <td >07-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>72</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Jasobanta Sethi</td>
    <td >Harpreet Kaur</td>
    <td >Part Time</td>
    <td >41200356</td>
    <td >16-07-2012</td>
    <td >EFFECT OF ACU TENS ON OSTEOPOROSIS</td>
    <td >15-07-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>73</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Jasobanta Sethi</td>
    <td >S Micheal Raj</td>
    <td >Part Time</td>
    <td >41200404</td>
    <td >08-08-2012</td>
    <td >EFFECT OF NEUROKINESIOLOGY TECHNIQUE ON EXECUTIVE DYSFUNCTION AND POSTURAL INSTABILITY AMONG MIDDLE AGED TYPE II DIABETES  MELLITUS</td>
    <td >07-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>74</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Jasobanta Sethi</td>
    <td >Sunil Kumar</td>
    <td >Part Time</td>
    <td >41200420</td>
    <td >12-08-2012</td>
    <td >ANALYSIS OF FOOT POSTURE IN ACUTE LATERAL ANKLE SPRAIN</td>
    <td >11-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>75</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Harmanpreet Kaur</td>
    <td >Rakesh Kumar</td>
    <td >Full Time</td>
    <td >11212129</td>
    <td >20-08-2012</td>
    <td >AN ASSESSMENT OF HEALTH AND PHYSICAL ACTIVITY STATUS OF PUNJAB POLICE</td>
    <td >19-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>76</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Neelam K Sharma</td>
    <td >Parambir Singh</td>
    <td >Full Time</td>
    <td >11312150</td>
    <td >06-08-2013</td>
    <td >EFFECT OF MULTIDISCIPLINARY APPROACH ON MENTALLY CHALLENGED CHILDREN</td>
    <td >05-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>77</td>
    <td >Technology and Sciences</td>
    <td >Electronics &amp; Communication Engineering</td>
    <td >Dr. Anita Kumari</td>
    <td >Sanjeev Kumar</td>
    <td >Full Time</td>
    <td >11312333</td>
    <td >08-08-2013</td>
    <td >ANALOG VLSI IMPLEMENTATION OF NEUROMORPHIC SYSTEM</td>
    <td >07-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>78</td>
    <td >Technology and Sciences</td>
    <td >Electronics &amp; Communication Engineering</td>
    <td >Dr. Mritunjay Kumar Rai</td>
    <td >Jai Sukh Paul Singh</td>
    <td >Full Time</td>
    <td >11312567</td>
    <td >13-08-2013</td>
    <td >DESIGN AND ANALYSIS OF ADVANCED APPROACH FOR PERFORMANCE ENHANCEMENT OF MULTI-INTERFACE MULTI-CHANNEL COGNITIVE RADIO NETWORKS</td>
    <td >12-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>79</td>
    <td >Technology and Sciences</td>
    <td >Zoology</td>
    <td >Dr. Joginder Singh Panwar</td>
    <td >Shivika Datta</td>
    <td >Full Time</td>
    <td >11313029</td>
    <td >20-08-2013</td>
    <td >BIOREMEDIATION OF PESTICIDE CONTAMINATED AGRICULTURAL SOIL BY VERMITECHNOLOGY AND TOXICITY ASSESSMENT BY ALLIUM CEPA.</td>
    <td >19-08-2018</td>
    <td >YES</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>80</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Nidhi Sethi</td>
    <td >Jatinder Pal Kaur Gill</td>
    <td >Full Time</td>
    <td >11312424</td>
    <td >10-08-2013</td>
    <td >SYNTHESIS CHARACTERIZATION HERBICIDAL AND BIOLOGICAL ACTIVITIES OF GLYPHOSATE DERIVATIVES</td>
    <td >09-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>81</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Niti Kant</td>
    <td >Manzoor Ahmad Wani</td>
    <td >Full Time</td>
    <td >11312810</td>
    <td >19-08-2013</td>
    <td >DENSITY TRANSITION BASED SELF- FOCUSING OF A SHORT PULSE LASER IN PLASMA</td>
    <td >18-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>82</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Suresh Chandra</td>
    <td >Surinder Manhas</td>
    <td >Full Time</td>
    <td >11312867</td>
    <td >19-08-2013</td>
    <td >STUDY OF MOLECULES IN THE INTERSTELLAR SPACE</td>
    <td >18-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>83</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Rajesh Verma</td>
    <td >Makhmoor Bashir</td>
    <td >Part Time</td>
    <td >11313030</td>
    <td >20-08-2013</td>
    <td >INFLUENCE OF TECHNOLOGICAL DEVELOPMENTS ON BUSINESS MODEL INNOVATIONS</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>84</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Babli Dhiman</td>
    <td >Tajinder</td>
    <td >Full Time</td>
    <td >11312708</td>
    <td >16-08-2013</td>
    <td >ANALYSIS OF STOCK MARKET CALANDER ANOMALIES AND STAKEHOLDERS BEHAVIOR</td>
    <td >15-08-2018</td>
    <td >Yes</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>85</td>
    <td >Business and Arts</td>
    <td >Commerce</td>
    <td >Dr. Mahesh Chandra Joshi</td>
    <td >Mukta Kukreja</td>
    <td >Full Time</td>
    <td >11312738</td>
    <td >17-08-2013</td>
    <td >AN EMPIRICAL ANALYSIS OF INDIAN OUTWARD FOREIGN DIRECT INVESTMENTS TO AFRICA</td>
    <td >16-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>86</td>
    <td >Business and Arts</td>
    <td >Commerce</td>
    <td >Dr. Babli Dhiman</td>
    <td >Shilpa</td>
    <td >Full Time</td>
    <td >11312213</td>
    <td >06-08-2013</td>
    <td >TRENDS PERFORMANCE AND EFFICIENCY OF FOREIGN BANKS IN INDIA SINCE </td>
    <td >05-08-2018</td>
    <td >YES</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>87</td>
    <td >Business and Arts</td>
    <td >Economics</td>
    <td >Dr. Surinder Kumar Singla</td>
    <td >Heena Goel</td>
    <td >Full Time</td>
    <td >11312604</td>
    <td >14-08-2013</td>
    <td >INDIA-UAE ECONOMIC RELATIONS: WITH SPECIAL REFERENCE TO MERCHANDISE TRADE</td>
    <td >13-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>88</td>
    <td >Business and Arts</td>
    <td >Economics</td>
    <td >Dr. Jasdeep Kaur Dhami</td>
    <td >Gurpreet Kaur</td>
    <td >Full Time</td>
    <td >11312667</td>
    <td >16-08-2013</td>
    <td >AN EMPIRICAL ANALYSIS OF TRADE PERFORMANCE AMONG BIMSTEC NATIONS WITH REFERENCE TO INDIA,</td>
    <td >15-08-2018</td>
    <td >YES</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>89</td>
    <td >Business and Arts</td>
    <td >Fine Arts and Performing</td>
    <td >Dr. Rohita Sharma</td>
    <td >Gurdeep Kaur</td>
    <td >Full Time</td>
    <td >11312693</td>
    <td >16-08-2013</td>
    <td >AN ANALYTICAL NARRATION OF SIKH INFLUENCE IN MINIATURE PAINTINGS OF KANGRA- GULER STYLE FROM TH TO TH CENTURY IN PUNJAB</td>
    <td >15-08-2018</td>
    <td >YES</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>90</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Patitapaban Mohanty</td>
    <td >Ramesh Chandra Patra</td>
    <td >Full Time</td>
    <td >11304869</td>
    <td >19-06-2013</td>
    <td >DRY NEEDLING AND MANUAL THERAPY FOR THE MANAGEMENT OF PATIENT WITH CERVICOGENIC HEADACHE</td>
    <td >18-06-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>91</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Umasankar Mohanty</td>
    <td >Kanchan Kumar Sarker</td>
    <td >Full Time</td>
    <td >11304873</td>
    <td >19-06-2013</td>
    <td >EFFICACY OF SPINAL MANIPULATION POSTURAL INSTABILITY AND QUALITY OF LIFE IN PATIENTS WITH CHRONIC NON SPECIFIC LO BACK PAIN.</td>
    <td >18-06-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>92</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Neelam K Sharma</td>
    <td >Arjun Singh</td>
    <td >Full Time</td>
    <td >11312002</td>
    <td >04-08-2013</td>
    <td >MANAGEMENT OF CRIMINAL PROPENSITY AMONG DRUG ADDICTS THROUGH YOGA SPORTS AND RECREATIONAL ACTIVITY</td>
    <td >03-08-2018</td>
    <td >YES</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>93</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Yuvraj Singh</td>
    <td >Vimal Kishore</td>
    <td >Full Time</td>
    <td >11312977</td>
    <td >20-08-2013</td>
    <td >RESIELENCE IN SPORTS: CONSTRUCTION AND VALIDATION OF SPORTS SPECIFIC RESILIENCE TOOL</td>
    <td >19-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>94</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Anand Thakur</td>
    <td >Rupinderdeep Kaur</td>
    <td >Full Time</td>
    <td >11311893</td>
    <td >02-08-2013</td>
    <td >CONSUMER ATTITUDINAL LOYALITY TOWARDS LUXURY FASHION BRANDS IN RELATION TO BRAND PERSONALITY AND EMOTIONAL ASPECTS.</td>
    <td >01-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>95</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Mridula Mishra</td>
    <td >Kanika Garg</td>
    <td >Full Time</td>
    <td >11312154</td>
    <td >06-08-2013</td>
    <td >STUDY ON RELATIONSHIP OF LEADERSHIP STYLES WITH CONFLICT RESOLUTION STRATEGY AND MANAGERIAL EFFECTIVENESS (WITH SPECIAL REFERENCE TO MANUFACTURING AN SERVICE SECTOR IN NCR)</td>
    <td >05-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>96</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr.Neethu Radhakrishnan</td>
    <td >Pushpinder Kaur</td>
    <td >Full Time</td>
    <td >11312126</td>
    <td >06-08-2013</td>
    <td >SUBMISSIVE AND SUBORDINATE ROLES OF WOMEN IN THE SELECT NOVELS OF BESSIE HEAD BUCHI EMECHETA AND FLORA NWAPA</td>
    <td >05-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>97</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Sandeep Kaur</td>
    <td >Ramandeep Kaur</td>
    <td >Full Time</td>
    <td >11311957</td>
    <td >03-08-2013</td>
    <td >BALBIR PARVANA DE NAVLAAN CH PRASTOOT KISAANI SAN</td>
    <td >02-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>98</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Anoop Beri</td>
    <td >Aaradhya Srivastava</td>
    <td >Full Time</td>
    <td >11311983</td>
    <td >03-08-2013</td>
    <td >SATISFACTION AND LOYALITY IN RELATION TO STUDENT ENGAGEMENT AN SOCIO-CULTURAL ADAPTATION AMONG INTERNATIONAL STUDENTS.</td>
    <td >02-08-2018</td>
    <td >Yes</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>99</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Harmanpreet Kaur</td>
    <td >Gurpreet Kaur</td>
    <td >Full Time</td>
    <td >11312136</td>
    <td >06-08-2013</td>
    <td >CONSTRUCTION AND STANDARDIZATION INVENTORY ON HOME ENVIRONMENT TOWARDS SPORTS </td>
    <td >05-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>100</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Joginder Singh Panwar</td>
    <td >Vikas Kaushik</td>
    <td >Part Time</td>
    <td >41300079</td>
    <td >14-08-2013</td>
    <td >IN-SILICO DESIGN OF VACCINE- A STUDY BASED ON USE OF PEPTIDES</td>
    <td >13-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>101</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Anand Mohan</td>
    <td >Anupam Kumar</td>
    <td >Part Time</td>
    <td >41300111</td>
    <td >19-08-2013</td>
    <td >TOXICOLOGICAL IMPACTS OF DELTAMETHRIN PESTICIDE ON IMMUNECOMPROMISED MICE MODEL AND RELATED IMMUNOMODULATION STUDIES</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>102</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Parmjit S Panesar</td>
    <td >Sawinder Kaur</td>
    <td >Part Time</td>
    <td >41300142</td>
    <td >20-08-2013</td>
    <td >STUDIES ON EVALUATION OF EPICOCCUM NIGRUM FOR PRODUCTION OF POLYKETIDE AND CAROTENOID PIGMENTS AS POTENTIAL NATURAL FOOD COLOURANT</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>103</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Pooja Gupta</td>
    <td >Jatinder Kaur</td>
    <td >Part Time</td>
    <td >41300127</td>
    <td >15-08-2013</td>
    <td >DEVELOPING ALGORITHMS TO IDENTIFY SPLICE JUNCTIONS IN PROTEIN CODING REGION FOR GENE PREDICTION.</td>
    <td >14-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>104</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Tanupreet Singh</td>
    <td >Pooja Rani</td>
    <td >Part Time</td>
    <td >41300132</td>
    <td >15-08-2013</td>
    <td >PROPOSE A SECURE FRAMEWORK FOR ISOLATING VARIOUS TYPES OF ATTACKS IN MOBILE AD HOE NETWORKS USING INTRUSION DETECTION SYSTEM</td>
    <td >14-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>105</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Ashish Jolly</td>
    <td >Sushil Kumar</td>
    <td >Part Time</td>
    <td >41300114</td>
    <td >15-08-2013</td>
    <td >SECURE AGILE SOFTWARE DEVELOPMENT BY EMBODIMENT OF SECURITY ACTIVITIES,</td>
    <td >14-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>106</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Babita Pandey</td>
    <td >Divya</td>
    <td >Part Time</td>
    <td >41300074</td>
    <td >13-08-2013</td>
    <td >COMPUTATIONAL INTELLIGENCE METHODS FOR GENE SELECTION AND CLASSIFICATION</td>
    <td >12-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>107</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Babita Pandey</td>
    <td >Aditya Khamparia</td>
    <td >Part Time</td>
    <td >41300094</td>
    <td >15-08-2013</td>
    <td >INTELLIGENT COMPUTING METHODS IN E-LEARNING ENVIRONMENT</td>
    <td >14-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>108</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Babita Pandey</td>
    <td >Arun Malik</td>
    <td >Part Time</td>
    <td >41300063</td>
    <td >10-08-2013</td>
    <td >EFFICIENT PATH MAPS GENERATION USING DATA MINING ON DISTRIBUTED RSUS IN VEHICULAR AD HOC NETWORKS</td>
    <td >09-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>109</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Pradeep Tomar</td>
    <td >Naresh Kumar</td>
    <td >Part Time</td>
    <td >41300071</td>
    <td >12-08-2013</td>
    <td >AN EFFICIENT BIG DATA STORAGE MODEL FOR CLOUD COMPUTING.</td>
    <td >11-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>110</td>
    <td >Technology and Sciences</td>
    <td >Computer Applications</td>
    <td >Dr. Babita Pandey</td>
    <td >Sarneet Kaur</td>
    <td >Part Time</td>
    <td >41300093</td>
    <td >16-08-2013</td>
    <td >INTLLIGENT COMPUTING METHOD FOR PROTEIN SECONDARY STRUCTURE PREDICTION</td>
    <td >15-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>111</td>
    <td >Technology and Sciences</td>
    <td >Mechanical Engineering</td>
    <td >Dr. Neel Kanth Grover</td>
    <td >Varun Panwar</td>
    <td >Part Time</td>
    <td >41300138</td>
    <td >15-08-2013</td>
    <td >INVESTIGATIONS OF SOME SURFACE MODIFICATION TECHNIQUES COMBATING EROSIVE WEAR OF I.D FANS IN COAL FIRED POWER PLANTS.</td>
    <td >14-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>112</td>
    <td >Technology and Sciences</td>
    <td >Environmental Sciences</td>
    <td >Dr. R.S. Kanwar</td>
    <td >Bhagat Pranita Pradip</td>
    <td >Part Time</td>
    <td >41300140</td>
    <td >20-08-2013</td>
    <td >DEVELOPING A WETLAND HEALTH INDEX USING DATA FROM RAMSAR WETLANDS</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>113</td>
    <td >Technology and Sciences</td>
    <td >Zoology</td>
    <td >Dr. Kamlesh Malik</td>
    <td >Kapil Kumar Sharma</td>
    <td >Part Time</td>
    <td >41300144</td>
    <td >20-08-2013</td>
    <td >DYNAMICS OF PEST COMPLEX ON POTATO SEED CROP IN PUNJAB AND ITS INTEGRATED MANAGEMENT</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>114</td>
    <td >Technology and Sciences</td>
    <td >Microbiology</td>
    <td >Dr. Anania Arjuna</td>
    <td >Himal Sapkota</td>
    <td >Part Time</td>
    <td >41300145</td>
    <td >20-08-2013</td>
    <td >QUORUM SENSING IN CLINICAL ISOLATES OF PSEUDOMONAS AERUGINOSA</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>115</td>
    <td >Technology and Sciences</td>
    <td >Nutrition&amp;Dietics</td>
    <td >Dr. Beenu Tanwar</td>
    <td >Monica Gautam</td>
    <td >Part Time</td>
    <td >41300070</td>
    <td >12-08-2013</td>
    <td >CELIAC DISEASE: PREVALENCE IN FEROZEPUR AND JALANDHAR CITIES OF PUNJAB AND DEVELOPMENT OF LOW COST GLUTEN FREE PRODUCTS</td>
    <td >11-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>116</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Suman</td>
    <td >Nidhi Aggarwal</td>
    <td >Part Time</td>
    <td >41300103</td>
    <td >17-08-2013</td>
    <td >SYNTHESIS CHARACTERIZATION AND BIOLOGICAL PROPERTIES OF SCHIFF BASE AND MIXED LIGAND COMPLEXES OF COPPER AND ZINC</td>
    <td >16-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>117</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Mukesh Kumar</td>
    <td >Gulshan Kumar</td>
    <td >Part Time</td>
    <td >41300119</td>
    <td >19-08-2013</td>
    <td >RADON MONITORING AND FAULT DELINEATION STUDY IN HIMACHAL HIMALAYA INDIA</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>118</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Kailash Chandra Juglan</td>
    <td >Jasdeep Kaur</td>
    <td >Part Time</td>
    <td >41300116</td>
    <td >19-08-2013</td>
    <td >VOICE RECOGNITION THROUGH PHONETIC FEATURES WITH HINDI AND PUNJABI UTTERANCES: FORENSIC APPLICATION.,</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>119</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Mukesh Kumar</td>
    <td >Anju Sharma</td>
    <td >Part Time</td>
    <td >41300106</td>
    <td >17-08-2013</td>
    <td >COMPUTATIONAL ANALYSIS OF   STRUCTURAL PARAMETERS OF QUINONE DERIVATIVES</td>
    <td >16-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>120</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Virendra Singh Chauhan</td>
    <td >Richa Sharma</td>
    <td >Part Time</td>
    <td >41300120</td>
    <td >19-08-2013</td>
    <td >A STUDY OF COUPLED FIXED POINT THEOREMS</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>121</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Babli Dhiman</td>
    <td >Bharti</td>
    <td >Full Time</td>
    <td >41300060</td>
    <td >07-08-2013</td>
    <td >TO STUDY THE EFFECT OF INTELLECTUAL CAPITAL ON ORGANIZATION PERFORMANCE AND MEDIATING ROLE OF ORGANIZATIONAL CAPABILITIES.</td>
    <td >06-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>122</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Rajesh Verma</td>
    <td >Jagjit Singh</td>
    <td >Part Time</td>
    <td >41300080</td>
    <td >14-08-2013</td>
    <td >STUDY OF CONSUMER TRUST PERCEPTIONS IN ONLINE B2C MARKETPLACES AND ITS IMPLICATIONS FOR ONLINE RETAILERS</td>
    <td >13-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>123</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Anand Thakur</td>
    <td >Simriti Kohli</td>
    <td >Part Time</td>
    <td >41300122</td>
    <td >19-08-2013</td>
    <td >RELATION BETWWEN PERSONAL VALUES AND PERCEPTION TOWARDS CSR: A STUDY OF SELECT COMPANIES IN NORTHERN INDIA.</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>124</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Vishal Sareen</td>
    <td >Monika Kalani</td>
    <td >Part Time</td>
    <td >41300135</td>
    <td >20-08-2013</td>
    <td >ASSESMENT OF INFLATION AND POLICY REGIMES IN INDIA</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>125</td>
    <td >Technology and Sciences</td>
    <td >Soil Science</td>
    <td >Dr. Balkrishna Sopan Bhople</td>
    <td >Harminder Singh</td>
    <td >Part Time</td>
    <td >41300150</td>
    <td >20-08-2013</td>
    <td >PHYTOEXTRACTION POTENTIAL OF HYPERACCUMULATORS (AROMATIC GRASSES) FOR CADMIUM CONTAMINATED SOILS</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>126</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Mahesh Chandra Joshi</td>
    <td >Richa Bhatia</td>
    <td >Part Time</td>
    <td >41300151</td>
    <td >20-08-2013</td>
    <td >FDI AS A MODE OF FOREIGN ENTRY ADOPTED BY SELECT MANUFACTURING FIRMS OF INDIA</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>127</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Farhan Khan</td>
    <td >Ravinder Singh</td>
    <td >Part Time</td>
    <td >41300159</td>
    <td >20-08-2013</td>
    <td >ROLE OF FAMILY COHESIVENESS SOCIAL CAPITAL AND SOCIO-EMOTIONAL WEALTH IN ENTREPRENEURIAL ORIENTATION - BUSINESS PERFORMANCE RELATIONSHIP</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>128</td>
    <td >Business and Arts</td>
    <td >Commerce</td>
    <td >Dr. Balwinder Singh<br></td>
    <td >Parmjot Kaur</td>
    <td >Part Time</td>
    <td >41300124</td>
    <td >19-08-2013</td>
    <td >IMPACT OF IFRS ON INDIA ACCOUNTING STANDARDS AND THE FINANCIAL PERFORMANCE OF INDIAN CORPORATES</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>129</td>
    <td >Business and Arts</td>
    <td >Commerce</td>
    <td >Dr. Babli Dhiman</td>
    <td >Saloni Raheja</td>
    <td >Part Time</td>
    <td >41300076</td>
    <td >13-08-2013</td>
    <td >A STUDY ON INDIVIDUAL INVESTMENT DECISIONS RISK TOLERANCE AND INFLUENCING FACTORS IN STOCK MARKET.</td>
    <td >12-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>130</td>
    <td >Business and Arts</td>
    <td >Economics</td>
    <td >Dr. Jasdeep Kaur Dhami</td>
    <td >Nassir Ul Haq Wani</td>
    <td >Part Time</td>
    <td >41300099</td>
    <td >17-08-2013</td>
    <td >PERFORMANCE AND PROSPECTS OF INDIAÂ€™S TRADE LINKAGE WITH BRCS ECONOMIES</td>
    <td >16-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>131</td>
    <td >Business and Arts</td>
    <td >Economics</td>
    <td >Dr. Surinder Kumar Singla</td>
    <td >Amarpreet Kaur</td>
    <td >Part Time</td>
    <td >41300100</td>
    <td >17-08-2013</td>
    <td >PERFORMANCE EVALUATION OF SCHEDULED COMMERCIAL BANKS IN FINANCING AGRICULTURE IN PUNJAB</td>
    <td >16-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>132</td>
    <td >Business and Arts</td>
    <td >Fine Arts and Performing</td>
    <td >Dr. Abid Hadi</td>
    <td >Tikendra Kumar Sahu</td>
    <td >Part Time</td>
    <td >41300154</td>
    <td >20-08-2013</td>
    <td >CONTEMPORARY EMBOSSED ART PRACTICES IN INDIA: AN EXPLORATORY STUDY</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>133</td>
    <td >Business and Arts</td>
    <td >Fine Arts and Performing</td>
    <td >Dr. Sushma Sharma</td>
    <td >Ravjot Kaur</td>
    <td >Part Time</td>
    <td >41300115</td>
    <td >19-08-2013</td>
    <td >PUNJAB KE LOK SANGEET KE ANTARGAT GURMEET BAWA KE GEETON KA SAMAJIK SANSKRITIK ADHYAYAN</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>134</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Anil Verma</td>
    <td >Inderjit Singh</td>
    <td >Part Time</td>
    <td >41300081</td>
    <td >14-08-2013</td>
    <td >A COMPARATIVE STUDY OF SELECT INDIAN DALIT WRITINGS AND AFRO-AMERICAN SLAVE NARRATIVES</td>
    <td >13-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>135</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jit Pal Aggarwal</td>
    <td >Parvesh Kumari</td>
    <td >Part Time</td>
    <td >41300121</td>
    <td >19-08-2013</td>
    <td >EXCAVATION OF THE INNER LANDSCAPE: PERSPECTIVE OF A SERVIVOR IN THE SELECT NOVELS AND MEMOIRS OF SAUL BELLOW, PRIMO LEVI, ELIE WIESEL AND CHARLOTTE DELBO,</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>136</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jit Pal Aggarwal</td>
    <td >Sukhvinder Kaur</td>
    <td >Part Time</td>
    <td >41300133</td>
    <td >20-08-2013</td>
    <td >INTERIOR MONOLOGUE OF WOMEN:QUEST FOR SURVIVAL THROUGH SEXUALITY AND MULTIPLE IDENTITIES IN THE SELECT NOVELS OF TONO MORRISON MARGARET ATWOOD AND DORIS LESSING</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>137</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Avtar Singh</td>
    <td >Balvir Chand</td>
    <td >Part Time</td>
    <td >41300073</td>
    <td >13-08-2013</td>
    <td >GURU GRANTH SAHIB VICH SANKLIT SLOK BANI-ROOP: VICHARDHRAE PARIPEKH</td>
    <td >12-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>138</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Avtar Singh</td>
    <td >Harjinder Singh</td>
    <td >Part Time</td>
    <td >41300090</td>
    <td >16-08-2013</td>
    <td >LEXICOLIGICAL STUDY OF DIALECT-DICTIONARIES OF PUNJABI: PRACTICAL ASPECTS</td>
    <td >15-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>139</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Balwinder Singh Thind</td>
    <td >Sukhwinder Singh</td>
    <td >Part Time</td>
    <td >41300084</td>
    <td >16-08-2013</td>
    <td >BHARTI SAHIT AKADEMI VALON PURSKRIT PUNJABI NAVLAN DA VISHLESHNATAMAK ADHYAN (&lsquo;GUACHE ARTH&rsquo; &lsquo;SUDHAR GHAR&rsquo; &lsquo;DHAHWAN DILHI DE KINGRE&rsquo; ATE &lsquo;NIRWAN&rsquo; DE VISHESH SANDHARBH VICH).</td>
    <td >15-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>140</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Sandeep Kaur</td>
    <td >Nirvair Singh</td>
    <td >Part Time</td>
    <td >41300086</td>
    <td >16-08-2013</td>
    <td >BALDEV SINGH DE NAVLAN VICH NAARI SAMVEDNA.</td>
    <td >15-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>141</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Kirandeep Singh</td>
    <td >Babaljit Kaur</td>
    <td >Part Time</td>
    <td >41300110</td>
    <td >19-08-2013</td>
    <td >BALBIR SINGH MOMI DA RACHNA SANSAR: ALOACHNATMAK ADHIYAN</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>142</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmaceutical Sciences</td>
    <td >Dr. Monica Gulati</td>
    <td >Yogyata</td>
    <td >Part Time</td>
    <td >41300112</td>
    <td >15-08-2013</td>
    <td >DEVELOPMENT AND EVALUATION OF TOPICAL VESICULAR DELIVERY SYSTEM FOR THE TREATMENT OF VITILIGO.</td>
    <td >14-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>143</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmaceutical Sciences</td>
    <td >Dr. T.Prakash, Prof. </td>
    <td >Bimlesh Kumar</td>
    <td >Part Time</td>
    <td >41300117</td>
    <td >15-08-2013</td>
    <td >PHARMACOLOGICAL EVALUATION OF DULOXENITE AND CURCUMIN IN ATTENUATION OF NEUROPATHIC PAIN</td>
    <td >14-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>144</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmaceutical Sciences</td>
    <td >Dr. Sachin Kumar Singh</td>
    <td >Bhupinder Kapoor</td>
    <td >Part Time</td>
    <td >41300097</td>
    <td >15-08-2013</td>
    <td >SYNTHESIS OF LIPIDIC PRODRUG OF METHOTREXATE AND THEIR FORMULATIONDEVELOPMENT FOR TREATMENT OF RHEUMATOID ARTHRITIS</td>
    <td >14-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>145</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmaceutical Sciences</td>
    <td >Dr. M.G. Chouhan</td>
    <td >Saurabh Singh</td>
    <td >Part Time</td>
    <td >41300156</td>
    <td >15-08-2013</td>
    <td >DEVELOPMENT AND EVALUATION OF POLYHERBAL FORMULATION CONTAINING COPPER NANOPARTICLES FOR TREATMENT OF TYPE-II DIABETES MELLITUS</td>
    <td >14-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>146</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Patitapaban Mohanty </td>
    <td >Biswajit Kanungo</td>
    <td >Part Time</td>
    <td >41300128</td>
    <td >19-08-2013</td>
    <td >EFFECT OF MANUAL THERAPY AND DRY NEEDLING ON TEMPOROMANDIBULAR DISORDER AND QUALITY OF LIFE</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>147</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Ajay Prashad Gautam</td>
    <td >A.Sridhar</td>
    <td >Part Time</td>
    <td >41300091</td>
    <td >16-08-2013</td>
    <td >EFFICACY OF SWISS BALL TRAINING AND TENS IN UNILATERAL NEGLECT</td>
    <td >15-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>148</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Ajay Prashad Gautam</td>
    <td >Saravanan S</td>
    <td >Part Time</td>
    <td >41300078</td>
    <td >14-08-2013</td>
    <td >EFFECT OF DIAPHRAGM FACILIATION TECHNIQUES IN PATIENTS WITH NON-SPECIFIC LOW BACK PAIN</td>
    <td >13-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>149</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Jaspreet Singh</td>
    <td >Himani Mehta</td>
    <td >Part Time</td>
    <td >41300105</td>
    <td >17-08-2013</td>
    <td >SCENARIO OF AUTISM SPECTRUM DISORDER IN THE STATE OF PUNJAB: PREVALENCE ANXIETY AND EFFICACY OF PHYSIOTHERAPY INTERVENTION IN THE SAMPLE POPULATION</td>
    <td >16-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>150</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Vijay Kumar Chechi</td>
    <td >Jyoti Bhalla</td>
    <td >Part Time</td>
    <td >41300072</td>
    <td >13-08-2013</td>
    <td >SELF REGULATED LEARNING STRATEGIES OF HIGHER EDUCATION STUDENTS IN RELATION TO CAUSAL ATTRIBUTION AND SELF EMOTIONALMANAGEMENT</td>
    <td >12-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>151</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Anshu Narad</td>
    <td >Mandeep Kaur</td>
    <td >Part Time</td>
    <td >41300066</td>
    <td >10-08-2013</td>
    <td >SELF HANDICAPPING TENDENCY AMONG HIGHER EDUCATION STUDENTS: INFLUENCE OF ATTRIBTIONAL BELEIFS LEARNING ENVIRONMENT AND PERFECTIONSM</td>
    <td >09-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>152</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Anshu Narad</td>
    <td >Namrata Bhalla</td>
    <td >Part Time</td>
    <td >41300067</td>
    <td >10-08-2013</td>
    <td >CROSS CULTURAL ADJUSTMENT AMONG HIGHER EDUCATION STUDENTS IN RELATION TO SELF CONSTRUAL, SOCIAL SUPPORT AND LINGUISTIC COMPETENCE</td>
    <td >09-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>153</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Nimisha Beri</td>
    <td >Anju Mehta</td>
    <td >Part Time</td>
    <td >41300085</td>
    <td >16-08-2013</td>
    <td >DEVELOPMENT AND EVALUATION OF INTERVENTION PROGRAM TO REDUCE ACCULTURATIVE STRESS AMONG INTERNATIONAL STUDENTS.</td>
    <td >15-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>154</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Parminder</td>
    <td >Shaloo Saini</td>
    <td >Part Time</td>
    <td >41300141</td>
    <td >20-08-2013</td>
    <td >INTERNET USAGE AND PARENTING STYLES IN RELATION TO THE HEALTH AND SOCIAL COMPETENCE OF THE SECONDARY SCHOOL STUDENTS</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>155</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Vijay Kumar Chechi</td>
    <td >Amanpreet Kaur</td>
    <td >Part Time</td>
    <td >41300147</td>
    <td >20-08-2013</td>
    <td >IMPACT OF CLASSROOM MANAGEMENT STYLES CREDIBILITY OF SCHOOL TEACHERS AND INSTITUTIONAL SUPPORT ON THE ACHIEVEMENT MOTIVATION AND LEADERSHIP DEVELOPMENT AMONG SECONDARY SCHOOL STUDENTS</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>156</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Pravin Kumar</td>
    <td >Bindiya Rawat</td>
    <td >Part Time</td>
    <td >41300077</td>
    <td >14-08-2013</td>
    <td >IMPACTOFIMPULSIVEBEHAVIORONMOTORABILITYMOTOREDUCABILITYRISKTAKINGANDDECISIONMAKINGABILITYAMONGINDIVIDUALTEAMANDCOMBATSPORTS</td>
    <td >13-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>157</td>
    <td >Technology and Sciences</td>
    <td >Vegetable Science</td>
    <td >Dr. Madhu Sharma</td>
    <td >Daljit Singh</td>
    <td >Part Time</td>
    <td >41300109</td>
    <td >18-08-2013</td>
    <td >PERFORMANCE OF SWEET PEPPER (CAPSICUM ANNUUM L.) CULTIVARS AND ECONOMICS UNDER PROTECTED STRUCTURES IN PUNJAB</td>
    <td >17-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>158</td>
    <td >Business and Arts</td>
    <td >Psychology</td>
    <td >Dr. Komal Rai</td>
    <td >Khushpinder Pal Sharma</td>
    <td >Part Time</td>
    <td >41300143</td>
    <td >20-08-2013</td>
    <td >A STUDY OF RELATIONSHIP BETWEEN PERSONALITY DIMENSIONS, STRESS AND COPING IN YOUNG MALE SUBSTANCE ABUSERS OF PUNJAB.</td>
    <td >19-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>159</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Umesh Goutam</td>
    <td >Neha Salaria</td>
    <td >Full Time</td>
    <td >11312733</td>
    <td >17-08-2013</td>
    <td >CLONING AND FUNCTIONAL CHARACTERIZATION OF HEAT TOLERANCE RESPONSIVE GENES FROM POTATO CULTIVAR KUFRI SURYA (SOLANUM TUBEROSUM L.)</td>
    <td >16-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>160</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Anil sharma</td>
    <td >Pushpa</td>
    <td >Full Time</td>
    <td >11312729</td>
    <td >17-08-2013</td>
    <td >E-HEALTH SYSTEM FOR EARLY DETECTION AND PREVENTION OF INHERITED DISEASES CAUSING DISORDERS IN PRENATAL</td>
    <td >16-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>161</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Nimisha Beri</td>
    <td >Shipra Verma</td>
    <td >Full Time</td>
    <td >11312207</td>
    <td >06-08-2013</td>
    <td >ORGANIZATION  CITIZENSHIP BEHAVIOR IN RELATION TO TEACHER EMPOWERMENT AND ORGANIZATIONAL CLIMATE: MEDIATING ROLE OF ORGANIZATIONAL IDENTIFICATION</td>
    <td >05-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>162</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Kundan Singh</td>
    <td >Sandeep Kaur</td>
    <td >Full Time</td>
    <td >11312220</td>
    <td >06-08-2013</td>
    <td >ORGANIZATIONAL COMMITMENT AMONG SECONDARY SCHOOL TEACHERS: ROLE OF PSYCHOLOGICAL EMPOWERMENT, JOB INVOLVEMENT AND ORGANIZATIONAL HEALTH</td>
    <td >05-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>163</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Pravin Kumar</td>
    <td >Neha</td>
    <td >Full Time</td>
    <td >11312149</td>
    <td >06-08-2013</td>
    <td >EFFECT OF YOGIC AND RECREATIONAL ACTIVITIES ON PSYCHO-SOCIAL, PHYSIOLOGICAL AND BIOCHEMICAL PARAMETERS OF HIV PATIENTS</td>
    <td >05-08-2018</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>164</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Kundan Singh</td>
    <td >Om Parkash</td>
    <td >Part Time</td>
    <td >41300087</td>
    <td >16-08-2013</td>
    <td >EFFECTIVENESS OF SECONDARY SCHOOL TEACHERS IN RELATION TO PERCEIVED ORGANISATIONAL CLIMATE, PSYCHOLOGICAL CAPITAL AND  LEARNING ORIENTATION</td>
    <td >15-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>165</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Yuvraj Singh</td>
    <td >Dinesh Kumar</td>
    <td >Full Time</td>
    <td >11412556</td>
    <td >07-08-2014</td>
    <td >DEVELOPMENT OF TALENT IDENTIFICATION MODEL FOR HOCKEY</td>
    <td >06-08-2019</td>
    <td >YES</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>166</td>
    <td >Technology and Sciences</td>
    <td >Nutrition&amp;Dietics</td>
    <td >Dr. Beenu Tanwar</td>
    <td >Piverjeet Kaur</td>
    <td >Full Time</td>
    <td >11412576</td>
    <td >07-08-2014</td>
    <td >NUTRITION KNOWLEDGE IN ASSOCIATION WITH HEALTH STATUS OF PROSTATE CANCER (PCA) PATIENTS IN SELECTED HOSPITALS OF BHATINDA CITY.</td>
    <td >06-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>167</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. A.K.Srivastava</td>
    <td >Jyoti Sharma</td>
    <td >Full Time</td>
    <td >11412633</td>
    <td >07-08-2014</td>
    <td >MULTIFERROICS PROPERTIES OF RARE EARTH AND TRANSITION METAL OXIDES</td>
    <td >06-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>168</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Yash Deep Singh</td>
    <td >Sundus Quyoom</td>
    <td >Full Time</td>
    <td >11412879</td>
    <td >09-08-2014</td>
    <td >TRANSCENDING RACE, REGION AND RELIGION: THE PAIN OF BEING A WOMAN</td>
    <td >08-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>169</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jit Pal Aggarwal</td>
    <td >Richa Arora</td>
    <td >Part Time</td>
    <td >41400056</td>
    <td >07-08-2014</td>
    <td >CONTEXTUALIZING BLUE BEARD PATRIARCHY AND THE AESTHETICS OF SEXUALITY: A FEMINIST READING OF THE SELECT NOVELS OF ANGELA CARTER, BAPSI SIDHWA AND MONICA ALI</td>
    <td >06-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>170</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Kirandeep Singh</td>
    <td >Gurdarshan Singh</td>
    <td >Part Time</td>
    <td >41400062</td>
    <td >07-08-2014</td>
    <td >1990 TON BAAD DI DALIT PUNJABI KAHAANI DA SAMAAJ-MANOVIGYANAK ADHYAN</td>
    <td >06-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>171</td>
    <td >Technology and Sciences</td>
    <td >Nutrition&amp;Dietics</td>
    <td >Dr. Anil Panghal</td>
    <td >Rachna Khosla</td>
    <td >Part Time</td>
    <td >41400063</td>
    <td >07-08-2014</td>
    <td >ROLE OF DIETARY HABITS IN THE DEVELOPMENT OF ESOPHAGEAL CANCER IN THE DOABA REGION OF PUNJAB</td>
    <td >06-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>172</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Kirandeep Singh</td>
    <td >Jatinder Singh</td>
    <td >Part Time</td>
    <td >41400065</td>
    <td >07-08-2014</td>
    <td >SAHIB SINGH DE NATKAN DA SAMAJ SHAASTRI ADHYAN</td>
    <td >06-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>173</td>
    <td >Applied Medical Sciences</td>
    <td >Ayurvedic Pharmacy</td>
    <td >Dr. Sachin Kumar Singh</td>
    <td >Barinder Kaur</td>
    <td >Part Time</td>
    <td >41400076</td>
    <td >08-08-2014</td>
    <td >DEVELOPMENT AND EVALUATION OF POLYHERBAL FORMULATION CONTAINING GOLD NANOPARTICLES FOR TREATMENT OF HYPERLIPIDEMIA AND TYPE - II DIABETES MELLITUS IN RAT MODEL&rdquo;</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>174</td>
    <td >Business and Arts</td>
    <td >Fine Arts and Performing</td>
    <td >Dr. Kulbir Kaur Virk</td>
    <td >Gurtej Singh</td>
    <td >Part Time</td>
    <td >41400080</td>
    <td >08-08-2014</td>
    <td >महाभारत की मुख्य नायिकायों में नाटकीय संभावनाएं</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>175</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Kirandeep Singh</td>
    <td >Manpreet Singh</td>
    <td >Part Time</td>
    <td >41400113</td>
    <td >09-08-2014</td>
    <td >PUNJABI NATAK VICH PESH NARI SASHAKTIKARAN DA SAMIKHYATMAK ADHYAN</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>176</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Umesh Goutam</td>
    <td >Kajal</td>
    <td >Full Time</td>
    <td >11410650</td>
    <td >22-07-2014</td>
    <td >CLONING AND OVER EXPRESSION OF WILT RESISTANCE GENES FROM POTATO (SOLANUM TUBEROSUM L.) CULTIVARS FOR ENHANCING BACTERIAL WILT RESISTANCE</td>
    <td >21-07-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>177</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Ashish Kumar</td>
    <td >Isha Batra</td>
    <td >Part Time</td>
    <td >11412467</td>
    <td >06-08-2014</td>
    <td >DESIGNING A HYBRID LIGHTWEIGHT LOGICAL SECURITY FRAMEWORK FOR INTERNET OF THINGS</td>
    <td >05-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>178</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Devendra Kumar Pandey</td>
    <td >Shahnawaz</td>
    <td >Full Time</td>
    <td >11412651</td>
    <td >08-08-2014</td>
    <td >IN VITRO PRODUCTION OF ZERO CALORIE NATURAL SWEETENER AND ANTIOXIDANT COMPOUNDS FROM STEVIA REBAUDIANA</td>
    <td >07-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>179</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Ashish Kumar</td>
    <td >Vivek Sharma</td>
    <td >Full Time</td>
    <td >11412696</td>
    <td >08-08-2014</td>
    <td >MICELLIZATION BEHAVIOUR OF SOME IONIC SURFACTANTS IN DMSO-WATER AND GLYCEROL-WATER MIXED SOLVENT SYSTEMS AND INFLUENCE OF BSA</td>
    <td >07-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>180</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Ramesh chand Thakur</td>
    <td >Ravi Sharma</td>
    <td >Full Time</td>
    <td >11412716</td>
    <td >08-08-2014</td>
    <td >STUDY OF THERMODYNAMIC AND TRANSPORT PROPERTIES OF SOMEWATER SOLUBLE VITAMINS IN BINARY AQUEOUS MIXTURES OF SUGARS</td>
    <td >07-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>181</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Rekha</td>
    <td >Dharmender</td>
    <td >Full Time</td>
    <td >11412730</td>
    <td >08-08-2014</td>
    <td >SYNTHESIS CHARACTERIZATION BIOLOGICAL AND CATALYTIC ACTIVITY OF COMPLEXES OF THIOSEMICARBAZONES WITH NI(II)</td>
    <td >07-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>182</td>
    <td >Technology and Sciences</td>
    <td >Zoology</td>
    <td >Dr. Rahul Singh</td>
    <td >Arun Chauhan</td>
    <td >Full Time</td>
    <td >11412806</td>
    <td >09-08-2014</td>
    <td >DEVELOPMENT OF PROBIOTICS FROM AQUATIC BODIES FOR ENHANCED PRODUCTIVITY IN FISH FARMING</td>
    <td >08-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>183</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Kailash Chandra Juglan</td>
    <td >Kirandeep Kaur</td>
    <td >Part Time</td>
    <td >11412812</td>
    <td >09-08-2014</td>
    <td >ULTRASONIC VOLUMETRIC AND STUDY OF LIQUID MIXTURES CONTAING GLYCOLS AT DIFFERENT TEMPERATURES</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>184</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Kundan Singh</td>
    <td >Priyanka</td>
    <td >Full Time</td>
    <td >11412825</td>
    <td >09-08-2014</td>
    <td >INFLUENCE OF EMOTIONAL EXHAUSTION ON SELF EFFICACY AND WORK PERFORMANCE AMONG SECONDARY SCHOOL TEACHERS: ROLE OF ORGANIZATIONAL JUSTICE</td>
    <td >08-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>185</td>
    <td >Business and Arts</td>
    <td >Fine Arts and Performing</td>
    <td >Dr. Abid Hadi</td>
    <td >Masooma Rizvi</td>
    <td >Full Time</td>
    <td >11412837</td>
    <td >09-08-2014</td>
    <td >REMNANTS OF WALL PAINTINGS IN PUNJAB - AN ANALYSIS AND EXPLORATORY STUDY</td>
    <td >08-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>186</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Mukesh Kumar</td>
    <td >Punam Kumari</td>
    <td >Full Time</td>
    <td >11412844</td>
    <td >09-08-2014</td>
    <td >NATURAL RADIOACTIVITY MEASUREMENTS IN THE ENVIRONS OF CHAMBA DISTRICT OF HIMACHAL PRADESH INDIA</td>
    <td >08-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>187</td>
    <td >Business and Arts</td>
    <td >commerce</td>
    <td >Dr. Sabyasachi Tipathi</td>
    <td >Ishaq Ahmad Dar</td>
    <td >Full Time</td>
    <td >11412868</td>
    <td >09-08-2014</td>
    <td >DETERMINANTS OF INTERNATIONALIZATION AND THEIR RELATIONSHIP WITH PERFORMANCE OF SMALL AND MEDIUM ENTERPRISES IN PUNJAB</td>
    <td >08-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>188</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. G Geetha</td>
    <td >Sawroop Kaur</td>
    <td >Full Time</td>
    <td >11412869</td>
    <td >09-08-2014</td>
    <td >SMART DISTRIBUTED FOCUSED WEB CRAWLER FOR HIDDEN WEB</td>
    <td >08-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>189</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Lovi Raj Gupta</td>
    <td >Nidhi Rani Kalia</td>
    <td >Full Time</td>
    <td >11412871</td>
    <td >09-08-2014</td>
    <td >FORMULATION OF A NEW AUGMENTED REALITY BASED ALGORITHM FOR NAVIGATION AND DECISION MAKING IN AUTOMATED VEHICLES USING IMAGE PROCESSING </td>
    <td >08-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>190</td>
    <td >Business and Arts</td>
    <td >Psychology</td>
    <td >Dr. Hariom Sharma</td>
    <td >Samreen Naz</td>
    <td >Full Time</td>
    <td >11412936</td>
    <td >09-08-2014</td>
    <td >STUDY OF EMOTIONAL COMPETENCE RESILIENCE JOB SATISFACTION AND MENTAL HEALTH OF MEDICAL PROFESSIONALS IN PUBLIC AND PRIVATE HOSPITALS</td>
    <td >08-08-2019</td>
    <td >YES</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>191</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Ashish Kumar</td>
    <td >Sumayah Bashir</td>
    <td >Full Time</td>
    <td >11413015</td>
    <td >10-08-2014</td>
    <td >CORROSION INHIBITION OF ALUMINIUM AND STEEL BY SOME COMMON DRUGS IN ACIDIC MEDIUM</td>
    <td >09-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>192</td>
    <td >Business and Arts</td>
    <td >Economics</td>
    <td >Dr. Vishal Sarin</td>
    <td >Biswash Gauchan</td>
    <td >Full Time</td>
    <td >11413317</td>
    <td >19-08-2014</td>
    <td >ANALYZING THE PROSPECTS OF MONETARY INTEGRATION IN SOUTH ASIA</td>
    <td >18-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>193</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Mukesh Kumar</td>
    <td >Mughavi A Tuccu</td>
    <td >Full Time</td>
    <td >11413454</td>
    <td >25-08-2014</td>
    <td >STUDY OF RADIOACTIVITY IN THE ENVIRONS OF DHIMAPUR DISTRICT OF NAGALAND INDIA)</td>
    <td >24-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>194</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Devendra Kumar Pandey</td>
    <td >Prabjot Kaur</td>
    <td >Full Time</td>
    <td >11413590</td>
    <td >24-02-2015</td>
    <td >ASSESSMENT OF GENETIC DIVERSITY AMONG SWERTIA SPECIES AND BIOTECHNOLOGICAL STRATEGIES FOR PRODUCTION OF BIO-ACTIVE COMPOUNDS</td>
    <td >23-02-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>195</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Susanta Kumar Panda</td>
    <td >Udyan Bhatt</td>
    <td >Full Time</td>
    <td >11413592</td>
    <td >24-02-2015</td>
    <td >POTENTIAL OF IMPORT SUBSITUTION IN SPORTS GOOD SECTOR IN INDIA</td>
    <td >23-02-2020</td>
    <td >YES</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>196</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Rekha</td>
    <td >Sandeep Kaur</td>
    <td >Full Time</td>
    <td >11413587</td>
    <td >19-02-2015</td>
    <td >SYNTHESIS CHARACTERIZATION AND BIOLOGICAL ACTIVITIES OF COMPLEXES OF SELENOSEMICARBAZONES WITH FIRST ROW TRANSITION METALS</td>
    <td >18-02-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>197</td>
    <td >Business and Arts</td>
    <td >Economics</td>
    <td >Dr. Tushinder Preet Kaur</td>
    <td >Meenakshi</td>
    <td >Part Time</td>
    <td >41400045</td>
    <td >05-08-2014</td>
    <td >THE IMPACT OF SOCIO-ECONOMIC AND DEMOGRAPHIC DIFFRENTIALS ON DEMOGRAPHIC DIVIDEND OF PUNJAB</td>
    <td >04-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>198</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. S. Hari Babu</td>
    <td >Anup Kumar Srivastava</td>
    <td >Part Time</td>
    <td >41400047</td>
    <td >06-08-2014</td>
    <td >ALTERNATE ASSET CLASS AND PORTFOLIO DIVERSIFICATION: AN EXPLORATORY STUDY WITH REFERENCE TO MODERN INDIAN ART</td>
    <td >05-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>199</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Ajay Prashad Gautam</td>
    <td >Manpreet Kaur Kang</td>
    <td >Part Time</td>
    <td >41400048</td>
    <td >06-08-2014</td>
    <td >EFFICACY OF BALL-BALLOON BLOWING AND REHABILITATION EXERCISE PROGRAM ON PRE AND POSTOPERATIVE KNEE OSTEOARTHRITIS</td>
    <td >05-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>200</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Harminder Singh</td>
    <td >Mukesh Kumar</td>
    <td >Part Time</td>
    <td >41400051</td>
    <td >06-08-2014</td>
    <td >BIO-POLYMER BASED TRANSITION METAL NANO FERRITE COMPOSITES: SYNTHESIS CHARACTERIZATION AND ADSORPTION BEHAVIOUR</td>
    <td >05-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>201</td>
    <td >Business and Arts</td>
    <td >Geography</td>
    <td >Dr. Ripudaman Singh</td>
    <td >Rajesh Jolly</td>
    <td >Part Time</td>
    <td >41400052</td>
    <td >06-08-2014</td>
    <td >APPLICATION OF REMOTE SENSING AND GIS FORMICRO LEVEL PLANNING OF THE KANDI REGION OF PUNJAB</td>
    <td >05-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>202</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Rajesh Verma</td>
    <td >Krishan Gopal</td>
    <td >Part Time</td>
    <td >41400053</td>
    <td >07-08-2014</td>
    <td >INFLUENCE OF POLITICAL MARKETING ON CITIZEN&rsquo;S POLITICAL PARTICIPATION IN PUNJAB.</td>
    <td >06-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>203</td>
    <td >Business and Arts</td>
    <td >Geography</td>
    <td >Dr.Ripudaman singh</td>
    <td >Daljit Singh</td>
    <td >Part Time</td>
    <td >41400054</td>
    <td >07-08-2014</td>
    <td >FIELD PATTERNS IN PUNJAB: A GEOGRAPHICAL ANALYSIS</td>
    <td >06-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>204</td>
    <td >Technology and Sciences</td>
    <td >Mechanical Engineering</td>
    <td >Dr. Sanjeev Saini</td>
    <td >Novepreet Dhall</td>
    <td >Part Time</td>
    <td >41400055</td>
    <td >07-08-2014</td>
    <td >INVESTIGATION ON MECHANICAL THERMAL AND MICRO STRUCTURAL PROPERTIES OF CARBON FIBER REINFORCED POLYMER NANOCOMPOSITES WITH DEGRADATION STUDY.</td>
    <td >06-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>205</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Shailesh Kumar Tripathi</td>
    <td >Prit Pal Singh</td>
    <td >Part Time</td>
    <td >41400068</td>
    <td >08-08-2014</td>
    <td >STUDY ON ASSOCIATION OF OPERATIONAL EFFICIENCY AND CUSTOMER SATISFACTION IN TERTIARY HOSPITALS IN PUNJAB&quot;</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>206</td>
    <td >Technology and Sciences</td>
    <td >Computer Applications</td>
    <td >Dr. V Sarvanan</td>
    <td >Navdeep Kumar</td>
    <td >Part Time</td>
    <td >41400070</td>
    <td >08-08-2014</td>
    <td >FRAUD DETECTION USING INFREQUENT PATTERN MINING</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>207</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. M.Rahul</td>
    <td >Priyanka Chhibber</td>
    <td >Part Time</td>
    <td >41400072</td>
    <td >08-08-2014</td>
    <td >APPLICATION OF WORKPLACE MENTORING TOWARDS IDENTIFICATION AND OVERCOMING OF SKILL GAP AMONG EMPLOYEES IN RETAIL SECTOR OF PUNJAB</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>208</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Geeta Arora</td>
    <td >Varun Joshi</td>
    <td >Part Time</td>
    <td >41400073</td>
    <td >08-08-2014</td>
    <td >THE NUMERICAL SOLUTIONS OF SOME LINEAR AND NONLINEAR PARTIAL DIFFERENTIAL EQUATIONS USING TRIGONOMETRIC B-SPLINE BASIS FUNCTIONS</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>209</td>
    <td >Business and Arts</td>
    <td >Fine Arts and Performing</td>
    <td >Dr. Pavitar Prakash Singh</td>
    <td >Deepak Kochhar</td>
    <td >Part Time</td>
    <td >41400074</td>
    <td >08-08-2014</td>
    <td >INFLUENCE OF ANIMATION ON INDIAN ADVERTISING INDUSTRY</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>210</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Ranjan Bala</td>
    <td >Geetika</td>
    <td >Part Time</td>
    <td >41400075</td>
    <td >08-08-2014</td>
    <td >ACADEMIC SELF-HANDICAPPING AMONG STUDENTS: ROLE OF GOALORIENTATION FAMILY COMMUNICATION PATTERNS AND LEARNING ENVIRONMENT</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>211</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. S. Hari Babu</td>
    <td >Rohit Bansal</td>
    <td >Part Time</td>
    <td >41400077</td>
    <td >08-08-2014</td>
    <td >A STUDY ON FINANCIAL DISTRESS PREDICTION AMONG SELECTED COMPANIES WITH SPECIAL REFERENCE TO FINANCIAL MARKET AND MACRO ECONOMIC VARIABLES</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>212</td>
    <td >Technology and Sciences</td>
    <td >Microbiology</td>
    <td >Dr. Shalini Singh</td>
    <td >Abhijit Kumar</td>
    <td >Part Time</td>
    <td >41400079</td>
    <td >08-08-2014</td>
    <td >EVALUATION OF BIOREMEDIATIVE ABILITY OF BACTERIAL STRAINS FOR ALLEVIATING HEAVY METAL POLLUTION</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>213</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Satish Sharma</td>
    <td >Gaganpreet Sharma</td>
    <td >Part Time</td>
    <td >41400084</td>
    <td >08-08-2014</td>
    <td >DEVELOPMENT OF PHYSICAL ACTIVITY CURRICULUM AND ITS EFFECT ON ANTHROPOMETRIC BIOMOTOR AND PHYSIOLOGICAL VARIABLES OF ELEMENTARY SCHOOL STUDENTS</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>214</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Pooja Gupta</td>
    <td >Parminder Singh</td>
    <td >Part Time</td>
    <td >41400088</td>
    <td >08-08-2014</td>
    <td >RESOURCE PROVISIONING FOR MULTI-TIER WEB APPLICATIONS BASED ON WORKLOAD PREDICTION IN CLOUD COMPUTING</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>215</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Pooja Gupta</td>
    <td >Avinash Kaur</td>
    <td >Part Time</td>
    <td >41400090</td>
    <td >08-08-2014</td>
    <td >DATA-AWARE PLACEMENT AND SCHEDULING FOR SCIENTIFIC WORKFLOW IN CLOUD COMPUTING</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>216</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Ajoy Bhatta</td>
    <td >Amrik Singh</td>
    <td >Part Time</td>
    <td >41400094</td>
    <td >08-08-2014</td>
    <td >EXPLORING THE SELECTED NOVELS OF KHUSHWANT SINGH CHAMAN NAHAL AND BAPSI SIDHWA IN THE LIGHT OF SIGMUND FREUD'S THEORY OF NACHTRAGLICHKEIT 'DEFERRED ACTION'</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>217</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. S. Hari Babu</td>
    <td >Anoop Mohanty</td>
    <td >Part Time</td>
    <td >41400095</td>
    <td >09-08-2014</td>
    <td >CONSUMER TECHNOLOGY READINESS USER'S INTERACTION SATISFACTION AND INTENTION TO CONTINUE FOR TECHNOLOGY ENABLED RETAIL BANKING SERVICES - A CASE STUDY OF SELECTED CITIES OF NORTH INDIA</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>218</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Ashish Kumar</td>
    <td >Monica Sood</td>
    <td >Part Time</td>
    <td >41400097</td>
    <td >09-08-2014</td>
    <td >ANALYSIS OF NATURE INSPIRED INTELLIGENCE IN THE DOMAIN OF PATH PLANNING AND SEARCHING WITH CONSIDERATION OF VARIOUS PARAMETERS</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>219</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. G Geetha</td>
    <td >Rahul Saha</td>
    <td >Part Time</td>
    <td >41400102</td>
    <td >09-08-2014</td>
    <td >DESIGN AND ANALYSIS OF SYMMETRIC RANDOM FUNCTION GENERATOR AS A NEW CRYPTOGRAPHIC PRIMITIVE</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>220</td>
    <td >Technology and Sciences</td>
    <td >Electronics and Electrical Engineering</td>
    <td >Dr. Sandeep Dhariwal</td>
    <td >Raj Kumar Sharma</td>
    <td >Part Time</td>
    <td >41400103</td>
    <td >09-08-2014</td>
    <td >DESIGN &amp; ANALYSIS OF A NOVEL HYBRID X BIT MULTIPLY AND ACCUMULATE (MAC) ARCHITECTURE USING CLOCK GATING SCHEME FOR PIPELINED PROCESSING</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>221</td>
    <td >Applied Medical Sciences</td>
    <td >Ayurvedic Pharmacy</td>
    <td >Dr. Amit Bhatia</td>
    <td >Dileep Singh Baghel</td>
    <td >Part Time</td>
    <td >41400104</td>
    <td >09-08-2014</td>
    <td >DEVELOPMENT AND EVALUATION OF ANTIUROLITHIC POLY HERBAL FORMULATION</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>222</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. John Eliezer</td>
    <td >Mamta Rana</td>
    <td >Part Time</td>
    <td >41400106</td>
    <td >09-08-2014</td>
    <td >THE PRAGMATICS OF THE COLLOQUY IN PUBLIC SPEECHES</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>223</td>
    <td >Technology and Sciences</td>
    <td >Biotechnology</td>
    <td >Dr. Chayanika Putatunda</td>
    <td >Nishtha Pandey</td>
    <td >Part Time</td>
    <td >41400107</td>
    <td >09-08-2014</td>
    <td >MICROBIAL PRODUCTION AND CHARACTERIZATION OF GLUTEN DIGESTING PROTEASE(S)</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>224</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Harjit Kaur</td>
    <td >Harish Mittu</td>
    <td >Part Time</td>
    <td >41400108</td>
    <td >09-08-2014</td>
    <td >IMPACT OF B. ED. PROGRAMME ON PUPIL TEACHERS TEACHER EDUCATORS PRINCIPALS AND INSTITUTIONS: AN EVALUATIVE STUDY</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>225</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Nimisha Beri</td>
    <td >Kamalpreet Kaur</td>
    <td >Part Time</td>
    <td >41400109</td>
    <td >09-08-2014</td>
    <td >NON COGNITIVE SKILLS AND SOCIAL SUPPORT AS PREDICTORS OF ACADEMIC SUCCESS AMONG PROFESSIONAL STUDENTS</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>226</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Avtar Singh</td>
    <td >Mangal Lal</td>
    <td >Part Time</td>
    <td >41400114</td>
    <td >09-08-2014</td>
    <td >SUMKALI PUNJABI KAVITA: PARMUKH SAROKAAR ATTE SANCHAAR VIDHAAN ( 2000 TAUN BAAD DI PUNJABI KAVITA DE SANDARABH VICH )</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>227</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Kumar Shailesh</td>
    <td >Syed Tabrez Hassan</td>
    <td >Part Time</td>
    <td >41400115</td>
    <td >09-08-2014</td>
    <td >A STUDY OF CONSUMER BEHAVIOUR BASED ON ONLINE PURCHASE PROCESS OFFERED BY E-COMMERCE WEBSITES TO MEASURE VALUE-PROPOSITION FOR BUYERS IN INDIA</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>228</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Dinkar Sharma</td>
    <td >Prince Singh</td>
    <td >Part Time</td>
    <td >41400118</td>
    <td >09-08-2014</td>
    <td >SERIES EXPANSIONS METHODS FOR SOLVING NON-LINEAR PARTIAL DIFFERENTIAL EQUATIONS</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>229</td>
    <td >Business and Arts</td>
    <td >Fine Arts and Performing</td>
    <td >Dr. Rohita Sharma</td>
    <td >Jitendra Kumar Sharma</td>
    <td >Part Time</td>
    <td >41400119</td>
    <td >09-08-2014</td>
    <td >ROLE OF FAMILY COHESIVENESS SOCIAL CAPITAL AND SOCIO-EMOTIONAL WEALTH IN ENTREPRENEURIAL ORIENTATION - BUSINESS PERFORMANCE RELATIONSHIP</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>230</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmaceutical Sciences</td>
    <td >Dr. Sachin kumar Singh</td>
    <td >Narendra Kumar Pandey</td>
    <td >Part Time</td>
    <td >41400121</td>
    <td >09-08-2014</td>
    <td >NANOTECHNOLOGY MEDIATED CO-FORMULATION OF SIMVASTATIN AND GLIMEPIRIDE</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>231</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Kirandeep Singh</td>
    <td >Surinder Kumar</td>
    <td >Part Time</td>
    <td >41400125</td>
    <td >09-08-2014</td>
    <td >RAVINDER RAVI DE KAV-NATKAN DA VISHVIKARN DE SANDHARBH VICH ADHYAN</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>232</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Balwinder Singh Thind</td>
    <td >Naib Singh</td>
    <td >Part Time</td>
    <td >41400130</td>
    <td >09-08-2014</td>
    <td >VISHVIKARN DAUR DE PUNJABI NOVEL VICH NIMAN-KISSANI SANKAT</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>233</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Mritunjay Kumar Rai</td>
    <td >Max Bhatia</td>
    <td >Part Time</td>
    <td >41400131</td>
    <td >09-08-2014</td>
    <td >BEHAVIORAL ANALYSIS OF PEER-TO-PEER NETWORK TRAFFIC USING STATISTICAL TECHNIQUE TO IMPROVE IDENTIFICATION ACCURACY</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>234</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Kailash Chandra Juglan</td>
    <td >Alok Jain</td>
    <td >Part Time</td>
    <td >41400132</td>
    <td >09-08-2014</td>
    <td >STUDY OF ACOUSTICAL AND THERMODYNAMIC PROPERTIES OF GRAPHENE OXIDE (GO) AND REDUCED GRAPHENE OXIDE (RGO) IN WATER AND SOME ORGANIC SOLVENTS</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>235</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Kirandeep Singh</td>
    <td >Gurpinder Singh</td>
    <td >Part Time</td>
    <td >41400135</td>
    <td >09-08-2014</td>
    <td >CULTURAL TRANSFORMATION IN CONTEMPORARY PUNJABI STORY</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>236</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Vishal Sareen</td>
    <td >Namita Kaur</td>
    <td >Part Time</td>
    <td >41400137</td>
    <td >09-08-2014</td>
    <td >(TRADE PERFORMANCE ND COMPETITIVENESS: A STUDY OF INDIA-ASEAN TRADE RELATIONS IN CONTEXT OF LOOK EAST POLICY)</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>237</td>
    <td >Technology and Sciences</td>
    <td >Computer Applications</td>
    <td >Dr. Prateek Jain</td>
    <td >Rajni Bhalla</td>
    <td >Part Time</td>
    <td >41400098</td>
    <td >09-08-2014</td>
    <td >DESIGNING A SECURE OPINION MINING FRAMEWORK BY TRUSTWORTHINESS IN BIG DATA FOR FEATURE SENTIMENT MINING AND FEATURE OPINION PAIRS</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>238</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Jit Pal Aggarwal</td>
    <td >Rituparna Chakraborty</td>
    <td >Part Time</td>
    <td >41400145</td>
    <td >09-08-2014</td>
    <td >CONFRONTATION AND COMMITMENT: THE EMERGENCE OF THE NEW WOMEN IN SELECT NOVELS OF GEORGE ELIOT GEORGE GISSING AND THOMAS HARDY</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>239</td>
    <td >Technology and Sciences</td>
    <td >Horticulture</td>
    <td >Dr. Jasbir Singh Bal</td>
    <td >Sukhdip Singh</td>
    <td >Part Time</td>
    <td >41400148</td>
    <td >10-08-2014</td>
    <td >PERFORMANCE OF EXOTIC MANDARIN CULTIVARS ON DIFFERENT ROOT STOCKS IN SUB-TROPICAL PLAINS</td>
    <td >09-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>240</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Senthil Paramasivam Kumar</td>
    <td >Varun Kalia</td>
    <td >Part Time</td>
    <td >41400150</td>
    <td >10-08-2014</td>
    <td >EFFICACY OF MYOFASCIAL TRIGGER POINT DRY NEEDLING WITH &amp; WITHOUT PARASPINAL NEEDLING IN PATIENTS WITH ADHESIVE CAPSULITIS.A RANDOMIZED CLINICAL TRIAL</td>
    <td >09-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>241</td>
    <td >Business and Arts</td>
    <td >Geography</td>
    <td >Dr. Harvinder Singh</td>
    <td >Mridula Pushkarna</td>
    <td >Part Time</td>
    <td >41400151</td>
    <td >10-08-2014</td>
    <td >SPATIAL ANALYSIS OF EDUCATIONALLY BACKWARD BLOCKS OF PUNJAB </td>
    <td >09-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>242</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Suman Rani</td>
    <td >Gurjasjeet Kaur</td>
    <td >Part Time</td>
    <td >41400154</td>
    <td >10-08-2014</td>
    <td >A COMPARATIVE STUDY OF THE FEMALE CHARACTERS IN THE SELECTED NOVELS OF V.S. NAIAPUL AND SALMAN RUSHDIE.</td>
    <td >09-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>243</td>
    <td >Technology and Sciences</td>
    <td >Nutrition&amp;Dietics</td>
    <td >Dr. Nancy Sahini</td>
    <td >Sukhjinder Singh</td>
    <td >Part Time</td>
    <td >41400157</td>
    <td >10-08-2014</td>
    <td >IMPACT OF HERBS BASED LIFESTYLE INTERVENTION REGIME ON SEXUAL DYSFUNCTION OF DIABETIC MALE ADULTS: A RANDOMIZED CONTROLLED TRAIL</td>
    <td >09-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>244</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Rajesh Kumar Gupta</td>
    <td >Sukhdev Singh</td>
    <td >Part Time</td>
    <td >41400160</td>
    <td >10-08-2014</td>
    <td >A STUDY OF BICOMPLEX SPACE WITH A TOPOLOGICAL VIEW POINT</td>
    <td >09-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>245</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. G Geetha</td>
    <td >Sumit Mittu</td>
    <td >Part Time</td>
    <td >41400169</td>
    <td >10-08-2014</td>
    <td >DESIGN AND DEVELOPMENT OF A REVERSE IMAGE SEARCH ENGINE</td>
    <td >09-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>246</td>
    <td >Technology and Sciences</td>
    <td >Mechanical Engineering</td>
    <td >Dr. Sumit Sharma</td>
    <td >Manish Dhawan</td>
    <td >Part Time</td>
    <td >41400175</td>
    <td >11-08-2014</td>
    <td >MOLECULAR DYNAMICS SIMULATION OF INTERPHASIAL  PROPERTIES OF CARBON NANOTUBE REINFORCED POLYMER COMPOSITES</td>
    <td >10-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>247</td>
    <td >Technology and Sciences</td>
    <td >Electronics and Electrical Engineering</td>
    <td >Dr. Himanshu Monga</td>
    <td >Sandeep Kumar Arora</td>
    <td >Part Time</td>
    <td >41400177</td>
    <td >11-08-2014</td>
    <td >DESIGN OF SECURE SESSION INITIATION PROTOCOL FOR VEHICULAR AD HOC NETWORKS</td>
    <td >10-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>248</td>
    <td >Technology and Sciences</td>
    <td >Electronics and Electrical Engineering</td>
    <td >Dr. Himanshu Monga</td>
    <td >Shakti Raj Chopra</td>
    <td >Part Time</td>
    <td >41400179</td>
    <td >11-08-2014</td>
    <td >MULTILEVEL SPACE-TIME TRELLIS CODING IN COOPERATIVE RELAY NETWORKS WITH APPLICATION IN COGNITIVE RADIO</td>
    <td >10-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>249</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Umasankar Mohanty</td>
    <td >Priyanka Anand</td>
    <td >Part Time</td>
    <td >41400183</td>
    <td >11-08-2014</td>
    <td >BRAIN GYM EXERCISES AND MIRROR BOX THERAPY IN HEMISPATIAL NEGLECT POST-STROKE- A RANDOMISED CLINICAL TRIAL</td>
    <td >10-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>250</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmacology</td>
    <td >Dr. Navneet Khurana</td>
    <td >Satinder Kaur</td>
    <td >Part Time</td>
    <td >41400186</td>
    <td >11-08-2014</td>
    <td >PHARMACOLOGICAL EVALUATION OF ALPHA- ASARONE AND BETAINE FOR PARKINSONS DISEASE</td>
    <td >10-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>251</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Geeta Arora</td>
    <td >Gurpreet Singh Bhatia</td>
    <td >Part Time</td>
    <td >41400187</td>
    <td >11-08-2014</td>
    <td >NUMERICAL TREATEMENT OF LINEAR AND NON-LINEAR PARTIAL DIFFERENTIAL EQUATIONS USING RADIAL BASIC FUNCTION METHODS</td>
    <td >10-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>252</td>
    <td >Technology and Sciences</td>
    <td >Horticulture</td>
    <td >Dr. J S Bal</td>
    <td >Jatinder Singh</td>
    <td >Part Time</td>
    <td >41400189</td>
    <td >11-08-2014</td>
    <td >EFFECT OF PRE- AND POST-HARVESTED TREATMENTS ON REPENING AND STORAGE LIFE OF WINTER SEASON GUAVA (PSIDIUM GUAJAVA L. VAR.ALLAHABAD SAFEDA) </td>
    <td >10-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>253</td>
    <td >Technology and Sciences</td>
    <td >Computer Applications</td>
    <td >Dr. Manmohan Sharma</td>
    <td >Sahil Rampal</td>
    <td >Part Time</td>
    <td >41400190</td>
    <td >11-08-2014</td>
    <td >A NOVEL MULTI-KEY MULTIMODALITIES ENCRYPTION ALGORITHM TO SECURE ENTERPRISE DATA ON LOCAL BUSINESS PREMISES OR OFFLOADING TO CLOUD</td>
    <td >10-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>254</td>
    <td >Technology and Sciences</td>
    <td >Electronics and Electrical Engineering</td>
    <td >Dr. Himanshu Monga</td>
    <td >Gurjot Singh</td>
    <td >Part Time</td>
    <td >41400192</td>
    <td >11-08-2014</td>
    <td >TO DESIGN &amp; IMPLEMENT EFFICIENT MESSAGE AUTHENTICATION CODE USING LIGHTWEIGHT KEY EXCHANGE PROTOCOL FOR WSN-IOT' S FRAMEWORK</td>
    <td >10-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>255</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Geeta Arora</td>
    <td >Pooja Kataria</td>
    <td >Part Time</td>
    <td >41400195</td>
    <td >13-08-2014</td>
    <td >NUMERICAL SOLUTION OF LINEAR AND NONLINEAR PARTIAL DIFFERENTIAL EQUATIONS USING EXPONENTIAL B SPLINES</td>
    <td >12-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>256</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Geeta Arora</td>
    <td >Mandeep Kaur</td>
    <td >Part Time</td>
    <td >41400197</td>
    <td >14-08-2014</td>
    <td >NUMERICAL TREATEMENT OF SINGULARLY PERTURBED DIFFERENTIAL EQUATIONS BY SOME HYBRID METHOD</td>
    <td >13-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>257</td>
    <td >Technology and Sciences</td>
    <td >Computer Applications</td>
    <td >Dr. Lovi Raj Gupta</td>
    <td >Supriya Sharma</td>
    <td >Part Time</td>
    <td >41400201</td>
    <td >19-08-2014</td>
    <td >FORMULATION OF A NEW IMAGE PROCESSING MECHANISM FOR AUGMENTED REALITY BASED NAVIGATION IN AUTONOMOUS VEHICLES FOR STATIONARY OBSTACLES</td>
    <td >18-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>258</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Ashish Kumar</td>
    <td >Shabnam Sharma</td>
    <td >Part Time</td>
    <td >41400206</td>
    <td >25-08-2014</td>
    <td >VARIOUS APPROACHES FOR HANDLING MULTIPLE TARGETS USING NATURE INSPIRED INTELLIGENCE</td>
    <td >24-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>259</td>
    <td >Business and Arts</td>
    <td >Hindi</td>
    <td >Dr. Vinod Kumar</td>
    <td >Ravinder Kumar</td>
    <td >Part Time</td>
    <td >41400207</td>
    <td >27-08-2014</td>
    <td >अब्दुल बिस्मिल्लाह के कथा-साहित्य का मनोवैज्ञानिक अध्ययन</td>
    <td >26-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>260</td>
    <td >Technology and Sciences</td>
    <td >Electronics and Electrical Engineering</td>
    <td >Dr. Rajiv Kumar Singh</td>
    <td >Paramdeep singh</td>
    <td >Part Time</td>
    <td >41400717</td>
    <td >21-02-2015</td>
    <td >DESIGN OF A PRACTICAL RF ENERGY HARVESTING CIRCUIT FOR URBAN ENVIRONMENT.</td>
    <td >20-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>261</td>
    <td >Technology and Sciences</td>
    <td >Biochemistry</td>
    <td >Dr. Arvind Kumar</td>
    <td >Sruchi Devi</td>
    <td >Full Time</td>
    <td >41400751</td>
    <td >24-02-2015</td>
    <td >THE EVALUATION OF ANTICARCINOGENIC POTENTIAL OF LECTIN ISOLATED FROM LEAVES OF ALOE BARBADENSIS (MILLER) AND BRYOPHYLLUM PINNATUM USING HUMAN CANCER CELL LINE</td>
    <td >23-02-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>262</td>
    <td >Technology and Sciences</td>
    <td >Microbiology</td>
    <td >Dr. Mahender K. Gupta</td>
    <td >Rajinder Kumar</td>
    <td >Part Time</td>
    <td >41400750</td>
    <td >24-02-2015</td>
    <td >AN EXPLORATION OF MICROBIAL HERBICIDE ACTIVITY OF RHIZOBACTERIA AS INFLUENCED BY TILLAGE AND WEED MANAGEMENT</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>263</td>
    <td >Applied Medical Sciences</td>
    <td >Ayurvedic Pharmacy</td>
    <td >Dr. S. Tamilvanan</td>
    <td >Diksha Puri</td>
    <td >Part Time</td>
    <td >41400734</td>
    <td >24-02-2015</td>
    <td >DEVELOPMENT OF JANUS EMULSION CONTAINING TRIGONELLA FOENUM-GRAECUM AND ZINGIBER OFFICINALE FOR REDUCING THE PAIN INTENSITY IN PRIMARY DYSMENORRHEAL CONDITION</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>264</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmaceutics</td>
    <td >Dr. S. Tamilvanan</td>
    <td >Prabjot Kaur</td>
    <td >Part Time</td>
    <td >41400740</td>
    <td >24-02-2015</td>
    <td >DEVELOPMENT OPTIMIZATION AND EVALUATION OF DRY POWDER INHALERS CONTAINING ANTICANCER DRUGS (PACLITAXEL AND DOXORUBICIN) - LOADED SURFACTANT AND POLYMER-BASED PULMONARY NANOLIPID CARRIER SYSTEMS FOR THE MANAGEMENT OF DRUG RESISTANCE LUNG CANCER BY P-GP INHIBITION</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>265</td>
    <td >Technology and Sciences</td>
    <td >Vegetable Science</td>
    <td >Dr. Shailesh Kumar Singh</td>
    <td >Ranjit Singh Spehia</td>
    <td >Part Time</td>
    <td >41400716</td>
    <td >19-02-2015</td>
    <td >STANDARDIZATION OF SOILLESS MEDIA AND IRRIGATION SCHEDULE FOR IMPROVING YIELD AND QUALITY OF TOMATO IN UV STABILIZED POLYBAGS UNDER POLYHOUSE</td>
    <td >18-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>266</td>
    <td >Technology and Sciences</td>
    <td >Physics</td>
    <td >Dr. Kailash Chandra Juglan</td>
    <td >Vishal Sharma</td>
    <td >Part Time</td>
    <td >41400745</td>
    <td >24-02-2015</td>
    <td >PROCESSING AND ANALYSIS OF ULTRASOUND IMAGES FOR DISEASE DIAGNOSIS</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>267</td>
    <td >Business and Arts</td>
    <td >History</td>
    <td >Dr. Manu Sharma</td>
    <td >Rakesh Bawa</td>
    <td >Part Time</td>
    <td >41400744</td>
    <td >24-02-2015</td>
    <td >SOCIAL ISSUES IN HINDI CINEMA: A COMPARATIVE STUDY OF SELECT PRODUCTION HOUSES</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>268</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Arun B.</td>
    <td >G V Ramakrishnan</td>
    <td >Part Time</td>
    <td >41400198</td>
    <td >16-08-2014</td>
    <td >EFFECTS OF MOTOR CONTROL EXERCISES ON PAINFUNCTIONAL ACTIVITY AND CORE MUSCLE STRENGTH IN CHRONIC NON-SPECIFIC LOW BACK PAIN.</td>
    <td >15-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>269</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Arun B.</td>
    <td >Arun Kumar T H</td>
    <td >Part Time</td>
    <td >41400199</td>
    <td >16-08-2014</td>
    <td >EFFECT OF VIRTUAL REALITY TRAINING ON MULTIDIRECTIONAL DYNAMIC BALANCE OF NON-PROFESSIONAL SOCCER PLAYERS.</td>
    <td >15-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>270</td>
    <td >Applied Medical Sciences</td>
    <td >Physiotherapy</td>
    <td >Dr. Arun B.</td>
    <td >Lourdhuraj  I</td>
    <td >Part Time</td>
    <td >41400200</td>
    <td >16-08-2014</td>
    <td >EFFECT OF CONTINOUS TRACKING TASK ON MOTOR LEARNING AND PERFORMANCE OF UPPER EXTREMITY FUNCTION IN CHRONIC STROKE SUBJECTS.</td>
    <td >15-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>271</td>
    <td >Business and Arts</td>
    <td >History</td>
    <td >Dr. Vinay Kumar</td>
    <td >Yogesh Gambhir</td>
    <td >Part Time</td>
    <td >41400726</td>
    <td >24-02-2015</td>
    <td >ROLE OF VERNACULAR PRESS IN INTELLECTUAL AWAKENING IN PUNJAB: A STUDY OF THE DAILY MILAP IN THE CONTEXT OF INDIAN FREEDOM MOVEMENT (1923-1947)</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>272</td>
    <td >Business and Arts</td>
    <td >History</td>
    <td >Dr. Manu Sharma</td>
    <td >Rimmi Kapur</td>
    <td >Part Time</td>
    <td >41400710</td>
    <td >17-02-2015</td>
    <td >PEASANT MOVEMENT IN PUNJAB: A STUDY OF HOSHIARPUR DISTRICT -</td>
    <td >16-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>273</td>
    <td >Business and Arts</td>
    <td >Geography</td>
    <td >Dr. Ripudaman Singh</td>
    <td >Anil Behl</td>
    <td >Part Time</td>
    <td >41400723</td>
    <td >23-02-2015</td>
    <td >REGIONAL DISPARITIES IN THE LEVELS OF DEVELOPMENT IN PUNJAB: A GEOGRAPHICAL ANALYSIS</td>
    <td >22-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>274</td>
    <td >Business and Arts</td>
    <td >Psychology</td>
    <td >Dr. Neha Sharma</td>
    <td >Monika</td>
    <td >Part Time</td>
    <td >41400761</td>
    <td >24-02-2015</td>
    <td >PREDICTORS OF PSYCHOLOGICAL WELL-BEING OF ADOLESCENTS OF WORKING AND NON-WORKING MOTHERS</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>275</td>
    <td >Technology and Sciences</td>
    <td >Electronics and Electrical Engineering</td>
    <td >Dr. Mrityunjay Kumar Rai</td>
    <td >Deepinder Singh Wadhwa</td>
    <td >Part Time</td>
    <td >41400709</td>
    <td >17-02-2015</td>
    <td >DESIGN AND EVALUATION OF TECHNIQUES TO ENHANCE THE PERFORMANCE OF DEVICE - TO - DEVICE AND COOPERATIVE DEVICE - TO - DEVICE COMMUNICATION IN HETEROGENOUS NETWORKS.</td>
    <td >16-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>276</td>
    <td >Technology and Sciences</td>
    <td >Electronics and Electrical Engineering</td>
    <td >Dr. Ravi Shankar Mishra</td>
    <td >Abhishek Kumar</td>
    <td >Part Time</td>
    <td >41400729</td>
    <td >24-02-2015</td>
    <td >DESIGN AND ANALYSIS OF CHALLENGE RESPONSE PAIR GENERATOR USING PUF AND DPA  RESISTANT S-BOX</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>277</td>
    <td >Technology and Sciences</td>
    <td >Electronics and Electrical Engineering</td>
    <td >Dr. Mritunjay Kumar Rai</td>
    <td >Koushik Barman</td>
    <td >Part Time</td>
    <td >41400752</td>
    <td >24-02-2015</td>
    <td >DESIGN AND ANALYSIS OF RESOURCE SHARING TECHNIQUE BASED ON MODE SELECTION AND POWER CONTROL FOR DD COMMUNICATION.</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>278</td>
    <td >Technology and Sciences</td>
    <td >Electronics and Electrical Engineering</td>
    <td >Dr. Sajjan Singh</td>
    <td >Manoj Sindhwani</td>
    <td >Part Time</td>
    <td >41400715</td>
    <td >19-02-2015</td>
    <td >CLUSTER HEAD SELECTION ALGORITHM UNDER TRAFFIC AND MOBILITY CONDITIONS IN VANET</td>
    <td >18-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>279</td>
    <td >Technology and Sciences</td>
    <td >Electronics and Electrical Engineering</td>
    <td >Dr. Y.S Randhawa</td>
    <td >Gurpreet Singh Saini</td>
    <td >Part Time</td>
    <td >41400731</td>
    <td >24-02-2015</td>
    <td >DESIGN AND FABRICATION OF ANTENNA FOR SATELLITE APPLICATIONS WITH OPTIMIZED PARAMETERS</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>280</td>
    <td >Business and Arts</td>
    <td >Hindi</td>
    <td >DR. VINOD KUMAR</td>
    <td >Manju Arora</td>
    <td >Part Time</td>
    <td >41400117</td>
    <td >09-08-2014</td>
    <td >नरेन्द्र कोहली कृत &lsquo;महासमर&rsquo; उपन्यास में जीवन मूल्य</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>281</td>
    <td >Business and Arts</td>
    <td >Psychology</td>
    <td >Dr. Pradeep Kumar</td>
    <td >Parul Sharma </td>
    <td >Part Time</td>
    <td >41400124</td>
    <td >09-08-2014</td>
    <td >A STUDY OF HARDINESS PERSONALITY IN RELATION TO RESILIENCE OCCUPATIONAL STRESS AND JOB COMMITMENT AMONG PRIMARY SCHOOL TEACHERS</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>282</td>
    <td >Business and Arts</td>
    <td >Psychology</td>
    <td >Dr. Pradeep Kumar</td>
    <td >Vivek Bhuchar</td>
    <td >Part Time</td>
    <td >41400120</td>
    <td >09-08-2014</td>
    <td >A STUDY OF TECHNOSTRESS IN RELATION TO JOB SATISFACTION JOB PERFORMANCE AND MENTAL HEALTH AMONG IT PROFESSIONALS</td>
    <td >08-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>283</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Balwinder Singh Thind</td>
    <td >Surinder Kaur</td>
    <td >Part Time</td>
    <td >41400757</td>
    <td >24-02-2015</td>
    <td >PARVASI PUNJABI NATAK: MANVI RISHTEYAN DA YATHARTH-BODH</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>284</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Balwinder Singh Thind</td>
    <td >Pawan Kumar</td>
    <td >Part Time</td>
    <td >41400713</td>
    <td >19-02-2015</td>
    <td >SHRI GURU GRANTH SAHIB VICH DARAJ BHAGAT BAANI DA VADANT CHINTAN ATE UTTAR ADHUNIKTA</td>
    <td >18-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>285</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Sandeep Kaur</td>
    <td >Baljeet Kaur</td>
    <td >Part Time</td>
    <td >41400708</td>
    <td >17-02-2015</td>
    <td >PUNJAB VICH KINNER SAMAJ DA VIVHARIK ADHIAN</td>
    <td >16-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>286</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Sandeep Kaur</td>
    <td >Rupinder Kaur</td>
    <td >Part Time</td>
    <td >41400703</td>
    <td >16-02-2015</td>
    <td >CONSUMER CULTURE IMPACT ON PUNJABI CULTURE: SOCIAL ECONOMIC POLITICAL ANALYSIS</td>
    <td >15-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>287</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Anita Abrol</td>
    <td >Ajaz Ahmad</td>
    <td >Part Time</td>
    <td >41400755</td>
    <td >24-02-2015</td>
    <td >THE LOSS OF KASHMIRIYAT (CULTURAL ETHOS) THROUGH THE SELECTED NOVELS OF SALMAN RUSHDHIE BASHARAT PEER SIDHARTHGIGOO AND MIRZAWAHEED.</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>288</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Geeta Arora</td>
    <td >Pratiksha</td>
    <td >Part Time</td>
    <td >41400758</td>
    <td >24-02-2015</td>
    <td >A STUDY ON THE METHODS FOR SOLVING FRACTIONAL DIFFERENTIAL EQUATIONS</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>289</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. S.S.Shrivastava</td>
    <td >Kamal Kishore</td>
    <td >Part Time</td>
    <td >41400702</td>
    <td >16-02-2015</td>
    <td >STUDY OF FOURIER SERIESAND BOUNDARY VALUE PROBLEMS INVOLVING A-FUNCTION</td>
    <td >15-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>290</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmacology</td>
    <td >Dr. Sachin Kumar Singh</td>
    <td >Amarjeet Singh</td>
    <td >Part Time</td>
    <td >41400736</td>
    <td >24-02-2015</td>
    <td >CO-FORMULATION OF VENLAFAXINE TRAMADOL AND PREDNISOLONE LOADED NANOEMULSION FOR ATTENUATION OF NEUROPATHIC PAIN</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>291</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. V. Kaul</td>
    <td >Mohinderpal Kaur</td>
    <td >Part Time</td>
    <td >41400746</td>
    <td >24-02-2015</td>
    <td >EFFECT OF MIXED MARTIAL ARTS TRAINING ON THE PHYSICAL FITNESS MOTOR SKILLS ASSIMILATION AND EMOTIONAL STABILITY OF CHILDREN WITH INTELLECTUAL DISABILITIES</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>292</td>
    <td >Business and Arts</td>
    <td >English</td>
    <td >Dr. Sanjay Prasad Panday</td>
    <td >Aastha Saini</td>
    <td >Part Time</td>
    <td >41400766</td>
    <td >24-02-2015</td>
    <td >PORTRAYL OF WOMEN IN SELECT FILMS: A FEMINIST APPROACH</td>
    <td >23-02-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>293</td>
    <td >Technology and Sciences</td>
    <td >Zoology</td>
    <td >Dr Amit Sehgal</td>
    <td >Sumaya Farooq</td>
    <td >Full Time</td>
    <td >11512531</td>
    <td >13-08-2015</td>
    <td >MODULATORY EFFECTS OF GREEN TEA AND GREEN TEA COMBINATION AGAINST BENZO(A) PYRENE-MEDIATED LUNG TUMORIGENESIS IN MICE MODEL</td>
    <td >12-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>294</td>
    <td >Technology and Sciences</td>
    <td >Chemistry</td>
    <td >Dr. Dwarika Parsad</td>
    <td >Akhil Saxena</td>
    <td >Full Time</td>
    <td >11512280</td>
    <td >10-08-2015</td>
    <td >CORROSION INHIBITION EFFECT OF SOME NATURAL PRODUCTS ON MILD STEELIN ACIDIC MEDIUM</td>
    <td >09-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>295</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Sanjay Mishra</td>
    <td >Pranav Sharma</td>
    <td >Full Time</td>
    <td >11512064</td>
    <td >06-08-2015</td>
    <td >EXTENSIONS OF PONTRYAGIN REFLEXIVE TOPOLOGICAL GROUPS BEYOND LOCAL COMPACTNESS</td>
    <td >05-08-2020</td>
    <td >Yes</td>
    <td >UGC</td>
  </tr>
  <tr>
    <td>296</td>
    <td >Business and Arts</td>
    <td >Management</td>
    <td >Dr. Babli Dhiman</td>
    <td >Gursimran Kaur</td>
    <td >Full Time</td>
    <td >11511830</td>
    <td >01-08-2015</td>
    <td >STUDY ON CO-INTEGRATION AMONG INDIAN STOCK AND COMMODITY MARKET (WITH SPECIAL REFERENCE TO SEASONALITY CO-MOVEMENT AND VOLATILITY</td>
    <td >31-07-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>297</td>
    <td >Business and Arts</td>
    <td >Economics</td>
    <td >Dr. Vishal Sarin</td>
    <td >Harwinder Kaur</td>
    <td >Full Time</td>
    <td >11511829</td>
    <td >01-08-2015</td>
    <td >TRADE SPECIALIZATION IN CONTEXT OF TRADE AND FINANCIAL INTEGRATION IN SELECTED ASIAN COUNTRIES</td>
    <td >31-07-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>298</td>
    <td >Business and Arts</td>
    <td >History</td>
    <td >Dr. Manu Sharma</td>
    <td >Akatolu Assumi</td>
    <td >Full Time</td>
    <td >11512530</td>
    <td >13-08-2015</td>
    <td >A STUDY OF NAGA TRIBES IN NAGLAND:AN ORAL HISTORY</td>
    <td >12-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>299</td>
    <td >Business and Arts</td>
    <td >Psychology</td>
    <td >Dr Komal Rai</td>
    <td >Rajandeep Kaur</td>
    <td >Full Time</td>
    <td >11512168</td>
    <td >08-08-2015</td>
    <td >THE ROLE OF PSYCHOLOGICAL FLEXIBILITY EMOTIONAL MATURITY AND FRUSTRATION TOLERANCE IN PSYCHOLOGICAL WELL BEING OF PUNJAB POLICE</td>
    <td >07-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>300</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmaceutics</td>
    <td >Dr. Sachin Kumar Singh</td>
    <td >Varun Garg</td>
    <td >Full Time</td>
    <td >11512447</td>
    <td >11-08-2015</td>
    <td >DESIGN AND OPTIMIZATION OF SELF NANO EMULSIFYING DRUG DELIVERY SYSTEM (SNEDDS) FOR POLYPEPTIDE K: ALONE AND IN COMBINATION WITH CURCUMIN FOR EFFECTIVE MANAGEMENT OF DIABETES MELLITUS</td>
    <td >10-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>301</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Ranjan BALA</td>
    <td >Hilal Bashir</td>
    <td >Full Time</td>
    <td >11511920</td>
    <td >04-08-2015</td>
    <td >PERSONALITY HARDINESS ANOMIE AND CONTEXTUAL INFLUENCES AS PREDICTORS OF ACADEMIC DISHONESTY: A MULTICAMPUS INVESTIGATION</td>
    <td >03-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>302</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Savita Gupta</td>
    <td >Liyaqat Bashir</td>
    <td >Full Time</td>
    <td >11512050</td>
    <td >06-08-2015</td>
    <td >SOCIAL NETWORKING USAGEACADEMIC PROCRASTINATION AND PERFORMANCE AMONG UNIVERSITY STUDENTS: ROLE OF SELF EFFICACY AND METACOGNITIVE BELIEFS</td>
    <td >05-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>303</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Vijay Kumar Chechi</td>
    <td >Anuradha Joshi</td>
    <td >Part Time</td>
    <td >41500143</td>
    <td >22-03-2016</td>
    <td >BULLYING PREVALENCE AND PSYCHOSOMATIC PROBLEMS AMONG CBSE SCHOOL STUDENTS: ROLE OF SOCIAL SUPPORT</td>
    <td >21-03-2022</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>304</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Kundan Singh</td>
    <td >Bindu Gera</td>
    <td >Full Time</td>
    <td >11512549</td>
    <td >17-08-2015</td>
    <td >INFLUNCE OF ORGANIZATIONAL  JUSTICE  AND CYNICISM ON THE WORKPLACE  DEVIANCE AMONG UNIVERSITY TEACHERS:ROLE OF EMOTIONAL INTELLIGENCE</td>
    <td >16-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>305</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Neelam K Sharma</td>
    <td >Mahak</td>
    <td >Full Time</td>
    <td >11511891</td>
    <td >03-08-2015</td>
    <td >EFFECT OF KIDNET KARMA YOGIC TEACHING AND NOSTALGIC STREET GAMES ON THE STATE OF SOPHROSYNE AND POST TRAUMATIC STRESS DISORDER AMONG ORPHAN CHILDREN.</td>
    <td >02-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>306</td>
    <td >Business and Arts</td>
    <td >Physical Education</td>
    <td >Dr. Manohar Lal</td>
    <td >Sudha Bhatt</td>
    <td >Part Time</td>
    <td >11512496</td>
    <td >12-08-2015</td>
    <td >ANALYZING POSITIONAL PLAY IN FEMALE FIELD HOCKEY</td>
    <td >11-08-2021</td>
    <td >No</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>307</td>
    <td >Business and Arts</td>
    <td >Psysical Education</td>
    <td >Dr. Manoharlal</td>
    <td >Gaganpreet Kaur</td>
    <td >Full Time</td>
    <td >11511648</td>
    <td >27-07-2015</td>
    <td >ASSOCIATION OF BODY DIMENSIONS AND KINEMATIC VARIABLES WITH THE PERFORMANCE OF ELITE WEIGHTLIFTERS</td>
    <td >26-07-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>308</td>
    <td >Business and Arts</td>
    <td >Journalism and Mass Communication</td>
    <td >Dr. Subhash Kumar</td>
    <td >Km Vinita</td>
    <td >Full Time</td>
    <td >11512569</td>
    <td >19-08-2015</td>
    <td >IMPACT OF HOLLYWOOD MOVIES ON INDIAN CINEMA WITH SPECIAL REFERENCE TO TECHNOLOGICAL INVENTION</td>
    <td >18-08-2020</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>309</td>
    <td >Technology and Sciences</td>
    <td >Electronics &amp; Communication Engineering</td>
    <td >Dr. Sandeep Dhariwal</td>
    <td >Jaideep Singh</td>
    <td >Part Time</td>
    <td >41500108</td>
    <td >19-08-2015</td>
    <td >THREAT ESTIMATION OF ARP POISONING IN WIRELESS NETWORKS AND FORMULATION OF EFFECTIVE PREVENTION TECHNIQUE</td>
    <td >18-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>310</td>
    <td >Technology and Sciences</td>
    <td >Mechanical Engineering</td>
    <td >Dr. Sumit Sharma</td>
    <td >Gagandeep Singh  Raheja</td>
    <td >Part Time</td>
    <td >41500115</td>
    <td >21-08-2015</td>
    <td >DEVELOPMENT OF ALUMINUM METAL MATRIX COMPOSITES REINFORCED WITH MICRO/NANO REINFORCEMENTS BY FRICTION STIR PROCESSING </td>
    <td >20-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>311</td>
    <td >Technology and Sciences</td>
    <td >Nutrition&amp;Dietics</td>
    <td >Dr. Neeta Raj Sharma</td>
    <td >Pooja Goyal</td>
    <td >Part Time</td>
    <td >41500113</td>
    <td >20-08-2015</td>
    <td >THE EFFECT OF PROBIOTIC VSL# AND LIFESTYLE INTERVENTION IN OBESE CHILDREN WITH NON-ALCOHOLIC FATTY LIVER DISEASE (NAFLD)</td>
    <td >19-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>312</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr Preety Kalra</td>
    <td >Pankaj Kumar</td>
    <td >Part Time</td>
    <td >41500073</td>
    <td >13-08-2015</td>
    <td >A MATHEMATICAL STUDY OF ROLE OF DELAY IN STABILITY AND BIFURCATION ANALYSIS IN PLANT GROWTH DYNAMICS UNDER THE EFFECT OF TOXICANTS.</td>
    <td >12-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>313</td>
    <td >Technology and Sciences</td>
    <td >Mathematics</td>
    <td >Dr. Pushpinder Singh</td>
    <td >Nitin Kumar Mishra</td>
    <td >Part Time</td>
    <td >41500094</td>
    <td >18-08-2015</td>
    <td >INVENTORY MODELS WITH TRADE CREDIT IN A FINITE PLANNING HORIZON</td>
    <td >17-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>314</td>
    <td >Technology and Sciences</td>
    <td >HORTICULTURE</td>
    <td >Dr. Senthil Kumar</td>
    <td >Lal Bahadur</td>
    <td >Part Time</td>
    <td >41500080</td>
    <td >14-08-2015</td>
    <td >STANDARDIZATION OF FERTIGATION DOZE FOR OPEN AND PROTECTED CULTIVATION OF BANANA (MUSA SPP. AAA) UNDER PUNJAB CONDITIONS</td>
    <td >13-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>315</td>
    <td >Technology and Sciences</td>
    <td >HORTICULTURE</td>
    <td >Dr Shailesh Kumar Singh</td>
    <td >Damandeep Singh</td>
    <td >Part Time</td>
    <td >41500081</td>
    <td >14-08-2015</td>
    <td >STANDARDIZATION OF FERTIGATION DOZE FOR OPEN AND PROTECTED CULTIVATION OF PAPAYA IN PUNJAB</td>
    <td >13-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>316</td>
    <td >Technology and Sciences</td>
    <td >Agronomy</td>
    <td >Dr. Madhu Sharma</td>
    <td >Paramjit</td>
    <td >Part Time</td>
    <td >41500082</td>
    <td >14-08-2015</td>
    <td >AGRONOMIC PERFORMANCE AND MINI-TUBER PRODUCTION OF POTATO VARIETIES UNDER AEROPONIC SYSTEM</td>
    <td >13-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>317</td>
    <td >Business and Arts</td>
    <td >Punjabi</td>
    <td >Dr. Avtar Singh</td>
    <td >Sandeep Singh</td>
    <td >Part Time</td>
    <td >41500038</td>
    <td >28-07-2015</td>
    <td >PUNJABI KAVITA VICH PESH MAUNKHI RISHTEYA DA SAMAAJ-MANOVIGIYANIK ADHAYAN</td>
    <td >27-07-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>318</td>
    <td >Business and Arts</td>
    <td >Hindi</td>
    <td >Dr. Vinod Kumar</td>
    <td >Prabhjot Kaur</td>
    <td >Part Time</td>
    <td >41500048</td>
    <td >03-08-2015</td>
    <td >अज्ञेय अजय शर्मा और अनीता देसाई के साहित्य का मनोविज्ञानिक चिन्तन : एक तुलनात्मक अध्ययन</td>
    <td >02-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>319</td>
    <td >Business and Arts</td>
    <td >Hindi</td>
    <td >Dr.Hardeeep Kaur</td>
    <td >Navjot Kaur</td>
    <td >Part Time</td>
    <td >41500053</td>
    <td >04-08-2015</td>
    <td >जगदीश चन्द्र के उपन्यासों का समाजशास्त्रीय अध्ययन</td>
    <td >03-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>320</td>
    <td >Business and Arts</td>
    <td >Hindi</td>
    <td >Dr.Hardeep Kaur</td>
    <td >Vimmi Jaggi</td>
    <td >Part Time</td>
    <td >41500126</td>
    <td >24-08-2015</td>
    <td >ANAMIKA KE SAHITYA MEIN ISTRI VIMARSH AUR USKA TULNATMAK ADHYAYAN</td>
    <td >23-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>321</td>
    <td >Business and Arts</td>
    <td >History</td>
    <td >Dr. Munendra Singh</td>
    <td >Taranveer Kaur</td>
    <td >Part Time</td>
    <td >41500051</td>
    <td >03-08-2015</td>
    <td >URBANISATION IN PUNJAB DURING COLONIAL PERIOD: A STUDY OF MALWA REGION (-)</td>
    <td >02-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>322</td>
    <td >Business and Arts</td>
    <td >Geography</td>
    <td >Dr. Ripudaman Singh</td>
    <td >Brij Mohan</td>
    <td >Part Time</td>
    <td >41500044</td>
    <td >01-08-2015</td>
    <td >IMPACT OF CROPPING PATTERN ON SUB-SOIL WATER AND FARM ECONOMICS IN PUNJAB: A SPATIO-TEMPORAL STUDY</td>
    <td >31-07-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>323</td>
    <td >Business and Arts</td>
    <td >Geography</td>
    <td >Dr. Ripudaman Singh</td>
    <td >Naresh Kumar</td>
    <td >Part Time</td>
    <td >41500066</td>
    <td >12-08-2015</td>
    <td >RURAL TOURISM IN PUNJAB: A GEOGRAPHICAL STUDY</td>
    <td >11-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>324</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmaceutics</td>
    <td >Dr. Sachin Kumar Singh</td>
    <td >Ankit Kumar</td>
    <td >Part Time</td>
    <td >41500133</td>
    <td >25-08-2015</td>
    <td >FORMULATION AND EVALUATION OF COLON TARGETED MINI TABLETS OF - FLUOROURACIL</td>
    <td >24-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>325</td>
    <td >Applied Medical Sciences</td>
    <td >Pharmacology</td>
    <td >Dr. Navneet Khurana</td>
    <td >Gurpreet Bawa</td>
    <td >Part Time</td>
    <td >41500067</td>
    <td >12-08-2015</td>
    <td >MODULATION OF TNF-ALPHA BY PIRFENIDOME AND PIPERINE IN OPIOID WITHDRAWAL SYNDROME</td>
    <td >11-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>326</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Mihir Mallick</td>
    <td >Komal Sharma</td>
    <td >Part Time</td>
    <td >41500057</td>
    <td >06-08-2015</td>
    <td >IMPACT OF PARENTAL ATTACHMENT ON ACADEMIC PERFORMANCE OF SENIOR SECONDARY SCHOOL STUDENTS: ROLE OF PSYCHOLOGICAL RISK ENGAGEMENT AND BUOYANCY</td>
    <td >05-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>327</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Vijay Kumar Chechi</td>
    <td >Saroj Bala</td>
    <td >Part Time</td>
    <td >41500060</td>
    <td >08-08-2015</td>
    <td >EFFECTIVENESS OF SARVA SHIKSHA ABHIYAN PRE AND POST RTE IMPLEMENTATION IN IMPROVING ACHIEVEMENT AND REDUCING DROPOUT RATE AMONG CHLIDREN OF BELOW POVERTY FAMILIES</td>
    <td >07-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>328</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Vijay Kumar Chechi</td>
    <td >Ophilia Lobo</td>
    <td >Part Time</td>
    <td >41500103</td>
    <td >18-08-2015</td>
    <td >EFFECT OF TEACHER-SELF EFFICACY FOR MORAL VALUES VALUES AMONG MIDDLE SCHOOL STUDENTS  WITH RESPECT TO THEIR CIVIC RESPONSIBILITY AND AGGRESSION</td>
    <td >17-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>329</td>
    <td >Business and Arts</td>
    <td >Education</td>
    <td >Dr. Vijay Kumar Chechi</td>
    <td >Almaas Sultana</td>
    <td >Part Time</td>
    <td >41500106</td>
    <td >19-08-2015</td>
    <td >HEDONIC WELL-BEING COPING STRATEGIES AND WORKPLACE OSTRACISM AMONG TEACHERS: INFLUENCE ON JOB PERFORMANCE AND STEREOTYPE THREAT</td>
    <td >18-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>330</td>
    <td >Business and Arts</td>
    <td >Journalism and Mass Communication</td>
    <td >Dr. Kuldeep Siwach</td>
    <td >Naval Preet Singh</td>
    <td >Part Time</td>
    <td >41500071</td>
    <td >12-08-2015</td>
    <td >ROLE OF MEDIA IN CAPACITY BUILDING AND SKILL DEVELOPMENT IN RURAL PUNJAB</td>
    <td >11-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>331</td>
    <td >Business and Arts</td>
    <td >Journalism and Mass Communication</td>
    <td >Dr. Kuldeep Siwach</td>
    <td >Hadwin Charli Durai</td>
    <td >Part Time</td>
    <td >41500118</td>
    <td >22-08-2015</td>
    <td >INFOTAINMENT PROGRAMMES IN TAMIL CHANNELS: USES AND GRATIFICATION STUDY OF AUDIENCE IN CHENNAI </td>
    <td >21-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>332</td>
    <td >Business and Arts</td>
    <td >Economics</td>
    <td >Dr. Tushinder Preet Kaur</td>
    <td >Ramanpreet Kaur</td>
    <td >Part Time</td>
    <td >41500129</td>
    <td >25-08-2015</td>
    <td >A STUDY ON EXPLORING THE RELATIONSHIP BETWEEN URBANIZATION ECONOMIC GROWTH AND ENVIRONMENT DEGRADATION WITH SPECIAL REFERENCE TO ASIAN COUNTRIES</td>
    <td >24-08-2021</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
  <tr>
    <td>333</td>
    <td >Technology and Sciences</td>
    <td >Computer Science and Engineering</td>
    <td >Dr. Babita Pandey</td>
    <td >Raj Kamal Kaur</td>
    <td >Part Time</td>
    <td >11312483</td>
    <td >11-08-2013</td>
    <td >MODEL BASED SECURITY ANALYSIS OF SAFETY CRITICAL SYSTEM</td>
    <td >10-08-2019</td>
    <td >NO</td>
    <td >NA</td>
  </tr>
 </tbody>
 
 
 </table>
		
	</div>
	<p><a class="popup-modal-dismiss" href="#">Dismiss</a></p>
</div>

	
	
	
	
	



	
	
	<div id="gotoTop" class="icon-angle-up"></div>
	<script type="text/javascript" src="//www.lpu.in/js/functions.js"></script>
	<script type="text/javascript" src="//www.lpu.in/academics/js/jquery.dataTables.min.js"></script>
	
	<script type="text/javascript">
		$(function() {
				$('#primary-menu').hover(function(){
				 $("#lpunst-form").fadeOut(500);
			}, function(){
				$("#lpunst-form").fadeIn(500);
			});
		});
		
		$(document).ready(function() {
		
		$('#example').DataTable({
			"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
		});
		
		
		
	} );
	
	$(document).ready(function(){
	var sliderHeight = $(window).height() - $("#header").height() - $("#top-bar").height() - 200;
	$('#slider').css('height',sliderHeight);
});



$(function () {
	$('.popup-modal').magnificPopup({
		type: 'inline',
		preloader: false,
		focus: '#username',
		modal: true
	});
	$(document).on('click', '.popup-modal-dismiss', function (e) {
		e.preventDefault();
		$.magnificPopup.close();
	});
});
				
	</script>
	
</body>
</html>
	

	
	