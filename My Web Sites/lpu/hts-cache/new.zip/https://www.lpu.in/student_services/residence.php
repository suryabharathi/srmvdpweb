<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>

	<title>Residential Facilities for Students - LPU</title>
	<meta name="description" content="Lovely Professional University provides best Safe and Secure residential  for students. Canteens provide excellent food service as they have delicious meal plans for students." />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="author" content="Lovely Professional University" />
	
	<!-- Stylesheets
	============================================= -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700" rel="stylesheet">
	<link rel="stylesheet" href="//www.lpu.in/css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/style.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/dark.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/animate.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/magnific-popup.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/vmap.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/responsive.css" type="text/css" />
	<link rel="stylesheet" href="//www.lpu.in/css/home-custom.css" type="text/css" />
	<script type="text/javascript" src="//www.lpu.in/js/jquery.js"></script>
	<script type="text/javascript" src="//www.lpu.in/js/plugins.js"></script>

	<style>
		.heading-block::after	{
			margin-top: 10px;
			width: 20%;
			border-top: 4px solid #F58220 !important;
		}
		.border-none:after {
			border-top: none !important;
		}
		.portfolio-overlay a.right-icon {
			margin-right: auto !important;
			right: 40% !important;
			margin-top: -50px !important;
		}
		.portfolio-3 .portfolio-item .portfolio-desc .more-link{
			display:block;
			color: #428fc9;
			text-decoration: none;
		}
		
		.portfolio-3 .portfolio-item .portfolio-image, .portfolio-3 .portfolio-item .portfolio-image a, .portfolio-3 .portfolio-item .portfolio-image img{
			width:100%; height:auto;
		}
		.portfolio-desc h5
		{
			margin-bottom:0 !important;
		}
	</style>
	  <link rel="manifest" href="/manifest.json">


<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P8ZP9K2');</script>
<!-- End Google Tag Manager -->
<!-- ===================================================== -->
<!-- Description of the code :AdWords Remarketing Tag -->
<!-- Applied Date: 06-Mar-2018 format  ( 05-Mar-2018 )  -->
<!-- Applicable for  Year: 2018 -->
<!-- Required Till: Permanent or Possible Month-Year till code is required -->
<!-- Source Agency : AdGlobal Etc -->
<!-- Contact Person : Abha  -->
<!-- ===================================================== -->
<!-- Global site tag (gtag.js) - Google AdWords: 980757795 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-980757795"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'AW-980757795');
</script>

<!-- ============ End Of Code  ============================== -->

<!-- ===================================================== -->
<!-- Description of the code :Facebook Pixel -->
<!-- Applied Date: 06-Mar-2018 format  ( 05-Mar-2018 )  -->
<!-- Applicable for  Year: 2018 -->
<!-- Required Till: Permanent or Possible Month-Year till code is required -->
<!-- Source Agency : AdGlobal Etc -->
<!-- Contact Person : Abha  -->
<!-- ===================================================== -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '1512138752380429');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=1512138752380429&ev=PageView&noscript=1"
/></noscript>
<!-- ============ End Of Code  ============================== -->

 	<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
	<script>
	  var OneSignal = window.OneSignal || [];
	  OneSignal.push(function() {
		OneSignal.init({
		  appId: "39fdbe81-037d-4888-82d6-1d2db7fb38b3",
		});
	  });
	</script>
 
</head>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Top Bar
		============================================= -->
		<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P8ZP9K2"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<style>
/*#top-bar {
    margin-top: 0 !important;
}*/
#header.sticky-header #header-wrap{
	top:0 !important;
}
#page-menu.sticky-page-menu #page-menu-wrap, .main-nav-scrolled{
	top:60px !important;
}


/*Hello Bar Start*/

.lpu-hello-bar{background-color:#fccb92 ; color:#000000; padding:9px 10px; text-align:center; }
.font18{font-size:18px;}
.section-mt40{margin-top:40px !important;} <!--for landing page -->
.font15b{font-size:16px;font-weight:bold !important;}
@media(max-width:430px){.font18{font-size:16px;}
.font15b{font-size:14px;font-weight:bold !important;}}
@media(max-width:800px)
{.lpu-hello-bar{position:static !important;}#top-bar{margin-top:0;}
.section-mt40{margin-top:0 !important;} <!--for landing page -->
}
</style>

<script type="text/javascript">
$( document ).ready(function() {
			var lastdate, today, bday, diff, days;
			lastdate = [15,7,2018]; 
			today = new Date($('#getdate').val());
			bday = new Date(lastdate[2],lastdate[1]-1,lastdate[0]);
			
			diff = bday.getTime()-today.getTime();
			days = Math.floor(diff/(1000*60*60*24));
			
			if(parseInt(days)>0){
				var count=parseInt(days)+1;
				if(count==1)
				{
					$('#nest-last-date').html("Last <strong>"+count +" days</strong>   left to apply for admission with  scholarship. Last Date: 15th July 2018. ");	
				}
				else{
					$('#nest-last-date').html("Last <strong>"+count +" days</strong> left to apply for admission with  scholarship. Last Date: 15th July 2018.");	
				}
			}
			else if(parseInt(days)==0)
			{
				$('#nest-last-date').html("Last day left to apply for admission with  scholarship. Last Date: 15th July 2018. ");
			}
			else
			{
				$('#nest-last-date').html('Applications invited for LPUNEST (Ph.D.) 2018-19 Spring Term. ');
			}
	});
     	
          
    </script>
<div class="lpu-hello-bar" id="lpu-bar">



	<div class="font-f" id="topbartext">
		<i class="icon icon-bullhorn" aria-hidden="true"></i>
		 Applications invited for Admission-2019. <b class="font15b">
			<a data-link="hellobar-lpunest" data-href="//nest.lpu.in/main.aspx" target="_blank" class="applylnk hide-on-lp" style="color:#000000 !important;">
			Apply Now.</a> </b>
		<br>
		  <input type='hidden' id='getdate' value="" />
	</div>

<!--
<div id="oc-posts-top-bar" class="owl-carousel posts-carousel">	
 <div class="oc-item">
	<div class="font-f" id="topbartext">
		<i class="icon icon-bullhorn" aria-hidden="true"></i>
		<span id="nest-last-date"></span> Results of Transforming Education Awards is declared.  <b class="font15b">
			<a data-link="hellobar-lpunest" data-href="https://www.lpu.in/educationawards/account/login" target="_blank" class="applylnk hide-on-lp" style="color:#000000 !important;">
			Click here.</a></b>
		<br>
		  <input type='hidden' id='getdate' value="" />
</div>
</div>	
	
	
	 <div class="oc-item">
	<div class="font-f" id="topbartext">
		<i class="icon icon-bullhorn" aria-hidden="true"></i>
		<span id="nest-last-date"></span>Nominations for Transforming Education Awards 2019 is open.  <b class="font15b">
			<a class="hide-on-lp" href="https://www.lpu.in/educationawards"  style="color:#000000 !important;" target="_blank"> Nominate Now.</a> </b>
		<br>
		  <input type='hidden' id='getdate' value="" />
	</div>
	</div>
	
	
	
		 <div class="oc-item">
	<div class="font-f" id="topbartext">
		<i class="icon icon-bullhorn" aria-hidden="true"></i>
		<span id="nest-last-date"></span>  Applications invited for LPUNEST-2019. <b class="font15b">
			<a data-link="hellobar-lpunest" data-href="//nest.lpu.in/main.aspx" target="_blank" class="applylnk hide-on-lp" style="color:#000000 !important;">
			Apply Now.</a> </b>
		<br>
		  <input type='hidden' id='getdate' value="" />
	</div>
	</div>		
	
	
	
	
	
	</div>-->
	
		
	</div>
	

<!-- Hello Bar End-->

<div id="top-bar" class="ps-top-bar slider-top-link">
			<div class="container-fluid clearfix">
				<div class="col_half nobottommargin mr0">
					<div class="top-links dark">
						<ul>
            <li class="hidden-xs hidden-xxs hidden-sm hidden-md"><a href="https://ums.lpu.in/lpuums" target="_blank">Parent's Login</a></li>
            <li class="hidden-xs hidden-xxs hidden-sm hidden-md"><a href="https://ums.lpu.in/lpuums" target="_blank">UMS</a></li>
			<li class="hidden-xs hidden-xxs hidden-sm hidden-md"><a href="//www.lpu.in/jobs/">Jobs</a></li>
            <!--<li class="hidden-xs hidden-xxs hidden-sm"><a href="//www.lpu.in/about_lpu/tour_lpu.php">Campus Visit</a></li> -->
		
			<li class="hidden-xs hidden-xxs hidden-sm"><a href="http://happenings.lpu.in/" target="_blank">Happenings</a></li>
			<li class="hidden-xs hidden-xxs hidden-sm"><a href="https://www.lpu.in/disha/" target="_blank"> Career Guidance </a> </li>
			<li class="hidden-xs hidden-xxs hidden-sm"><a href="//conferences.lpu.in/" target="_blank"> Conferences </a> </li>
				<li ><a href="//www.lpu.in/studygrant" target="_blank" >Study Grant</a></li>
			<li ><a data-link="topbar-lpunest" data-href="//nest.lpu.in/main.aspx" target="_blank" class="nest-result applylnk">LPUNEST</a></li>
			<!--<li class="hidden-xs hidden-xxs hidden-sm"><a href="//nest.lpu.in/main.aspx" target="_blank" >LPUNEST</a></li>-->
			<li class="hidden-xs hidden-xxs hidden-sm"><a href="//admission.lpu.in/">Result </a></li>
			<li class="hidden-xs hidden-xxs hidden-sm"><a href="//www.lpu.in/international/" target="_blank">International Admissions </a></li>
			<li ><a href="//www.lpu.in/contact_us/contact-us.php">Contact Us</a></li>     
		    

			<!--<li><a id="educationawards" href="#" data-toggle="modal" data-target="#myLargeModal">Education Awards</a></li>			 -->
          </ul>
					</div>
				</div>
				<div class="col_half fright nobottommargin mr0 top-ts">				
					<div id="top-social">
						<ul>
						   <li class="d-one"><a  data-toggle="tooltip" data-placement="bottom" title="" href="https://api.whatsapp.com/send?phone=+91-9876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202018." target="_blank" class="si-whatsapp"><span class="ts-icon"><i style="font-size: 14px; font-weight: bold; padding-top: 11px;" class="fa fa-whatsapp"></i></span></a></li>
							<li><a href="https://www.facebook.com/LPUUniversity" target="_blank" class="si-facebook"><span class="ts-icon"><i class="icon-facebook"></i></span></a></li>
							<li><a href="https://twitter.com/lpuuniversity" target="_blank" class="si-twitter"><span class="ts-icon"><i class="icon-twitter"></i></span></a></li>
							<li><a href="https://plus.google.com/u/0/102445329734305802454/posts" target="_blank" class="si-gplus"><span class="ts-icon"><i class="icon-gplus"></i></span></a></li>
							<li><a href="https://www.linkedin.com/company/lovely-professional-university" target="_blank" class="si-linkedin"><span class="ts-icon"><i class="icon-linkedin"></i></span></a></li>
							<li><a href="https://www.youtube.com/user/LPUuniversity" target="_blank" class="si-youtube"><span class="ts-icon"><i class="icon-youtube"></i></span></a></li>
							<li><a href="" class="si-call ppwnd"><span class="ts-icon"><i class="icon-call"></i></span></a></li>
							<li><a href="mailto:admissions@lpu.co.in" class="si-email3"><span class="ts-icon"><i class="icon-email3"></i></span></a></li>
							 <li><a href="//www.lpu.in/about_lpu/tour_lpu.php" target="_blank" class="si-call"><span class="ts-icon"><i class="icon-globe"></i></span><span class="ts-text">360<sup>0</sup> View</span></a>
							</li>
						  </ul>
					</div>
				</div>
			</div>
		</div>
		
		<script type="text/javascript">

						$(document).ready(function() {
							 $("#oc-posts-top-bar").owlCarousel({
								margin: 20,
								autoplayTimeout:5000,								
								loop:true,
								nav: false,
								navText: ['<i class="icon-angle-left"></i>','<i class="icon-angle-right"></i>'],
								autoplay: true,
								autoplayHoverPause: true,
								dots: false,
								responsive:{
									0:{ items:1 },
									600:{ items:1 },
									1000:{ items:1 },
									1200:{ items:1 }
								}
							});

						});

					</script>
					
								
				<!-- Header
		============================================= -->
		
<header id="header" class="full-header ps-header" data-responsive-class="not-dark">
	<div id="header-wrap">
		<div class="container clearfix">
			<div id="primary-menu-trigger"><i class="icon-reorder"></i>
			</div>
			<div id="logo">
				<a href="//www.lpu.in/" class="standard-logo" data-sticky-logo="//www.lpu.in/images/logo/logo-media.png" data-dark-logo="//www.lpu.in/images/logo/logo-dark.png" data-mobile-logo="//www.lpu.in/images/logo/logo-media.png"><img src="//www.lpu.in/images/logo/logo.png"  alt="LPU Logo" width="auto" height="auto" /></a>
				<a href="//www.lpu.in/" class="retina-logo" data-sticky-logo="//www.lpu.in/images/logo/logo-media@2x.png" data-dark-logo="//www.lpu.in/images/logo/logo-dark.png" data-mobile-logo="//www.lpu.in/images/logo/logo-media@2x.png"><img width="auto" height="auto" src="//www.lpu.in/images/logo/logo-media@2x.png"  alt="LPU Logo"></a>
			</div>
			<nav id="primary-menu">
				<ul>
					<li>
						<a href="#">
							<div>About</div>
						</a>
						<div class="mega-menu-content style-2 clearfix" style="padding:0 !important">
							<ul>

								<li class="mega-menu-title">
									<a>
										<div>Get Started</div>
									</a>
									<div class="col-xs-12 mb0 pl0 pr0">
										<ul>
											<li>
												<a href="//www.lpu.in/about_lpu/infrastructure.php">
													<div>Infrastructure</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/about_lpu/accreditation.php">
													<div>Accreditation and Tie Ups</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/about_lpu/ranking.php">
													<div>Ranking</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/placements.php">
													<div>Placements</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/about_lpu/alumni.php">
													<div>Alumni</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/about_lpu/leadership.php">
													<div>Leadership</div>
												</a>
											</li>
											<li><a href="//www.lpu.in/about_lpu/vision-mission.php">
												<div>Vision and Mission</div>
												</a></li>
											<li>
												<a href="//www.lpu.in/admission/lpu-in-your-town.php#lpu-town">
													<div>Location</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/about_lpu/tour_lpu.php">
													<div>Tour LPU</div>
												</a>
											</li>
										</ul>
									</div>
								</li>
							</ul>
						</div>
					</li>
					<li class="mega-menu sub-menu">
						<a href="#">
							<div style="border-bottom:2px solid #F68121;"> Admissions</div>
						</a>
						<div class="mega-menu-content style-2 clearfix col-4" style="padding:0 !important">
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Get Started</div>
									</a>
									<ul>

										<li>
											<a href="//www.lpu.in/admission/admissions.php">
												<div>Overview</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/ProgramSearch.php#Apply">
												<div>How To Apply?</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/scholarship/scholarship.php">
												<div>Scholarship</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/admission/lpu-in-your-town.php#lpu-town">
												<div>LPU in Your Town</div>
											</a>
										</li>
									
										<li>
											<a href="//www.lpu.in/admission/career_assessment.php">
												<div>Career Assessment</div>
											</a>
										</li>
										<li>										
										<a href="//www.lpu.in/events/freshmeninduction/index.php"><div>Reporting and Induction </div></a>
										</li><li>										
										<a target="_blank"  href="//www.lpu.in/international/"><div>International Applicants</div></a>
										</li>
										
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Programmes By Qualification</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/programmes/all/10th">
												<div>After 10th <small> (Diploma Programmes)</small></div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/all/12th">
												<div>After 12th  <small> (Under Graduation Programmes)</small></div>
											</a>
										</li>
										
										<li>
											<a href="//www.lpu.in/programmes/all/Graduation">
												<div>After Graduation <small> (Master Programmes)</small></div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/all/Post Graduation">
												<div>After Post Graduation</div>
											</a>
										</li>
										<li><a href="//nest.lpu.in/phd/">
										  <div>Doctoral Programmes</div>
										  </a></li>
										  
										  <!--<li><a href="//www.lpu.in/after-doctoral-programmes/index.php">
										  <div>After Doctoral Programmes</div>
										  </a></li> -->
										  
										  
										  <li>
											<a href="//www.lpu.in/programmes/all/Diploma or Certificate">
												<div>After Diploma or Certificate</div>
												
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/all">
												<div>All Programmes</div>
											</a>
										</li>
										
										<!--<li>
											<a href="//www.lpu.in/programmes/ProgramSearch.php">
												<div>Programme Search</div>
											</a>
										</li>-->
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Programmes by type</div>
									</a>
									<ul>
										
										<li>
											<a href="//www.lpu.in/programmes/regular">
												<div>Standard or Regular Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/lateral">
												<div>Lateral Entry Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/admission/integrated-bachelors-masters-programmes.php">
												<div>Integrated Bachelors-Masters Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/admission/honours-programmes-options.php">
												<div>Honours Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/admission/dual-degree-programmes-options.php">
												<div>Dual Degree Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/programmes/parttime">
												<div>Part Time Programmes</div>
											</a>
										</li>
										
										 <li><a href="//www.lpu.in/admission/short-term-courses.php">
										  <div>Short Term Courses</div>
										  </a></li>	
										  <li>
											<a href="//www.lpu.in/engineering/" target="_blank">
												<div>Top Engineering Courses (B.Tech - M.Tech)</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>International Applicants</div>
									</a>
									<ul>

									<li><a  target="_blank"  href="//www.lpu.in/international"><div>Overview</div></a></li>
									 <li><a target="_blank" href="//www.lpu.in/international/programmes/ProgramSearch.php"><div>Programme Offered</div></a> </li>
									 <li><a target="_blank"  href="//www.lpu.in/international/english-language-requirement.php"><div>English Language Requirement</div></a> </li>
								  <li><a target="_blank"  href="//www.lpu.in/international/scholarship.php"><div>Scholarship</div></a> </li>
								  <li><a  target="_blank" href="//www.lpu.in/international/how_to_apply.php"><div>How to Apply</div></a> </li>
																		
									</ul>
								</li>
							</ul>
						</div>
					</li>
					
					
					
					
					<li class="mega-menu sub-menu hide">
						<a href="#">
							<div>International</div>
						</a>
						<div class="mega-menu-content style-2 clearfix col-4" style="padding:0 !important">
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Get Started</div>
									</a>
									<ul>

										<li>
											<a href="//www.lpu.in/international/how_to_apply.php">
												<div>How to Apply</div>
											</a>
										</li>
										<li>
											<a href="//admission.lpu.in">
												<div>Apply Online</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/how_to_pay.php">
												<div>How to Pay</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/scholarship.php">
												<div>Schlorship</div>
											</a>
										</li>
									
										<li>
											<a href="//www.lpu.in/international/booklet_and_forms.php">
												<div>Admission Guidelines</div>
											</a>
										</li>
																				
											<li>
											<a href="//www.lpu.in/OnlineAdmission/LetterAuthentication.aspx">
												<div>Admission Authetication</div>
											</a>
										</li>
										
											<li>
											<a href="//www.lpu.in/international/english-language-requirement.php">
												<div>English Language Requirement</div>
											</a>
										</li>
										
										<li>
											<a href="//www.lpu.in/international/across_globe.php">
												<div>Our Global Representatives</div>
											</a>
										</li>
										
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Programme Offered</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/international/programmes/all/Grade 10th (O Level)">
												<div>Diploma (after O level)</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/programmes/all/Grade 12th (A Level)">
												<div>Under Graduate (after A level)</div>
											</a>
										</li>
										
										<li>
											<a href="//www.lpu.in/international/programmes/all/Graduation">
												<div>Post Graduate (after Graduation)</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/programmes/all/Graduation">
												<div>Doctoral (after Post Graduation)</div>
											</a>
										</li>
										<li><a href="//www.lpu.in/international/english-language-programme.php">
										  <div>English Language Programmes</div>
										  </a></li>
										  <li>
											<a href="//www.lpu.in/international/study_india_programme.php">
												<div>Study India Programmes</div>
												
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/study_abroad_programme.php">
												<div>Term Exchange Programmes</div>
											</a>
										</li>
										
										<!--<li>
											<a href="//www.lpu.in/programmes/ProgramSearch.php">
												<div>Programme Search</div>
											</a>
										</li>-->
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Summer School Programme</div>
									</a>
									<ul>
										
										<li>
											<a href="//www.lpu.in/international/summer_school/index.php">
												<div>International Summer School Programmes</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_eligibility.php">
												<div>Eligibility</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_accommodation_and_facilities.php">
												<div>Accomodation and Other Facilities</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_registeration_and_fee_structure.php">
												<div>Registration and Fee Structure</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_proposed_schedule.php">
												<div>Schedule and Details</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/international/summer_school/int_visa_requirement_and_guidelines.php">
												<div>Visa Requirement and Guidelines</div>
											</a>
										</li>
										
										 <li><a href="//www.lpu.in/international/summer_school/int_gallery.php">
										  <div>Gallary</div>
										  </a></li>	
										  
										   <li><a href="//www.lpu.in/international/summer_school/int_faq.php">
										  <div>FAQ's</div>
										  </a></li>	
										  
										     <li><a href="//www.lpu.in/international/summer_school/int_contact.php">
										  <div>Contact Us</div>
										  </a></li>	
										  
										  
										  
										  
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Student Support and FAQs</div>
									</a>
									<ul>

									<li><a  target="_blank"  href="//www.lpu.in/international/pre_arrival.php"><div>Pre Arrival Information</div></a></li>
									 <li><a target="_blank" href="//www.lpu.in/international/post_arrival.php"><div>Post Arrival Information</div></a> </li>
									 <li><a target="_blank"  href="//www.lpu.in/international/after_you_graduate.php"><div>After You Graduate</div></a> </li>
								  <li><a target="_blank"  href="//www.lpu.in/international/returning_back.php"><div>Returning Back Home</div></a> </li>
								  <li><a  target="_blank" href="//www.lpu.in/international/international_student_experience.php"><div>Students Testimonials</div></a> </li>
								   <li><a  target="_blank" href="//www.lpu.in/international/general-faq.php"><div>Joining Related FAQs</div></a> </li>
									<li><a  target="_blank" href="//www.lpu.in/international/admission_related_faqs.php"><div>Admission Related FAQs</div></a> </li>
								  <li><a  target="_blank" href="//www.lpu.in/international/visa-frro-faq.php"><div>VISA/FRRO Related FAQs</div></a> </li>
								   <li><a  target="_blank" href="//www.lpu.in/international/general_information_related_to_visa.php"><div>Visa Requirement and Guidelines</div></a> </li>
								   <li><a  target="_blank" href="//www.lpu.in/international/visa_extensions.php"><div>Visa Extensions</div></a> </li>
																		
									</ul>
								</li>
							</ul>
						</div>
					</li>
					
					<li class="mega-menu">
						<a href="#">
							<div>Academics</div>
						</a>
						<div class="mega-menu-content col-3 style-2 clearfix">
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>How We Teach</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/academics/live-projects.php">
												<div>Live projects</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/industry-immersion.php">
												<div>Industry Immersion</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/Interdisciplinary-minors.php">
												<div>Interdisciplinary Minors</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/curriculum-innovations.php">
												<div>Curriculum innovations</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/guest-lectures.php">
												<div>Guest lectures / Workshops</div>
											</a>
										</li>

										<li>
											<a href="//www.lpu.in/academics/assessment-and-evaluation.php">
												<div>Assessment and Evaluation</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/mentoring-advising.php">
												<div>Mentoring and advising</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Highlights</div>
									</a>
									<ul>
										<li>
											<a href="//www.lpu.in/academics/research.php">
												<div>Research @ LPU</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/faculty-development.php">
												<div>Human Resource Development Center</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/placements.php">
												<div>Placements</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/libraries-laboratories.php">
												<div>Libraries and Laboratories</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/calendar_regular_programmes.php">
												<div>Academic Calendar</div>
											</a>
										</li>
										<li>
											<a href="//www.lpu.in/academics/holiday-list.php">
												<div>Holiday List</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Disciplines / Departments </div>
									</a>
									<div>
										<ul>
											<li><a href="#disciplines-popup" data-lightbox="inline" class="mb0">LPU has 45+ disciplines / departments  for your career path.<br><br><div class="pull-right mt-20">View All</div></a>
											</li>
											
										</ul>
									</div>
								</li>
							</ul>
						</div>
					</li>
				
				<li>
						<a href="//www.lpu.in/placements.php">
							<div>Placements</div>
						</a>
						<!-- <div class="mega-menu-content style-2 clearfix" style="padding:0 !important">
               <ul>
              <li class="mega-menu-title"><a>
                  <div>Campus Placement</div>
                  </a>
              <div class="col-xs-12 mb0 pl0 pr0">
               <ul>
                  <li><a href="#">
                    <div>Link 1</div>
                    </a></li>
					 <li><a href="#">
                    <div>Link 2</div>
                    </a></li>
					 <li><a href="#">
                    <div>Link 3</div>
                    </a></li>
					 <li><a href="#">
                    <div>Link 4</div>
                    </a></li>
					 <li><a href="#">
                    <div>Link 5</div>
                    </a></li>
                    <li><a href="#">
                    <div>Link 6</div>
                    </a></li>
                  </ul>
              </div>
              </li>
              </ul>
            </div>-->
					</li>
			

			
			
			
			
			

			<li class="mega-menu">
						<a href="#">
							<div>Campus Life</div>
						</a>
						
						<div class="mega-menu-content col-2 style-2 clearfix">
						
							
							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Campus Life</div>
									</a>
									
									<div class="col-md-12 mb0 pl0 pr0">
									<div class="col-md-6 ma0 pa0"><ul>
											<li>
												<a href="//www.lpu.in/campus_life/entrepreneurship.php">
													<div>Entrepreneurship</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/sports.php">
													<div>Sports</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/art-and-culture.php">
													<div>Art and Culture</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/campus-events.php">
													<div>Campus Events</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/student-organisations.php">
													<div>Student Organizations</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/community-services.php">
													<div>Community Service</div>
												</a>
											</li>
										</ul>
									</div>
									<div class="col-md-6 ma0 pa0"><ul>
											
											<li>
												<a href="//www.lpu.in/campus_life/visitors.php">
													<div>Visitors</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/diversity.php">
													<div>Diversity</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/on-campus-jobs.php">
													<div>On Campus Jobs</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/campus_life/fun-zone.php">
													<div>Fun Zone</div>
												</a>
											</li>
											
										</ul>
									</div>
										
									</div>
								
								
								</li>
							</ul>
						

							<ul>
								<li class="mega-menu-title">
									<a>
										<div>Student Services</div>
									</a>
									
									<div class="col-md-12 mb0 pl0 pr0">
									<div class="col-md-6 ma0 pa0"><ul>
											<li>
												<a href="//www.lpu.in/student_services/security.php">
													<div>Campus Security</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/healthcare.php">
													<div>Uni Hospital</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/ums.php">
													<div>University Management System</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/residence.php">
													<div>Residential Facilities</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/transport.php">
													<div>Transportation Facilities</div>
												</a>
											</li>
										</ul>
									</div>
									<div class="col-md-6 ma0 pa0"><ul>
											
											<li>
												<a href="//www.lpu.in/student_services/shopping-dining.php">
													<div>Shopping and Dining</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/banking-postal-services.php">
													<div>Banking and Postal Services</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/student_services/education-loan-assistance.php">
													<div>Education Loan Assistance</div>
												</a>
											</li>
											<li>
												<a href="//www.lpu.in/placements.php">
													<div>Placements</div>
												</a>
											</li>
											<li>
												<a href="http://startupschool.lpu.in/" target="_blank">
													<div>Startup School</div>
												</a>
											</li>
										</ul>
									</div>
										
									</div>
								
								
								</li>
							</ul>
						
						</div>
					
						
						
				</li>

				<li class="mega-menu">
						<a href="#">
							<div>Schools</div>
						</a>
						<div class="mega-menu-content col-3 style-2 clearfix">
							<ul>
								<li class="mega-menu-title">
									
									<ul>
										<li>
											<a href="//schools.lpu.in/business/" target="_blank">
												<div>Business</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/computer-science-engineering/" target="_blank">
												<div>Computer Science and Engineering</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/mechanical-engineering/" target="_blank">
												<div>Mechanical Engineering</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/civil-engineering/" target="_blank">
												<div>Civil Engineering</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">
												<div>Electronics and Electrical Engineering</div>
											</a>
										</li>
										
																				<li>
											<a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">
												<div>Bioengineering and Biosciences</div>
											</a>
										</li>
												
										<li>
											<a href="//schools.lpu.in/architecture-design/" target="_blank">
												<div>Architecture and Design</div>
											</a>
										</li>
										
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									
									<ul>
										<li>
											<a href="//schools.lpu.in/hotel-management-and-tourism/" target="_blank">
												<div>Hotel Management and Tourism</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/computer-applications/" target="_blank">
												<div>Computer Application</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/pharmaceutical-sciences" target="_blank">
												<div>Pharmaceutical Sciences</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/agriculture/" target="_blank">
												<div>Agriculture</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/fashion-design/" target="_blank">
												<div>Design</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/journalism-film-production/" target="_blank">
												<div>Journalism, Films And Creative Arts</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/physical-sciences/" target="_blank">
												<div>Chemical Engineering And Physical Sciences</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							<ul>
								<li class="mega-menu-title">
									
									<ul>
										<li>
											<a href="//schools.lpu.in/law/" target="_blank">
												<div>Law</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/polytechnic/" target="_blank">
												<div>Polytechnic</div>
											</a>
										</li>
										
										<li>
											<a href="//schools.lpu.in/physiotherapy-and-paramedical-sciences/" target="_blank">
												<div>Physiotherapy and Paramedical Sciences</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/education/" target="_blank">
												<div>Education</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/physical-education/" target="_blank">
												<div>Physical Education</div>
											</a>
										</li>
										<li>
											<a href="//schools.lpu.in/social-sciences/" target="_blank">
												<div>Social Sciences and Languages</div>
											</a>
										</li>
									</ul>
								</li>
							</ul>
							
						</div>
					</li>
				
				
				<li class="scroll-menu"><a href="https://nest.lpu.in/" target="_blank"><div>Apply Now</div></a></li>
				<!--<li class="scroll-menu"><a href="http://www.lpu.in/contact_us/contact-us.php" target="_blank"><div>Enquire Now</div></a></li>-->
				</ul>
				<div id="top-search">
					<a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
					<form action="//www.lpu.in/result.php" name="form2" id="form2">
						<input type="hidden" name="cx" value="partner-pub-016589675364233558975:gl7zrlhae3u"/>
						<input type="hidden" name="cof" value="FORID:11"/>
						<input type="hidden" name="ie" value="ISO-8859-1"/>
						<input type="text" name="q" onclick="make_blank();" class="form-control" placeholder="Type &amp; Hit Enter.."/>
					</form>
				</div>
			</nav>
		</div>
	</div>
</header>		<!-- #header end -->
		
		<!-- Page Title
		============================================= -->
		
		<div id="page-menu" class="">

			<div id="page-menu-wrap">

				<div class="container clearfix">

					<div class="menu-title"> <span>Residential Facilities</span> </div>

				</div>

			</div>

		</div>
		
		<div class="clearfix"></div>
		
			<section id="slider" style="background-image: url('images/residence/top/top.jpg'); background-size: cover; background-position: center center;">
			<div class="container clearfix">
				<div class="vertical-middle">
							<div class="caption-bg text-center">
								<h1>Largest Residential Capacity in the World</h1>
							</div>
					</div>
			</div>			
					<div class="video-overlay" style="background-color: rgba(0,0,0,0.6);"></div>
		</section>
		
			
	
		

<!-- Content place here
		============================================= -->

		<div class="clearfix"></div>
		
		
		<div class="section notopmargin mb0 pt30 pb20">
			<div class="container clearfix">
				
				<div class="heading-block center mb0 border-none">
					<h2>City in a Campus</h2>
					<span>All the facilities of the city - in one campus!</span>
				</div>
				
				<div class="col-md-12 pa0 mt20 grid-innr">
					<div class="col-sm-6 col-xs-12 pad">
						<div class="fslider" data-animation="fade" data-thumbs="true" data-arrows="false" data-speed="1200" data-pause="7000">
							<div class="flexslider">
								<div class="slider-wrap">
									<div class="slide" data-thumb="images/security/flexslider/boxed/thumbs/2.jpg">
										<a href="#">
											<img width="auto" height="auto" class="lazy" data-lazyload="images/security/flexslider/boxed/2.jpg" alt="LPU security">
											<!--<div class="flex-caption slider-caption-bg">Responsive Ready Design</div>-->
										</a>
									</div>
									<div class="slide" data-thumb="images/security/flexslider/boxed/thumbs/3.jpg">
										<a href="#">
											<img width="auto" height="auto" class="lazy" data-lazyload="images/security/flexslider/boxed/3.jpg" alt="LPU security">
											<!--<div class="flex-caption slider-caption-bg slider-caption-bg-light slider-caption-top-left">Retina Graphics Display</div>-->
										</a>
									</div>
									<div class="slide" data-thumb="images/security/flexslider/boxed/thumbs/4.jpg">
										<a href="#">
											<img width="auto" height="auto" class="lazy" data-lazyload="images/security/flexslider/boxed/4.jpg" alt="LPU security">
											<!--<div class="flex-caption slider-caption-bg slider-caption-top-right">Bootstrap 3+ Compatible</div>-->
										</a>
									</div>
									<div class="slide" data-thumb="images/security/flexslider/boxed/thumbs/5.jpg">
										<a href="#">
											<img width="auto" height="auto" class="lazy" data-lazyload="images/security/flexslider/boxed/5.jpg" alt="LPU security">
											<!--<div class="flex-caption slider-caption-bg slider-caption-bg-light slider-caption-bottom-right">eCommerce Design Included</div>-->
										</a>
									</div>
									<div class="slide" data-thumb="images/security/flexslider/boxed/thumbs/6.jpg">
										<a href="#">
											<img width="auto" height="auto" class="lazy" data-lazyload="images/security/flexslider/boxed/6.jpg" alt="LPU security">
											<!--<div class="flex-caption slider-caption-bg">eCommerce Design Included</div>-->
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="col-md-6">

						<div class="heading-block topmargin-sm">
							<h3>Safe and secure residential facility for boys and girls</h3>
						</div>

						<div class="col-md-12 pa0 pb15">
							<p class="lead">The university is committed to zero tolerance to ragging, alcohol, smoking, drugs and disciplinary misconduct. Automated turnstile gates with biometric machines regulate entry & exit to residential facility.</p>
							
							<button class="btn btn-default btn-xs mb5 mr5" data-toggle="modal" data-target="#residential-fee">Fee Details</button>
							<button class="btn btn-default btn-xs mb5 mr5" data-toggle="modal" data-target="#residential-facilities">Salient Features</button>
							<button class="btn btn-default btn-xs mb5 mr5" data-toggle="modal" data-target="#important-points">Important Points</button>
						</div>
						
					</div>
					
				</div>
			</div>
		</div>

		
		<div class="modal fade bs-example-modal-lg" id="important-points" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-body">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">Important Points for Residential Facility</h4>
					</div>
					<div class="modal-body pb20" style="height: 450px;overflow-y: scroll; text-transform: none;">
					<ul class="iconlist iconlist-color">
						 <li><i class="icon-ok"></i>Residential facility is permitted on annual basis for students admitted for regular programmes for the duration of regular academic session.</li>
						<li><i class="icon-ok"></i>All rights of permission to avail the Residential facility are reserved with the University and can be denied to any student. No student shall be entitled to claim this facility as a matter of right.</li>
						<li><i class="icon-ok"></i>Residential facility will be offered on First Come First Serve basis, with the provision for reservation for special category of student(s) such as those admitted for residential or specific programme or admitted in Hons. programme or from the distant places or on the basis of academic/ sports/ cultural/ co-curricular or other performances or as decided otherwise by the University.</li>
						<li><i class="icon-ok"></i>The location of the Residential facility, floor and room pattern are subject to change from time to time.</li>
						<li><i class="icon-ok"></i>Residential facility will be provided till the end of the regular academic session including regular exams or 10 months from the start of session, whichever is earlier. Students can come and join two days prior to start of academic session and will be required to vacate Residential room/ apartment within two days after regular exams. For availing Residential facility after the end of academic session for any purpose like summer school/ reappear examination/ make up examination/ PEP/ EEP classes etc., additional proportionate residential fee (residence) will have to be paid by the student, subject to the availability and permission of Residential Services.</li>
						<li><i class="icon-ok"></i>Customized plan (e.g. for full calendar year) may be provided on request.</li>
						<li><i class="icon-ok"></i>Residential fee (Residence) is for the academic session 2019-20 and is subject to change for successive sessions.</li>
						<li><i class="icon-ok"></i>Unless otherwise specified, Residential facility(s) once chosen like Air-Conditioned facility etc. will not be changed during the academic session.</li>
						<li><i class="icon-ok"></i>Residential fee (Residence) includes the fee for accommodation (boarding and lodging), geyser, cooler or AC (as opted), and electricity (free units as mentioned in the fee table), generator and maintenance cost for light load.</li>
						<li><i class="icon-ok"></i>Electricity used in excess of light load permissible by the university will be charged on actual basis. In case of shared room or apartment i.e. 2, 3, 4 seater etc. usages of electricity units will be calculated on per room basis and shared equally among all the occupants of the room.</li>
						<li><i class="icon-ok"></i>The reading of electricity meter noted on the day prior to reporting date of the first student in the allotted room in residential facility of the university, shall be considered as the initial reading for all the subsequent students allotted the same room.</li>
						<li><i class="icon-ok"></i>For Refund of fee, refer to ‘Refund Policy for Indian Applicants’ mentioned in Part-C of Prospectus 2019.</li>	
					</ul>	
					</div>
				</div>
			</div>
		</div>
	</div>
	
	
	<div class="modal fade bs-example-modal-lg" id="residential-facilities" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-body">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">Residential Facilities</h4>
					</div>
					<div class="modal-body pb20 " style="height: 450px;overflow-y: scroll; text-transform: none;">
					<ul class="iconlist iconlist-color">
						 <li><i class="icon-ok"></i>Separate residential facility for boys and girls within the campus.</li>
						 <li><i class="icon-ok"></i>Rooms with attached washroom (except in certain dormitory rooms), bed (without mattress), table, chair and almirahs.</li>
						<li><i class="icon-ok"></i>Air cooler / Air Conditioner facility in each room (as opted).</li>
						<li><i class="icon-ok"></i>Arrangement for power supply through dedicated 24 hours hotlines.</li>
						<li><i class="icon-ok"></i>Geyser in each room to provide hot water in winters (scheduled timings) for two hours per room every day or as decided by the University.</li>
						<li><i class="icon-ok"></i>In campus Hospital with ambulance to provide medical assistance to students.</li>
						<li><i class="icon-ok"></i>Internet connectivity through Wi-Fi system for scheduled timing for academic purposes only and subject to conditions.</li>
						<li><i class="icon-ok"></i>Power backup for light load only (not for AC/ Geyser/ Air cooler).</li>
						<li><i class="icon-ok"></i>Mess facility with vegetarian meals only.</li>
						<li><i class="icon-ok"></i>Parking two wheeler/car facility at designated places only.</li>
						<li><i class="icon-ok"></i>Gymnasium (optional on payment basis).</li>
						<li><i class="icon-ok"></i>Students in residential facility are permitted to keep Electrical Kettles, Electrical Irons, Steamer, Laptop, Mobile Charger, Shaving Set, Trimmer, Hair Straightener and Hair Dryer. Extra electricity bill due to the usage of these electrical items will be borne by the occupants of that room.	</li>
					</ul>	
					</div>
				</div>
			</div>
		</div>
	</div>
		
		
		
    <div class="modal fade bs-example-modal-lg" id="residential-fee" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
		
			<div class="modal-body">			
			
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">Fee (in &#8377) for Residential facility for Academic session 2019-20</h4>
					</div>
					
					
					
					
					
					<div class="modal-body pb20 " style="height: 450px;overflow-y: scroll; text-transform: none;">
						
						<div class="tabs clearfix pt30" id="tab-1">
						
						

							<ul class="tab-nav clearfix">
								<li><a href="#tabs-1">Standard Rooms</a></li>
								<li><a href="#tabs-2">Apartments</a></li>
								<li><a href="#tabs-3">Dormitory</a></li>
								
							</ul>

							<div class="tab-container">

								<div class="tab-content clearfix" id="tabs-1">
								
								<h4 class="pb0 pt20 ma0">Standard Rooms</h4><br>
							  The following facilities are available in Standard hostel rooms:-
<ul class="iconlist iconlist-color">
								<li><i class="icon-ok"></i> Air Conditioner/ Air Cooler  in each room</li>
								<li><i class="icon-ok"></i> Attached washroom in each room</li>
								<li><i class="icon-ok"></i> Geyser in each room</li>
								<li><i class="icon-ok"></i> Iron Bed</li>
								<li><i class="icon-ok"></i> Study Table</li>
								<li><i class="icon-ok"></i> Plastic Chair</li>
								<li><i class="icon-ok"></i> Almirah</li>
</ul>
								
								
								
								
										<h4 class="pb0 pt0 ma0">4 Seater</h4>
							<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Room Category</td>
							   <td width="25%">Air Cooled </td>
							   <td width="25%">Air Conditioned</td>
							 </tr>
							 <tr>
							   <td>Fee for Full Academic Session </td>
							   <td>52000</td>
							   <td>62000</td>
							 </tr>
							  <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>300</td>
							   <td>500</td>
							 </tr>
							  </tbody>
							</table>
							<h4 class="pb0 pt20 ma0">3 Seater</h4>
							<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Room Category</td>
							   <td width="25%">Air Cooled </td>
							   <td width="25%">Air Conditioned</td>
							 </tr>
							 <tr>
							   <td><p>Fee for Full Academic Session </p></td>
							   <td>For Boys: 62000<br>
						       For Girls: 57000</td>
							   <td>For Boys: 77000<br>
For Girls: 72000</td>
							   
							 </tr>
							 <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>400</td>
							   <td>650</td>
							 </tr>
							  </tbody>
							</table>
							<h4 class="pb0 pt20 ma0">2 Seater</h4>
							<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Room Category</td>
							   <td width="25%">Air Cooled </td>
							   <td width="25%">Air Conditioned</td>
							 </tr>
							 <tr>
							   <td>Fee for Full Academic Session </td>
							   <td>73000</td>
							   <td>88000</td>
							   
							 </tr>
							 <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>500</td>
							   <td>750</td>
							 </tr>
							  </tbody>
							</table>
							<h4 class="pb0 pt20 ma0">1 Seater</h4>
							<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Room Category</td>
							   <td width="25%">Air Cooled </td>
							   <td width="25%">Air Conditioned</td>
							 </tr>
							 <tr>
							   <td>Fee for Full Academic Session </td>
							   <td>95000</td>
							   <td>115000</td>
							   
							 </tr>
							 <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>700</td>
							   <td>1000</td>
							 </tr>
							  </tbody>
							</table>
							
							
							  <h4 class="pb0 pt0 ma0">5 Seater</h4>
							<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Room Category</td>
							   <td width="25%">Air Cooled </td>
							   <td width="25%">Air Conditioned</td>
							 </tr>
							 <tr>
							   <td>Fee for Full Academic Session </td>
							   <td>47000</td>
							   <td>57000</td>
							 </tr>
							  <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>250</td>
							   <td>400</td>
							 </tr>
							  </tbody>
							</table>
							
							<h4 class="pb0 pt0 ma0">6 Seater</h4>
							<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Room Category</td>
							   <td width="25%">Air Cooled </td>
							   <td width="25%">Air Conditioned</td>
							 </tr>
							 <tr>
							   <td>Fee for Full Academic Session </td>
							   <td>42000</td>
							   <td>52000</td>
							 </tr>
							  <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>200</td>
							   <td>325</td>
							 </tr>
							  </tbody>
							</table>
							<strong>Note:</strong> If a student has opted for 4 seater and due to any reason he/ she leaves 4 seater in between or opts for 3 seater/ 2 seater/ 1 seater then the entitled units will be distributed amongst the students staying there. For example, in 4 seater if 3 students are staying then they will be entitled for 300*3= 900 units and excess units will be divided amongst the students and will be paid by them accordingly.  
							
							
								</div>
								<div class="tab-content clearfix" id="tabs-2">
									
						
							
<h4 class="pb0 pt20 ma0">Apartments</h4>
<!--Apartments have 1/2/3/4 rooms in an apartment.--> <br>
<!--Broadly of Two Types:<br>
<strong>Shared Apartment:</strong> Apartment consists of 2/3 rooms and student opts for one of the room (attached washroom) which may be of 1/2/3 seater. The common kitchenette and lobby is shared by all the occupants of apartments (all rooms of the apartment)<br>
<strong>Independent Apartment:</strong> Apartment consists of one room with lobby and kitchenette area. One of two students opt for this apartment.-->
							  The following facilities are available in apartments:-
<ul class="iconlist iconlist-color">
								<li><i class="icon-ok"></i> Air Conditioner  in each room</li>
								<li><i class="icon-ok"></i> Attached washroom in each room</li>
								<li><i class="icon-ok"></i> Geyser in each room</li>
								<li><i class="icon-ok"></i> Wooden Box Bed</li>
								<li><i class="icon-ok"></i> Study Table</li>
								<li><i class="icon-ok"></i> Plastic Chair</li>
								<li><i class="icon-ok"></i> Almirah</li>
								<li><i class="icon-ok"></i> Permission to use two electrical gadgets (maximum load upto 5 ampere)</li>
</ul>
<!--<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped mt10 mb10 text-center">

  <tr>
    <td colspan="5"><strong>Fee for Apartments for Academic session 2017-2018</strong></td>
  </tr>
  <tr>
    <td>Seating/    Apartment Category</td>
    <td>&nbsp;</td>
    <td>Fee Structure for    Boys (in Rupees)</td>
    <td>Fee Structure    for Girls (in Rupees)</td>
    <td>Free    Electricity units per seat per session</td>
  </tr>
  <tr>
    <td rowspan="4">Allotment in Apartment with 2/3/4    rooms (With A.C, Lobby, Kitchenette)</td>
    <td>2+4 Seater <br>
      (Shared Apartment)</td>
    <td >64500</td>
    <td>N.A.</td>
    <td >200</td>
  </tr>
  <tr>
    <td>3 Seater (Shared    apartment) </td>
    <td >84500</td>
    <td>N.A.</td>
    <td >500</td>
  </tr>
  <tr>
    <td>2 Seater (Shared apartment) </td>
    <td >99000</td>
    <td >94000</td>
    <td >750</td>
  </tr>
  <tr>
    <td>1 Seater (Shared apartment) </td>
    <td >109000</td>
    <td >104000</td>
    <td >1000</td>
  </tr>
  <tr>
    <td rowspan="4">Allotment in Apartment with one    room only (With A.C, Kitchenettte etc.)</td>
    <td>4 Seater (Independent Apartment)</td>
    <td>79500</td>
    <td >N.A.</td>
    <td >375</td>
  </tr>
  <tr>
    <td>3 Seater (Independent    apartment) </td>
    <td>89500</td>
    <td >N.A.</td>
    <td >500</td>
  </tr>
  <tr>
    <td>2 Seater (Independent    apartment) </td>
    <td>109000</td>
    <td >94000</td>
    <td >750</td>
  </tr>
  <tr>
    <td>1 Seater (Independent apartment) </td>
    <td>N.A.</td>
    <td >104000</td>
    <td >1000</td>
  </tr>
</table>-->
							
                            
           <h4 class="pb0 pt0 ma0">4 Seater Apartment</h4>
							<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Category</td>
							   <td width="25%">Without Pantry</td>
							   <td width="25%">With Pantry</td>
							 </tr>
							 <tr>
							   <td>Fee for Full Academic Session </td>
							   <td>82000</td>
							   <td>87000</td>
							 </tr>
							  <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>500</td>
							   <td>500</td>
							 </tr>
							  </tbody>
							</table>
							<h4 class="pb0 pt20 ma0">3 Seater Apartment</h4>
							<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Category</td>
							   <td width="25%">Without Pantry</td>
							   <td width="25%">With Pantry</td>
							 </tr>
							 <tr>
							   <td>Fee for Full Academic Session </td>
							   <td>100000</td>
							   <td>105000</td>
							 </tr>
							  <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>650</td>
							   <td>650</td>
							 </tr>
							  </tbody>
							</table>
							<h4 class="pb0 pt20 ma0">2 Seater Apartment</h4>
							<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Category</td>
							   <td width="25%">Without Pantry</td>
							   <td width="25%">With Pantry</td>
							 </tr>
							 <tr>
							   <td>Fee for Full Academic Session </td>
							   <td>120000</td>
							   <td>125000</td>
							 </tr>
							  <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>750</td>
							   <td>750</td>
							 </tr>
							  </tbody>
							</table>
							<h4 class="pb0 pt20 ma0">1 Seater Apartment</h4>
					  <table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Category</td>
							   <td width="25%">Without Pantry</td>
							   <td width="25%">With Pantry</td>
							 </tr>
							 <tr>
							   <td>Fee for Full Academic Session </td>
							   <td>150000</td>
							   <td>155000</td>
							 </tr>
							  <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>1000</td>
							   <td>1000</td>
							 </tr>
							  </tbody>
							</table>
                                             
                            
                            
                      
                     <!-- <p class="mb10">** The Apartment has with/ without pantry facility.</p>-->
							
							
<!--<h4 class="pb0 pt20 ma0">Apartment with additional facilities</h4>
							  The following facilities are available in Single Seater Independent Apartment:
<ul class="iconlist iconlist-color">
	  <li><i class="icon-ok"></i> Air Conditioner in room</li>
								<li><i class="icon-ok"></i> Attached washroom</li>
								<li><i class="icon-ok"></i> Geyser in attached washroom</li>
								<li><i class="icon-ok"></i> Wooden Cupboards</li>
								<li><i class="icon-ok"></i> Curtains</li>
								<li><i class="icon-ok"></i> Mattress</li>
								<li><i class="icon-ok"></i> Pillow and Pillow Cover</li>
								<li><i class="icon-ok"></i> Bed sheet</li>
								<li><i class="icon-ok"></i> Bucket & Mug</li>
								<li><i class="icon-ok"></i> Dustbin</li>
								<li><i class="icon-ok"></i> Periodically replacement of Bed sheet, Pillow Cover along with regular housekeeping</li>
								<li><i class="icon-ok"></i> Permission to use two electrical gadgets (maximum load upto 5 ampere)</li>
								
</ul>

					<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped mt10 mb10 text-center">
					  <tr>
					    <td colspan="4"><strong>Fee for Apartments for Academic session 2018-2019</strong></td>
				      </tr>
					  <tr>
					    <td>Seating/    Apartment Category</td>
					    <td>&nbsp;</td>
					    <td>Fee Structure for    Boys (in Rupees)</td>
					    <td>Free    Electricity units per seat per session</td>
				      </tr>
					  <tr>
					    <td>Allotment in Apartment with one    room only</td>
					    <td>1 Seater (Independent apartment) </td>
					    <td >149000</td>
					    <td >1000</td>
				      </tr>
					  </table>-->
	
     <h4 class="pb0 pt20 ma0">Apartment with additional facilities</h4>  

   <p class="mb10">The following facilities are available in apartments:- </p>	
   
	 <ul class="iconlist iconlist-color">
	  <li><i class="icon-ok"></i> Double Box Bed (Wooden)</li>
								<li><i class="icon-ok"></i> Study Table</li>
								<li><i class="icon-ok"></i>Chair</li>
								<li><i class="icon-ok"></i> Almirah</li>
								<li><i class="icon-ok"></i> AC</li>
								<li><i class="icon-ok"></i> Geyser</li>
								<li><i class="icon-ok"></i> Mattress</li>
								<li><i class="icon-ok"></i> Curtain</li>
								<li><i class="icon-ok"></i> Bed sheet</li>
								<li><i class="icon-ok"></i> Pillow with Pillow Covers</li>
								<li><i class="icon-ok"></i> Bucket</li>
								<li><i class="icon-ok"></i> Mug</li>
								<li><i class="icon-ok"></i> Dustbin</li>								
</ul>
	  
    <h4 class="pb0 pt20 ma0">1 Seater Apartment</h4>
							<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td width="50%">Category</td>
							   <td width="25%">With Pantry</td>
							 </tr>
							 <tr>
							   <td>Fee for Full Academic Session </td>
							   <td>158000</td>
							 </tr>
							  <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>1000</td>
							 </tr>
							  </tbody>
							</table>
    
    				<br>
<br>
		
							<strong>Note:</strong> If a student has opted for 3 seater and due to any reason he/ she leaves 3 seater in between or opts for 2 seater/ 1 seater then the entitled units will be distributed amongst the students staying there. For example, in 3 seater if 2 students are staying then they will be entitled for 650*2= 1300 units and excess units will be divided amongst the students and will be paid by them accordingly. 
							
							
								</div>
								<div class="tab-content clearfix" id="tabs-3">
								
								<h4 class="pb0 pt20 ma0">Dormitory</h4><br>
							  The following facilities are available in Dormitory:- (Qty. as per seater)
<ul class="iconlist iconlist-color">

								<li><i class="icon-ok"></i> Air Cooler</li>
								<li><i class="icon-ok"></i> Iron Bed</li>
								<li><i class="icon-ok"></i> Study Table</li>
								<li><i class="icon-ok"></i> Plastic Chair</li>
								<li><i class="icon-ok"></i> Single Almirah</li>
								<li><i class="icon-ok"></i> Geyser</li>
								<li><i class="icon-ok"></i> With/Without attached washroom as applicable</li>
</ul>
									
                           
                            
                             
                              <h4 class="pb0 pt20 ma0">Dormitory (Upto 6 Seater)</h4>
					<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td>Room Category</td>
							   <td>Without attached washroom</td>
							   </tr>
							 <tr>
							   <td width="50%">Fee for Full Academic Session </td>
							   <td width="25%">39000</td>
							   </tr>
							 <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>200</td>
							   </tr>
							  </tbody>
							</table>
                                
						<h4 class="pb0 pt20 ma0">Dormitory (7 Seater to 15 Seater)</h4>
					  <table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td>Room Category</td>
							   <td>Without attached washroom</td>
							   <td>With attached washroom</td>
							   </tr>
							 <tr>
							   <td width="50%">Fee for Full Academic Session </td>
							   <td width="25%">34000</td>
							   <td width="25%">37000</td>
							 </tr>
							 <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>150</td>
							   <td>150</td>
							 </tr>
					    </tbody>
					  </table>
							
					  <h4 class="pb0 pt20 ma0">Dormitory (16 Seater onwards)</h4>
					  <table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped">
							  <tbody>
							 <tr>
							   <td>Room Category</td>
							   <td>Without attached washroom</td>
							   </tr>
							 <tr>
							   <td width="50%">Fee for Full Academic Session </td>
							   <td width="25%">29000</td>
							   </tr>
							 <tr>
							   <td>Free Electricity units per seat per Session</td>
							   <td>100</td>
							   </tr>
							  </tbody>
							</table>
							
								
								
								
							  </div>
								

							</div>

						</div>
						
							
							
							<!--<p class="pt10 mb10">* Allocation of exact Dormitory Room (with/ without attached washroom) will be done at the time of joining/ reporting to the University only.</p>-->
							

					  <div class="pb50"></div>
						
					</div>
				</div>
						</div>
		
		</div>
	</div>

	<div class="modal fade bs-example-modal-lg" id="meal-plan" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-body">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">Details for Mess Plan</h4>
					</div>
					<div class="modal-body pb20 " style="height: 450px;overflow-y: scroll; text-transform: none;">
						<ul class="iconlist iconlist-color">		
						<li><i class="icon-ok"></i>Mess Plan will be provided till the end of the regular academic 
						session including regular exams or 10 months from the start of session, whichever is earlier. 
						Students can avail the mess plan two days prior to start of academic session and will be required 
						to leave it within two days after regular exams. For availing Mess Plan after the end of academic 
						session for any purpose like summer school/ reappear examination/ make up examination/ PEP/ EEP 
						classes etc., additional proportionate fee for mess and its administration will have to be paid by the student, 
						subject to the availability and permission for mess plan.</li>
						<li><i class="icon-ok"></i>Customized plan (e.g. for full calendar year) may 
						be provided on request.</li>
						<li><i class="icon-ok"></i>Students have an option to avail Mess Plan from the University or may manage on their own. Mess Plan may be offered in 2 different categories i.e. Standard Food and Basic Food which includes both options of  North Indian Food and Regional Food (South Indian).</li>
						
						<!--<li><i class="icon-ok"></i>Skip Meal is an option given to student in which students can skip 4 meals weekly (2 Lunch and 2 Dinner) for selected slot of days. To skip a meal in mess Days Slots are<br>
             1.       Monday & Wednesday<br>
             2.       Tuesday & Thursday<br>
             3.       Wednesday & Friday<br>
On selected days students are free to take his/her lunch and dinner outside the mess on payment basis, breakfast                                           and dinner should be provided in mess only. The mess charge is slashed by Rs. 4000/- for the session/10 months whichever is earlier for the student choosing the skip meal option.
</li>-->
						
						<br>The details of Fee for Mess and its administration for different mess categories is as per the following table:

							
							
					
	<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table table-bordered nobottommargin table-striped mt10 mb10 ">
	<col width="30%">
<col width="50%">  
<col width="30%">  

<tr>
    <th >For Academic Session</th>
    <th >Standard Food</th>
    <th >Basic Food</td>    
  </tr>
  <tr>
    <td >Fee For    full Academic Session</td>
    <td >Rs. 32000</td>
    <td >Rs. 24000</td>
    </tr>
  <tr>
    <td >Fee Per    Semester</td>
    <td > Rs. 16500<br></td>
    <td >Rs. 12500</td>
    </tr>
  </table>
						<!--<li><i class="icon-ok"></i>Whenever Mess Plan is alloted for one semester only, then student has to pay Rs. 17000/- for first semester. In case he/ she opts to continue for next semester also, then he/ she needs to pay Rs. 15500/- for even semester.</li>-->
						<!--<li><i class="icon-ok"></i>Standard Mess has prescribed standard menu containing mainly North Indian dishes.</li>-->
						<!--<li><i class="icon-ok"></i>The fee for Meal Plan is for academic session 2017-18 only and is subject to change for successive sessions.</li>-->
						<!--<li><i class="icon-ok"></i>Continental Meal (if offered), may not be available in the same residential facility but may be at other place(s) within the University Campus.</li>-->
				      </ul>
						
					</div>
				</div>			</div>
		</div>
	</div>

	<div class="modal fade bs-example-modal-lg" id="flaundry" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-body">
				   <div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">Laundry Facility</h4>
					</div>
					<div class="modal-body pb20" style="height: 450px;overflow-y: scroll; text-transform: none;">
							Quality Laundry Services are available in the University Campus. The Laundry Services are provided through the best washing and drying machines using standard chemicals.
							<ul class="iconlist iconlist-color">
								<!--<li><i class="icon-ok"></i><!--Fee for Laundry facility (Optional) for academic session 2017-2018 is&nbsp;₹  3250/-
Fee for Laundry Facility is yet to be finalized.</li>-->

<li><i class="icon-ok"></i>The Laundry facility is optional. The Fee for Laundry and its administration is Rs. 4000 for academic session</li>

								<li><i class="icon-ok"></i>Generally, steam press system is used.</li>
								<li><i class="icon-ok"></i>Delivery/ collection is generally done in a bag with the proper identification number of the user at specified place in Residential Compound.</li>
								<li><i class="icon-ok"></i>Each student can get fixed number of his/her own clothes (not of his friends/ associates) washed/ironed from the Laundry in a month. If in a specific month student utilizes service of laundry facility for less number of clothes, then the balance will not be carried forward.</li>
							</ul>
						
					</div>
				</div>			</div>
		</div>
	</div>
	
		
	<div class="notopmargin mb0 pt50 pb0">
		<div class="container clearfix">
			<div class="col-md-12 pa0 mt20 grid-innr">
				<div class="col-sm-6 col-xs-12 pad2 pull-right">
					<div class="fslider" data-animation="fade" data-thumbs="true" data-arrows="false" data-speed="1200" data-pause="7000">
						<div class="flexslider">
							<div class="slider-wrap">
								<div class="slide" data-thumb="images/residence/green_env/thumbs/1.jpg">
									<a href="#">
										<img width="auto" height="auto" class="lazy" data-lazyload="images/residence/green_env/1.jpg" alt="LPU residence">
										<!--<div class="flex-caption slider-caption-bg">Responsive Ready Design</div>-->
									</a>
								</div>
								<div class="slide" data-thumb="images/residence/green_env/thumbs/2.jpg">
									<a href="#">
										<img width="auto" height="auto" class="lazy" data-lazyload="images/residence/green_env/2.jpg" alt="LPU residence">
										<!--<div class="flex-caption slider-caption-bg slider-caption-bg-light slider-caption-top-left">Retina Graphics Display</div>-->
									</a>
								</div>
								<div class="slide" data-thumb="images/residence/green_env/thumbs/3.jpg">
									<a href="#">
										<img width="auto" height="auto" class="lazy" data-lazyload="images/residence/green_env/3.jpg" alt="LPU residence">
										<!--<div class="flex-caption slider-caption-bg slider-caption-top-right">Bootstrap 3+ Compatible</div>-->
									</a>
								</div>
								<div class="slide" data-thumb="images/residence/green_env/thumbs/4.jpg">
									<a href="#">
										<img width="auto" height="auto" class="lazy" data-lazyload="images/residence/green_env/4.jpg" alt="LPU residence">
										<!--<div class="flex-caption slider-caption-bg slider-caption-bg-light slider-caption-bottom-right">eCommerce Design Included</div>-->
									</a>
								</div>
								<div class="slide" data-thumb="images/residence/green_env/thumbs/5.jpg">
									<a href="#">
										<img width="auto" height="auto" class="lazy" data-lazyload="images/residence/green_env/5.jpg" alt="LPU residence">
										<!--<div class="flex-caption slider-caption-bg">eCommerce Design Included</div>-->
									</a>
								</div>
							</div>
						</div>
							
					</div>	
				</div>
					
				<div class="col-md-6">
					<div class="heading-block topmargin-sm">
						<h3>Clean & Green Environment</h3>
					</div>					
					<div class="col-md-12 pa0">	
						<p class="lead pb15">LPU is one of the greenest campuses in the country. The greenery makes for a great learning environment and promotes creativity!</p>
					</div>
						

				</div>
			</div>
		</div>
	</div>

	
	
			<!-- Content
		============================================= -->
		<section id="content" class="pb0">
			<div class="content-wrap mb0 mt0 section">
				<div class="container clearfix">
				
					<div id="portfolio" class="portfolio grid-container portfolio-3 portfolio-masonry clearfix">

						<article class="portfolio-item grid-outer">
							<div class="portfolio-image">
								<a href="images/residence/4.jpg" data-lightbox="image"><img width="auto" height="auto" class="lazy" data-lazyload="images/residence/4.jpg" alt="Mentor Support"></a>
								
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25">IN HOUSE MENTOR SUPPORT</h3>
								<span class="pb15 pl20 pr25">The residential faculty & staff provide after-hours guidance and support to the students, in case they need any academic or life advice.</span>
							</div>
						</article>

						<article class="portfolio-item grid-outer">
							<div class="portfolio-image">
								<a href="images/residence/5.jpg" data-lightbox="image"><img width="auto" height="auto" class="lazy" data-lazyload="images/residence/5.jpg" alt="Medical Assistance"></a>
								
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25">MEDICAL ASSISTANCE</h3>
								<span class="pb15 pl20 pr25">The campus has a 24 hours 30 bed hospital which is staffed with resident medical officers, medical lab, dieticians and physiotherapists.</span>
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="portfolio-image">
								<a href="images/residence/6.jpg" data-lightbox="image"><img width="auto" height="auto" class="lazy" data-lazyload="images/residence/6.jpg" alt="Apartments"></a>
								
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25">APARTMENTS STYLE HOUSING</h3>
								<span class="pb15 pl20 pr25">Keeping students's requirements in mind, University offers quality residence (offering above average necessities) for their living comforts.</span>									
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="portfolio-image">
								<a href="images/residence/7.jpg" data-lightbox="image"><img width="auto" height="auto" class="lazy" data-lazyload="images/residence/7.jpg" alt="Laundry"></a>
								
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25">IN-HOUSE LAUNDRY</h3>
								<span class="pb15 pl20 pr25">In house laundry services are available at a nominal charges to students.</span>
								
								<a href="#" class="more-link pl20" data-toggle="modal" data-target="#flaundry">Laundry Facility <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
								
								
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="portfolio-image">
								<a href="images/residence/8.jpg" data-lightbox="image"><img width="auto" height="auto" class="lazy" data-lazyload="images/residence/8.jpg" alt="Meal Plan"></a>
								
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25">MESS PLAN / FOOD</h3>
								<span class="pb15 pl20 pr25">All residential facilities have dining halls that provide good quality and hygienic food four times a day. Over 1 Lakh meals are prepared each day!<br>
								</span>

								<a href="#" class="more-link pl20" data-toggle="modal" data-target="#meal-plan">Mess Plan 
									<i class="fa fa-angle-double-right" aria-hidden="true"></i>
								</a>
								
							</div>
						</article>
						
						<article class="portfolio-item grid-outer">
							<div class="portfolio-image">
								<a href="images/residence/9.jpg" data-lightbox="image"><img width="auto" height="auto" class="lazy" data-lazyload="images/residence/9.jpg" alt="Earn While You Learn"></a>
								
							</div>
							<div class="portfolio-desc">
								<h3 class="pl20 pr25">EARN WHILE YOU LEARN</h3>
								<span class="pb15 pl20 pr25">Become independent! Students residing in the campus can earn while studying by taking up part time jobs in labs, library, sales, shopping mall etc. </span>									
							</div>
						</article>
				
					</div>
				
					<script type="text/javascript">

						jQuery(window).load(function(){

							var $container = $('#portfolio');

							$container.isotope({ transitionDuration: '0.65s' });

							$('#portfolio-filter a').click(function(){
								$('#portfolio-filter li').removeClass('activeFilter');
								$(this).parent('li').addClass('activeFilter');
								var selector = $(this).attr('data-filter');
								$container.isotope({ filter: selector });
								return false;
							});

							$('#portfolio-shuffle').click(function(){
								$container.isotope('updateSortData').isotope({
									sortBy: 'random'
								});
							});

							$(window).resize(function() {
								$container.isotope('layout');
							});

						});

					</script><!-- Portfolio Script End -->

				

				</div>
				<div style="font-size:12px;" class="container mt50">
				<a href="../downloads/conditions-for-availing-residential-facility.pdf" target="_blank">Click here</a> to view the Conditions for availing Residential Facility
				</div>	
			</div>
			
		</section>
		
		<!-- #content end -->

		
		<!-- Content place here end -->


	
	
		<!-- Footer
		============================================= -->
			﻿
<!-- Footer============================================= -->
<style>
	.iccash li{margin-bottom:15px;}
	#myLargeModal .mod-btn-6.active {background: #f68220 none repeat scroll 0 0;border-color: #f68220;color: #fff;}	
	#myLargeModal .mod-btn-6:hover {background: #f68220 none repeat scroll 0 0;border-color: #f68220;color: #fff;}	
	.nirf-hd {color: #333333;text-transform: uppercase;font-size: 14px;font-weight: 500;text-decoration: none;line-height: 25px;}	
	.nirf-hd span {text-transform: none;color: #f68220;	text-decoration: underline;	}	
	.nirf li i {color: #f68220;	font-size: 11px;padding-right: 10px;}	
	.vertical-alignment-helper {display: table;height: 100%;width: 100%;}
	.vertical-align-center {display: table-cell;vertical-align: middle;}
	.modal-content {width: inherit;height: inherit;margin: 0 auto;}	
	.disciplines-popup {-webkit-border-radius: 10px !important;-moz-border-radius: 10px !important;border-radius: 10px !important;}	
	.disciplines-popup li {background: rgba(0, 0, 0, 0) url("//www.lpu.in/images/icons/widget-link.png") no-repeat scroll left 5px;line-height: 25px;border: medium none !important;color: #444;font-size: 14px;list-style: outside none none;padding-left: 15px;}	
	#dexample td {border: none !important;background: url(//www.lpu.in/images/icons/widget-link.png) no-repeat;padding: 0 0 0 15px;display: inline-block}	
	#dexample tr {background: none !important;border: medium none;display: inline-block;float: left;padding: 0 0 0 15px;width: 33%;}	
	.no-footer,	.dataTables_wrapper.no-footer .dataTables_scrollBody {border: none !important;}	
	#disciplines-popup table.dataTable thead th,#disciplines-popup table.dataTable thead td {border: none !important;}	
	@media screen and (min-width: 320px) and (max-width: 1023px) {#dexample tr {float: none;width: 100%;}}	
		
	.intercom .feature-box .fbox-icon {	width: 55px;height: 55px;}
	.intercom .feature-box .fbox-icon i {line-height: 58px;background-color: #ff4358;}	
	.intercom .fbox-effect .fbox-icon i:hover,.intercom .fbox-effect:hover .fbox-icon i {background-color: #ff4358;}	
	.intercom .fbox-effect .fbox-icon i:after {box-shadow: none;left: 0;}
	.intercom .badge {position: absolute;z-index: 999;right: 0;cursor: pointer;}	
	.toast-top-left {bottom: 80px;top: auto !important;}	
	.badge-color {background: #ff4358;color: #fff;box-shadow: 0 !important;}	
	.mt75 {	margin-top: 75px}	
	/*body.modal-open {overflow-y: scroll;}*/	
	.intercom .icon-comment:before {content: "\e65f";left: 14px;position: absolute;}	
	.m10 {margin-top: 9%;}
	.m3 {margin-top: 3%;}	
	.modal-dialog {	margin: 0 auto;}	
	.modal-body {padding: 0 15px !important;}	
	#noti .entry-content {background: #fff;}
	.single-modal {width: 300px !important;}
	.double-modal {	width: 600px !important;}
	.col-61 {width: 50% !important;}	
	.col-12 {width: 100% !important;}	
	#myLargeModal .modal-content {background: #EBEBEB;}	
	#myLargeModal .mod-btn {border-color: #2985C6;color: #2985C6;width: 96%;text-align: center;}	
	#myLargeModal .mod-btn:hover {border-color: #2985C6;color: #fff;background: #2985C6;}	
	#myLargeModal .mod-btn-6 {border-color: #2985C6;color: #2985C6;width: 45%;text-align: center;padding: 0 3px!important;font-size: 9px;}	
	#myLargeModal .mod-btn-6:hover {border-color: #2985C6;color: #fff;background: #2985C6;}	
	#myLargeModal .modal-header {padding: 7px;border-color: #d6d6d6;}
	.pr7 {padding-right: 7px;}
	.pl7 {padding-left: 7px;}	
	@media(max-width:770px) {#noti .entry-content p {min-height: auto !important;}#myLargeModal.modal{overflow-y:scroll !important;}}	
	.popupwindow {cursor: pointer;}
</style>

<!--Start of Zendesk Chat Script-->
<script type="text/javascript">
window.$zopim || (function(d, s) {
    var z = $zopim = function(c) {
            z._.push(c)
        },
        ps = z.s =
        d.createElement(s),
        e = d.getElementsByTagName(s)[0];
    z.set = function(o) {
        z.set.
        _.push(o)
    };
    z._ = [];
    z.set._ = [];
    ps.async = !0;
    ps.setAttribute("charset", "utf-8");
    ps.src = "https://v2.zopim.com/?5zU5ycyGChvBrSvnk5mgdxLN5fzikAC3";
    z.t = +new Date;
    ps.
    type = "text/javascript";
    e.parentNode.insertBefore(ps, e);
	
})(document, "script");
</script>
<!--End of Zendesk Chat Script-->


<div class="right-new-bar  hidden-sm hidden-xs hidden-xxs">


<div class="mb5 text-right"><a target="_blank"  href="//iviewd.com/lpu/"><img width="" height="auto" src="//www.lpu.in/images/virtual-tour.png" alt=""></a></div>




	<div class="right-icons apply-now" style="display:none !important">
		<div class="rotate" href="#LoginModal1" data-lightbox="inline" style="cursor:pointer">Apply Now</div>
	</div>
	<div class="right-icons call">
		<a href="" class="ppwnd white-tooltip" data-toggle="tooltip" data-placement="left" title="Schedule a Call">
		<i class="icon-call ml5"></i></a>
	</div>
	<div class="right-icons d-one">
		<a href="" target="_blank" class="white-tooltip si-whatsapp hidden-sm hidden-xs hidden-xxs" data-toggle="tooltip" data-placement="left" title="">
			<img width="auto" height="auto" src="//www.lpu.in/images/whatsapp-icon.png" alt="">
		</a>		
	</div>

	<div class="right-icons international">
		<a href="" target="_blank" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="For SAARC Nations::+91-9780005961 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;For Other Nations::+91-9855322332">
			<img width="auto" height="auto" src="//www.lpu.in/images/whatsapp-icon.png" alt="">
		</a>
	</div>
	<div class="right-icons international">
		<a href="//www.lpu.in/international/contact-us.php" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="Enquire Now ">
			<img width="auto" height="auto" src="//www.lpu.in/images/enquire-icon.png" alt="">
		</a>
	</div>
	<div class="right-icons international">
		<a href="//admission.lpu.in" target="_blank" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="Apply Now">
			<img width="auto" height="auto" src="//www.lpu.in/images/apply-now-icon.png" alt="">
		</a>
	</div>
	<div class="right-icons ltown"><a href="//www.lpu.in/admission/lpu-in-your-town.php#lpu-town" class="white-tooltip" data-toggle="tooltip" data-placement="left" title="LPU in Your Town"><i class="icon-location ml3"></i></a>
	</div>
	<div class="right-icons chatimg hide" style="height:43px;">
	</div>
</div>
<footer id="footer" class="dark remove-div" style="background-color: #222;">
	<div class="container mt15 clearfix" style="font-size:8px">E&OE </div>
	<div class="container">
		<!-- Footer Widgets
				============================================= -->
		<div class="footer-widgets-wrap clearfix" style="padding:20px 0 10px 0">
			<div class="col_two_third">
				<div class="widget clearfix">
					<!-- -->
					<div class="row">
						<div class="col-md-5 col-sm-12 col-xs-12 bottommargin-sm widget_links">
							<h4 class="mb10">Admissions</h4>
							<ul>
								<li><a href="//www.lpu.in/admission/admissions.php"> Admissions 2019 - 20 </a>
								</li>
								<li><a href="//www.lpu.in/international/international_students.php"> International Admissions 2019 - 2020 </a>
								</li>
								<li><a target="_blank" href="//www.lpude.in/admissions/overview.php">Distance Education Admissions</a>
								</li>
								<li><a href="//www.lpu.in/scholarship/scholarship.php">Scholarship</a>
								</li>
								<li><a title="Fee Deposit" href="//www.lpu.in/frmloginaccounts.aspx">Fee Deposit</a>
								</li>
								<li><a title="Top Engineering Courses (B.Tech - M.Tech)" href="//www.lpu.in/engineering/" target="_blank">
								Top Engineering Courses</a>
								</li>
							</ul>
							<h4 class="mb10 mt20">Media</h4>
							<ul>
								<li><a href="//www.lpu.in/tv-ads.php">TV Ads</a>
								</li>
								<li class="hide"><a href="//www.lpu.in/print-ads.php">Print Ads</a>
								</li>
								<li><a href="//www.lpu.in/newshome.aspx">Media Coverage</a>
								</li>
							</ul>
						</div>
						<div class="col-md-4 col-sm-12 col-xs-12 bottommargin-sm widget_links">
							<h4 class="mb10">Other Links:</h4>
							<ul>
								<li><a href="//alumni.lpu.in" target="_blank"> Alumni </a>
								</li>
								<li><a href="//www.lpu.in/campus_life/entrepreneurship.php"> Entrepreneurship </a>
								</li>
								<li class="hide"><a href="//www.lpu.in/campus_life/campus-events.php"> Events </a>
								</li>
								
								
								<li><a href="//www.lpu.in/EventCertificate/index.aspx"> Download Event Certificate </a>
								<li><a href="//www.lpu.in/authenticate" target="_blank" title="Certificate Authentication">Certificate Authentication</a>
								</li>
								<li><a target="_blank" title="Fee Deposit" href="//nad.gov.in/">National Academic Depository</a>
								</li>
								<li><a href="//www.lpu.in/jpd" target="_blank" title="Joint Placement Drive">Joint Placement Drive</a>
								</li>
								<li> <a data-toggle="modal" data-target="#convocation" href="#">9th Convocation Gallery</a> </li>
								<li> <a href="//www.lpu.in/knowledge-brain-storm/index.php">Knowledge Brainstorm</a> </li>
								<li> <a href="" class="" data-toggle="modal" data-target="#nirf">NIRF</a>
								</li>
								<li> <a href="//www.lpu.in/lpusummerschool/index.php">LPU Summer School 2018</a> </li>
							</ul>
						</div>


						<div class="col-md-3 col-sm-12 col-xs-12  widget_links">

							<h4 class="mb10">&nbsp;</h4>
							<ul>
							<li> <a href="//schools.lpu.in" target="_blank">Schools.lpu.in</a> </li>
								<li><a id="bt-notification" href="#" data-toggle="modal" data-target="#myLargeModal">Education Awards</a>
								</li>
								<li> <a href="//www.lpu.in/explorica/index.php" target="_blank">Explorica</a> </li>
								<li> <a href="//www.lpu.in/downloads/ssr.pdf" target="_blank">LPU SSR</a> </li>
								<li> <a href="https://ums.lpu.in/lpuums/" target="_blank">Parent's Login</a> </li>
								<li> <a href="https://ums.lpu.in/lpuums/" target="_blank">UMS Login</a>
								</li>
								<li><a href="//www.lpu.in/about_lpu/tour_lpu.php" target="_blank">Campus Visit</a>
								</li>
								<li><a href="//www.lpu.in/jobs/jobs_at_lpu.php" target="_blank">Jobs At LPU</a>
								</li>
								<li><a href="//www.lpu.in/contact_us/contact-us.php" target="_blank">Contact</a> </li>
								<li><a href="https://docs.google.com/forms/d/e/1FAIpQLScHTG-vQoSOKIRPGnuNZ2bc66M6BOpJXOxBUxOFAUdfz35UkA/viewform" target="_blank">Supplier Registration</a>
								</li>
								<!--<li><a href="//www.lpu.in/downloads/Corigendum-Indian-Express-29-8-18.html" target="_blank">Corrigendum</a></li>-->
						</div>
					</div>
					
				</div>
			</div>
			<div class="col-md-3 col-sm-12 col-xs-12">				
				<div class="widget clearfix" style="margin-bottom: -20px;">
					<div class="row">
						<div class="col-md-12 clearfix bottommargin-sm">
							<a href="//www.lpu.in/about_lpu/tour_lpu.php" style="margin-right: 10px;">
                				<img width="auto" height="auto" src="//www.lpu.in/images/360.gif"> 
              				</a>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 clearfix">
							<h4 class="mt0 pr10" style="display:inline;float:left">Download App</h4>
							<div style="display:inline;float:left">
								<a title="Appstore" class="social-icon si-rounded si-appstore" href="https://itunes.apple.com/in/app/lputouch/id509819753?mt=8" target="_blank">
							<i class="icon-appstore"></i>
							<i class="icon-appstore"></i>
						</a>
						<a title="Android" class="social-icon si-rounded si-android" href="https://play.google.com/store/apps/details?id=ums.lovely.university&hl=en" target="_blank">
							<i class="icon-android"></i>
							<i class="icon-android"></i>
						</a>							
							</div>
							<div class="clearfix"></div>
								<div class="col-md-12 col-sm-12 col-xs-12 pl0 widget_links">
              <div class="mb10">Subscribe Newsletter</div>
            <!-- <p class="mb0">Stay updated about latest happenings, events and campus news</p>-->
          <div id="widget-subscribe-form-result" data-notify-type="success" data-notify-msg=""></div>
          <div id="widget-subscribe-form-result2" data-notify-type="error" data-notify-msg=""></div>
			
			<div class="widget subscribe-widget clearfix mt15 mb15">
				<form id="widget-subscribe-form" action="#" role="form" method="post" class="nobottommargin">
					<div class="input-group divcenter">
						<span class="input-group-addon"><i id="spinner" class="icon-email2"></i></span>
							<input style="height:32px;" type="email" id="widget-subscribe-form-email" name="email" class="form-control required email plr6" placeholder="Enter your Email">
							<span class="input-group-btn">
								<button class="btn btn-success plr6" id="subs-btn" type="submit">Go</button>
							</span>
								</div>
							</form>
						</div>
		
            </div>
							
							
							<div>
								<span title="Tel"><strong>Tel:</strong></span> +91-1824-404404 <br>
								<span title="Toll Free"><strong>Toll Free:</strong></span> 1800 102 4431<br>
								<!--<span title="Helpline"><strong>Helpline:</strong></span> 01824 444545<br>-->
							</div>
							<div class="col_last tleft mt20">
								<div class="fleft clearfix">
									<div class="fleft">
										<a href="https://www.facebook.com/LPUUniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-facebook">
										<i class="icon-facebook"></i>
										<i class="icon-facebook"></i>
									  </a>
										<a href="https://twitter.com/lpuuniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										  </a>
										<a href="https://plus.google.com/+LpuIn-lovely-professional-university/posts" target="_blank" class="social-icon si-small si-borderless nobottommargin si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										  </a>
										<a href="https://www.linkedin.com/company/lovely-professional-university" target="_blank" class="social-icon si-small si-borderless nobottommargin si-linkedin">
											<i class="icon-linkedin"></i>
											<i class="icon-linkedin"></i>
										  </a>	
										<a href="https://www.youtube.com/user/LPUuniversity" target="_blank" class="social-icon si-small si-borderless nobottommargin si-gplus">
											<i class="icon-youtube"></i>
											<i class="icon-youtube"></i>
										  </a>
									</div>
									<div class="clear"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- .footer-widgets-wrap end -->

	</div>
	
			<!-- Copyrights
			============================================= -->
	<div id="copyrights" style="padding:10px 0">
		<div class="container clearfix">
			<div class="row clearfix">
				<div class="col-md-6 col-sm-12">
					<div class="copyrights-menu copyright-links clearfix">
						<!--Copyrights &copy; 2014 All Rights Reserved by Canvas Inc.<br>-->
						<img width="auto" height="auto" src="//www.lpu.in/images/footer-widget-logo.png" alt="" class="alignleft" style="margin-top: 20px; padding-right: 18px; border-right: 1px solid #4A4A4A;"/>
						<p class="pt15 mb0">
							India's Largest University* <strong>Lovely Professional University</strong>, Jalandhar-Delhi, G.T. Road, Phagwara, Punjab (INDIA) -144411.<br/>Website: //www.lpu.in
						</p>
					</div>
				</div>
				<div class="col-md-6 col-sm-12 tright hidden-xs mt15">
					<div class="fright clearfix">
						<div class="copyrights-menu copyright-links nobottommargin">
							<a href="//www.lpu.in/downloads/Ragging.pdf" target="_blank">Anti-Ragging</a>/ <a style="cursor:pointer" target="_blank" data-toggle="modal" data-target="#sexual-harrassment-footer">ICCASH</a>/ <a href="//www.lpu.in/privacy.php">Privacy Policy</a>/ <a href="//www.lpu.in/disclaimer.php">Disclaimer</a> / <a href="//www.lpu.in/downloads/student-grievance-redressal-policy.pdf">Student Grievance Redressal</a> / <a href="#">RTI</a> / Problem with this page ? <a href="mailto:webmaster@lpu.co.in?subject=Mail from lpu.in Website">Contact Webmaster</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- #copyrights end -->
</footer>

	<!-- sexual-harrassment-footer modal start -->
	<div id="sexual-harrassment-footer" class="modal fade" role="dialog">
  <div class="modal-dialog modal-dialog-centered">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ICCASH</h4>
      </div>
      <div class="modal-body">
        <ol class="mt20 ml20 iccash"><li> <a href="https://www.lpu.in/downloads/sexual-harrassment-of-women-act-and-rules-2013.pdf" target="_blank"> The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013</a></li>
<li> <a href="https://www.lpu.in/downloads/UGC_regulations-harassment.pdf"  target="_blank">UGC ( Prevention, Prohibition and Redressal of sexual harassment of Women employees and students in Higher Educational Institutions ) Regulations, 2015</a></li>

<li> <a href="https://www.lpu.in/downloads/handbook-for-prevention-of-sexual-harassment%20at-workplace.pdf"  target="_blank">Handbook on Sexual Harassment of Women at Workplace issued by the Ministry of Women and Child Development, Government of India</a></li>
<li><a href="https://www.lpu.in/downloads/composition-of-ICCASH.pdf"  target="_blank"> Composition of Internal Complaints Committee against Sexual harassment</a></li>
<li> "Sexual Harassment Complaint Registration: - <a href="mailto:iccash@lpu.co.in" target="_top">iccash@lpu.co.in</a> </li>
<li><a href="//www.lpu.in/downloads/Anti-Sexual-Harrasment-policy.pdf" target="_blank">Anti Sexual Harrasment Policy</a> </li>

</ol>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
		<!-- sexual-harrassment-footer modal end -->




<!-- Go To Top -->
<div id="gotoTop" class="icon-angle-up"></div>
<!-- start intake top bar -->
<div id="intake" class="modal fade mt50" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-body mt30">
				<h4 class="text-center mb0"><strong>Admissions for 2017-2018 are closed, except for the following programmes.</strong><br></h4>
				<div class="col-md-12 pa0 mt20">
					<div class="col-md-12">
						<div class="title-block">
							<h4>B.Ed.</h4>
							<span>
								<a href="//admission.lpu.in/" target="_blank" class="more-link">Click Here</a>
							</span>
							<br> The last date to apply for admission is 31st August 2017.
						</div>
					</div>
					<div class="col-md-12">
						<div class="title-block">
							<h4> Integrated B.Ed. - M.Ed.</h4>
							<span>
								<a href="//admission.lpu.in/" target="_blank" class="more-link">Click Here</a>
							</span>
							<br> The last date to apply for admission is 31st August 2017.
						</div>
					</div>
					To enquire for admission in programmes other than mentioned above, <a href="//www.lpu.in/contact_us/contact-us.php" class="btn btn-default btn-xs">Click Here</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<div class="modal1 mfp-hide" id="disciplines-popup">
	<div class="block divcenter disciplines-popup" style="background-color: #FFF; width: 80%;">
		<div class="row nomargin clearfix">
			<div class="col-sm-12 col-padding pa30">
				<div class="heading-block center mb30">
					<h2>Disciplines / Departments</h2> </div>
				<table id="dexample" class="display" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electronics &amp; Communication Engg. (ECE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/business/" target="_blank">Management</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/pharmaceutical-sciences/" target="_blank">Pharmaceutical Sciences</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/computer-science-engineering/" target="_blank">Computer Science &amp; Engineering (CSE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/business/" target="_blank">Commerce</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/computer-science-engineering/" target="_blank">Information Technology (IT)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/business/" target="_blank">Economics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physiotherapy-and-paramedical-sciences/" target="_blank">Physiotherapy</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electronics &amp; Computer Engineering</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/law/" target="_blank">Law</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physiotherapy-and-paramedical-sciences/" target="_blank">Medical Laboratory Sciences</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">Mechanical Engineering (ME)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/hotel-management-and-tourism/" target="_blank">Hotel Management and Tourism</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biotechnology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">ME - Mechatronics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Architecture</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Microbiology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">Aerospace Engineering</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Planning</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Forensic Sciences</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Interior &amp; Furniture Design</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biochemistry</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/architecture-design/" target="_blank">Product &amp; Industrial Design</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Botany</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/mechanical-engineering/" target="_blank">Automobile Engineering (AE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/fashion-design/" target="_blank">Fashion Design</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Zoology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electrical Engineering (EE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Multimedia &amp; Animation</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Chemistry</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/electronics-electrical-engineering/" target="_blank">Electrical and Electronics Engineering (EEE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Journalism &amp; Film Production</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Physics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/civil-engineering/" target="_blank">Civil Engineering (CE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Fine Arts</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Mathematics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biotechnology (BT)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/journalism-film-production/" target="_blank">Performing Arts</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Arts (Humanities)</a>
							</td>
						</tr>
						
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Psychology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">English and Foreign Languages</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/bioengineering-and-biosciences/" target="_blank">Biomedical Engineering</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Sociology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Indian Languages</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">Chemical Engineering (CHE)</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">History</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Public Administration</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-sciences/" target="_blank">CHE - Petroleum</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Political Science</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/polytechnic/" target="_blank">Polytechnic</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Geography</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/arts-and-languages/" target="_blank">Library Science</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/computer-applications/" target="_blank">Computer Applications</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/agriculture/" target="_blank">Food Technology</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/education/" target="_blank">Education</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/agriculture/" target="_blank">Agriculture</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/agriculture/" target="_blank">Nutrition and Dietetics</a>
							</td>
						</tr>
						<tr>
							<td><a href="//schools.lpu.in/physical-education/" target="_blank">Physical Education</a>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!-- Modal noti start -->
<div class="modal fade" id="myLargeModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" id="modal-width">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title upcom text-center" id="myLargeModalLabel">Events</h4>
				<!--<h4 class="modal-title upcom1 text-center">Knowledge BrainStorm</h4>-->
			</div>
			<div class="modal-body" id="single-modal">
				<div id="noti" class="row clearfix">
				
				
				
				
				
				<!--start3rd-->
					<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/studygrant.jpg" alt="studygrant">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
							<strong>Benefits of Taking LPUNEST</strong><br>
								Now qualifying LPUNEST can also get you an assured study grant of upto Rs. 3 Lac per student to study at IITs/ NITs/ IIMs/ NLUs / IHMs/ NIDs/ IIT( DoD/ IDC)/ IIITDM/ NIFTs. <strong>OR</strong> Get admission into LPU programmes and avail scholarship of upto Rs. 5 Lac per student.
							</p>
							<div class="text-center">								
							
								
								<a class="button button-small active button-border button-rounded" href="//www.lpu.in/studygrant/index.php" target="_blank">Read More</a>

							</div>
						</div>
					</div>
					<!--end3rd-->
				
				
					<!--start3rd-->
					<!--<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/knowledge.jpg" alt="knowledge-brain-storm">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
								<strong>“Knowledge Brainstorm” (KBS),</strong> conducted under Transforming Education Awards for school students of North Eastern states, has proved to be the most preferred aptitude test for the young minds. KBS has been designed to examine the general skills, critical thinking, analytical skills, and intellectual promise of school students.
							</p>
							<div class="text-center">								
							
								
								<a class="button button-small active button-border button-rounded" href="//www.lpu.in/knowledge-brain-storm/index.php" target="_blank">Read More</a>

							</div>
						</div>
					</div>-->
					<!--end3rd-->
					
					<!--start3rd-->
					<!--<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5 col-md-6">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/convocation.jpg" alt="FRESHMEN INDUCTION 2018" style="opacity: 1;">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
								<strong>9th Convocation on 22nd October 2018</strong><br> Lovely Professional University solicit your presence on the occasion of the “9th Annual Convocation Ceremony” for the class of 2017 and 2018 scheduled for Monday 22nd of October 2018 at 1000 hrs. Shri M. Venkaiah Naidu, Hon’ble Vice-President of India, has very kindly consented to be the Chief Guest and deliver the Convocation Address. 
							</p>
							<div class="text-center">	
								<a class="button button-small active button-border button-rounded" href="convocation/index.aspx" target="_blank">Read More </a>
							</div>
						</div>
					</div>-->
					<!--end3rd-->
					
					
					<!--start3rd-->
					<div class="diff-popup col-md-4 clearfix pb0 mb10 pa5 col-md-6">
						<div class="entry-image mb0">
							<img class="image_fade" src="//www.lpu.in/images/educationawards.jpg" alt="AIU 2018" style="opacity: 1;">
						</div>
						<div class="entry-content mt0 mb0 pa10">
							<p class="mb5">
								<strong>Transforming Education Awards</strong><br>After the grand success of its first edition, the 2nd Edition of Transforming Education Awards is slated to be a much better affair as compared to last year. Upload a video of your inspiring teacher and win a grant of Rs. 50000 for your school, award of Rs. 25000 for your Teacher, and Rs. 10000 for yourself.   
							</p>
								<div class="text-center">	
								<a class="button button-small active button-border button-rounded" href="https://www.lpu.in/educationawards" target="_blank">Read More </a>
							</div>
						
						</div>
					</div>
					<!--end3rd-->
					
					
				</div>
			</div>
		</div>
	</div>
</div>

<!--<div class="modal fade" id="nirf" role="dialog">
	<div class="vertical-alignment-helper">
		<div class="modal-dialog vertical-align-center">
			<div class="modal-content cent">
				<div style="background-color:#2985c6;" class="modal-header">
					<button type="button" style="color:#fff; opacity:1;" class="close" data-dismiss="modal">&times;</button>
					<h4 style="background:#2985c5; color:#fff;" class="modal-title">NIRF</h4>
				</div>
				<div class="modal-body">
				<h4 class="text-center mt15 border-bottom">2018</h4>
					<ul class="iconlist nirf" style="margin-top:20px;">
						<li><a href="https://www.lpu.in/downloads/nirf/Architecture.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture<br></a>
						</li>
						<li><a href="https://www.lpu.in/downloads/nirf/Management.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a>
						</li>
						<li><a href="https://www.lpu.in/downloads/nirf/Pharmacy.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a>
						</li>
						
					</ul>
					<h4 class="text-center mt15 border-bottom">2019</h4>
					
					<ul class="iconlist nirf" style="margin-top:20px;">
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Engineering</a></li>
						<li><a href="" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Overall</a></li>
						
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>-->

<div class="modal fade" id="nirf" role="dialog">
	<div class="vertical-alignment-helper">
		<div class="modal-dialog vertical-align-center">
			<!-- Modal content-->
			<div class="modal-content cent">
				<div style="background-color:#2985c6;" class="modal-header">
					<button type="button" style="color:#fff; opacity:1;" class="close" data-dismiss="modal">&times;</button>
					<h4 style="background:#2985c5; color:#fff;" class="modal-title">NIRF</h4>
				</div>
				<div class="modal-body">
				
						<div class="tabs tabs-bb clearfix" id="tab-9">

							<ul class="tab-nav clearfix">
								<li><a href="#tabs-33">2018</a></li>
								<li><a href="#tabs-34">2019</a></li>
							</ul>

							<div class="tab-container">

								<div class="tab-content clearfix" id="tabs-33">
									<ul class="iconlist nirf" style="margin:0 0 0 30px;">
										<li><a href="https://www.lpu.in/downloads/nirf/Architecture.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture<br></a>
										</li>
										<li><a href="https://www.lpu.in/downloads/nirf/Management.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a>
										</li>
										<li><a href="https://www.lpu.in/downloads/nirf/Pharmacy.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a>
										</li>
										
									</ul>
								</div>
								<div class="tab-content clearfix" id="tabs-34">
									<ul class="iconlist nirf" style="margin:0 0 0 30px">
										<li><a href="https://www.lpu.in/downloads/nirf/Architecture-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Architecture</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Management-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Management</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Pharmacy-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Pharmacy</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Engineering-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Engineering</a></li>
										<li><a href="https://www.lpu.in/downloads/nirf/Overall-2019.pdf" target="_blank" class="nirf-hd"><i class="icon-ok"></i>Report of NIRF Data Capturing System: Overall</a></li>										
									</ul>
								</div>
								

							</div>

						</div>

				</div>
				<div class="modal-footer">
					<ul class="iconlist text-center nirf" style="margin:0 !important;">
					<li class="nirf-hd">Email ID for Comments & Feedback : <span>registrar@lpu.co.in</span>
						</li>
					</ul>
				  </div>
			</div>
		</div>
	</div>
</div>






<div class="modal fade" id="convocation" role="dialog">
	<div class="modal-dialog modal-lg modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<div class="modal-title" style="font-size:18px; font-weight:400; color:#232020;"><b>9th Convocation</b></div>
			</div>
			<div class="modal-body">
				The photographs of the students, who attended the 9th Convocation are attached under the following links. Students can download the photographs based on the line number allocated to them, for the ceremony.
				<div class="col-md-12 pa0 mt20">
					<div class="col-md-12">
						<div class="title-block">
							<h4>Convocation (Gold Medalist and Ph.D)</h4>
							<span>
								<a href="https://photos.app.goo.gl/rc8kQAN5wERJhrLA7" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="divider mt10 mb10"><em class="icon-circle"></em>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 1)</h4>
							<span>
								<a href="https://photos.app.goo.gl/TUxf8rNFqDHMhphw5" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 2)</h4>
							<span>
								<a href="https://photos.app.goo.gl/hiHDZi2p45nvB4az6" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
				</div>
				<div class="divider mt10 mb10"><em class="icon-circle"></em>
				</div>
				<div class="col-md-12 pa0">
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 3)</h4>
							<span>
								<a href="https://photos.app.goo.gl/8efLx5unJD5AML3C9" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 4)</h4>
							<span>
								<a href="https://photos.app.goo.gl/AhpHq8WZhNU6pTEt7" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
				</div>
				<div class="divider mt10 mb10"><em class="icon-circle"></em>
				</div>
				<div class="col-md-12 pa0">
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 5)</h4>
							<span>
								<a href="https://photos.app.goo.gl/sHJLeF4z61nAsvUh7" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="title-block">
							<h4>Convocation (Line 6)</h4>
							<span>
								<a href="https://photos.app.goo.gl/nFQJppXSfGpYe4XBA" target="_blank" class="more-link">Click Here</a>
							</span>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<input type='hidden' id='getday' value="Wednesday" />


<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" defer></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" type="text/css"/>
<script src="//www.lpu.in/js/jquery.popupwindow.js" defer></script>

<script type="text/javascript">

            function isValidEmailAddress(emailAddress) {
            var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
            return pattern.test(emailAddress);
            }
         

          

	$(document).ready(function() {
		
	 $("#subs-btn").click(function () {
            if (!isValidEmailAddress($("#widget-subscribe-form-email").val())) {
            $('#widget-subscribe-form-result2').attr('data-notify-msg', 'Please enter a valid email address');
            SEMICOLON.widget.notifications($('#widget-subscribe-form-result2'));
            }
            else {
            $("#spinner").removeClass('icon-email2').addClass('icon-line-loader icon-spin');
            var id = $("#widget-subscribe-form-email").val();
            $.ajax({
            url: "../SubscribeNewsletter.asmx/Subscribe",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: "{email:'" + id + "'}",
            success: function (msg) {
            $("#spinner").removeClass('icon-line-loader icon-spin').addClass('icon-email2');
            $("#widget-subscribe-form-email").val('');
            if(msg.d=="success")
            {

            $('#widget-subscribe-form-result').attr('data-notify-msg', 'You have successfully subscribed');
            SEMICOLON.widget.notifications($('#widget-subscribe-form-result'));

            }
            else if(msg.d=="error")
            {
            $('#widget-subscribe-form-result2').attr('data-notify-msg', 'You have already subscribed');
            SEMICOLON.widget.notifications($('#widget-subscribe-form-result2'));

            }
            },
            error: function () {
            $("#widget-subscribe-form-email").val('');
            $("#spinner").removeClass('icon-line-loader icon-spin').addClass('icon-email2');
            }
            });
            return false;

            }
            });
			
		// $( "#educationawards" ).click( function () {
			// $( ".upcom" ).addClass( "hide" );
			// $( ".upcom1" ).removeClass( "hide" );
			// $( ".brainstorm" ).css( "display", "none" );
			// $( "#modal-width" ).removeClass( "double-modal" );
			// $( "#modal-width" ).addClass( "single-modal" );
			// $( ".diff-popup" ).removeClass( "col-md-4" );
			// $( ".diff-popup" ).removeClass( "col-61" );
			// $( ".diff-popup" ).removeClass( "col-md-6" );
		// } );


		$( "#bt-notification" ).click( function () {
			$( ".brainstorm" ).css( "display", "" );

			$( ".upcom" ).removeClass( "hide" );
			$( ".upcom1" ).addClass( "hide" );
			//$(".diff-popup").addClass("col-md-4");
			//$( "#modal-width" ).addClass( "double-modal" );
			//$("#modal-width").addClass("double-modal");
			//$( "#modal-width" ).removeClass( "single-modal" );
			$( ".diff-popup " ).addClass( "col-md-6" );

		} );
		$( "#footer" ).removeAttr( "style" );
		var pathname = window.location.pathname;
		var str_array = pathname.split( '/' );
		if ( str_array[ 1 ].replace( /^\s*/, "" ).replace( /\s*$/, "" ) == "international" ) {
			//alert('Number1');
			$( ".international" ).show();
			$( ".si-whatsapp" ).attr("href","https://api.whatsapp.com/send?phone=+919876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202019.");
			$( ".call" ).hide();
			$( ".ltown" ).hide();
		} else {
			$( ".international" ).hide();

			//Whatsapp Number change
			if ( $('#getday').val() == "Monday" || $('#getday').val() == "Wednesday" || $('#getday').val() == "Friday" ) {
				//alert('Number1');
				$( ".si-whatsapp" ).attr("href","https://api.whatsapp.com/send?phone=+919876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202019.");
				$( ".si-whatsapp" ).attr("title","Whatsapp only +919876022222");
			} else {
				//alert('Number2');
				$( ".si-whatsapp" ).attr("href","https://api.whatsapp.com/send?phone=+919876022222&text=Hi%2C%20I%20need%20assistance%20for%20Admissions%202019.");
				$( ".si-whatsapp" ).attr("title","Whatsapp only +919876022222");
			}
		}

		$( '#dexample' ).DataTable( {
			scrollY: 500,
			"paging": false,
			"ordering": false,
			"info": false
		} );

		var numItems = $( '#single-modal .col-md-4' ).length;
		//alert(numItems);
		if ( numItems <= 3 ) {
			$( '#myLargeModal' ).addClass( 'm10' );

		}
		if ( numItems > 3 ) {
			$( '#myLargeModal' ).addClass( 'm3' );
		}
		if ( numItems == 1 ) {
			$( '#modal-width' ).addClass( 'single-modal' );
			$( '#noti .col-md-4' ).addClass( 'col-12' );
		}
		if ( numItems == 2 ) {
			$( '#modal-width' ).addClass( 'double-modal' );
			$( '#noti .col-md-4' ).addClass( 'col-61' );
		}
		var sWidth = $( window ).width();
		if ( sWidth < 770 ) {
			$( '#noti .col-md-4' ).removeClass( 'pl7' );
			$( '#noti .col-md-4' ).removeClass( 'pr7' );
			if ( numItems == 1 ) {
				$( '#modal-width' ).removeClass( 'single-modal' );
				$( '#noti .col-md-4' ).removeClass( 'col-12' );
			}
			if ( numItems == 2 ) {
				$( '#modal-width' ).removeClass( 'double-modal' );
				$( '#noti .col-md-4' ).removeClass( 'col-61' );
			}
		}
	} );

	function homeToast( vtype, vtitle, vmsgtext, vNavigationUrl, type ) {
		if ( type == "link" ) {
			toastr.options = {
				"closeButton": true,
				"debug": false,
				"newestOnTop": true,
				"progressBar": true,
				"positionClass": "toast-top-left",
				"preventDuplicates": true,
				//"onclick": daljit(),
				onclick: function () {
					window.open( vNavigationUrl, '_blank' );
				},
				"showDuration": "12000",
				"hideDuration": "1000",
				"timeOut": "10000",
				"extendedTimeOut": "1000",
				"showEasing": "swing",
				"hideEasing": "linear",
				"showMethod": "fadeIn",
				"hideMethod": "fadeOut"
			}
			toastr[ vtype ]( vmsgtext, vtitle )
		} else if ( type == "popup" ) {
			toastr.options = {
				"closeButton": true,
				"debug": false,
				"newestOnTop": true,
				"progressBar": true,
				"positionClass": "toast-top-left",
				"preventDuplicates": true,
				onclick: function () {
					$( "#" + vNavigationUrl ).trigger( "click" );
				},
				"showDuration": "12000",
				"hideDuration": "1000",
				"timeOut": "10000",
				"extendedTimeOut": "1000",
				"showEasing": "swing",
				"hideEasing": "linear",
				"showMethod": "fadeIn",
				"hideMethod": "fadeOut"
			}
			toastr[ vtype ]( vmsgtext, vtitle )
		}
	}

	function setModalMaxHeight( element ) {
		this.$element = $( element );
		this.$content = this.$element.find( '.modal-content' );
		var borderWidth = this.$content.outerHeight() - this.$content.innerHeight();
		var dialogMargin = $( window ).width() < 768 ? 20 : 60;
		var contentHeight = $( window ).height() - ( dialogMargin + borderWidth );
		var headerHeight = this.$element.find( '.modal-header' ).outerHeight() || 0;
		var footerHeight = this.$element.find( '.modal-footer' ).outerHeight() || 0;
		var maxHeight = contentHeight - ( headerHeight + footerHeight );

		this.$content.css( {
			'overflow': 'hidden'
		} );

		this.$element
			.find( '#myLargeModal .modal-body' ).css( {
				'max-height': maxHeight,
				'overflow-y': 'auto'
			} );
	}

	$( '.modal' ).on( 'show.bs.modal', function () {
		$( this ).show();
		setModalMaxHeight( this );
	} );

	$( window ).resize( function () {
		if ( $( '.modal.in' ).length != 0 ) {
			setModalMaxHeight( $( '.modal.in' ) );
		}
	} );
	$( '.ppwnd' ).on( 'click', function ( event ) {
		event.preventDefault();
		$.popupWindow( '//www.lpu.in/ClickToCall.php', {
		//$.popupWindow( '//172.17.60.228/ClickToCall.php', {
			width: 420,
			height: 630
		} );
	} );
</script>
<div style="display:none !important">

<!-- ===================================================== -->
<!-- Description of the code :Google Analytics -->
<!-- Applied Date: 06-Mar-2018 format  ( 05-Mar-2018 )  -->
<!-- Applicable for  Year: 2018 -->
<!-- Required Till: Permanent or Possible Month-Year till code is required -->
<!-- Source Agency : AdGlobal Etc -->
<!-- Contact Person : Abha  -->
<!-- ===================================================== -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-8319620-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-8319620-1');
</script>
<!-- ============ End Of Code  ============================== -->

<!-- ===================================================== -->
<!-- Description of the code :AMO Code -->
<!-- Applied Date: 06-Mar-2018 format  ( 05-Mar-2018 )  -->
<!-- Applicable for  Year: 2018 -->
<!-- Required Till: Permanent or Possible Month-Year till code is required -->
<!-- Source Agency : AdGlobal Etc -->
<!-- Contact Person : Abha  -->
<!-- ===================================================== -->
<img src="//pixel.everesttech.net/px2/5453?px_evt=t&ev_Landing_Page=1" width="1" height="1"/>
<!-- ============ End Of Code  ============================== -->
</div>		<!-- #footer end -->

	</div><!-- #wrapper end -->


	
<!-- Go To Top
============================================= -->
<div id="gotoTop" class="icon-angle-up"></div>
<script type="text/javascript" src="//www.lpu.in/js/functions.js"></script>
<script>
$(document).ready(function(){
	var sliderHeight = $(window).height() - $("#header").height() - $("#top-bar").height() - 200;
	$('#slider').css('height',sliderHeight);
});
</script>
</body>
</html>
