<head><title>Document Moved</title></head>
<body><h1>Object Moved</h1>This document may be found <a HREF="https://www.lpu.in/admission/career_assessment.php">here</a></body>