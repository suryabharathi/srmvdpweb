<head><title>Document Moved</title></head>
<body><h1>Object Moved</h1>This document may be found <a HREF="https://www.lpu.in/about_lpu/ranking.php">here</a></body>